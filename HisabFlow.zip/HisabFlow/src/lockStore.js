// লক সেটিং আলাদা কী-তে সেভ হয় (ব্যাকআপ ফাইলে যায় না, রিস্টোরে বদলায়ও না)
import { Preferences } from '@capacitor/preferences';

const KEY = 'hisabflow_lock';
let current = null;

export async function loadLock() {
  try {
    const { value } = await Preferences.get({ key: KEY });
    current = value ? JSON.parse(value) : null;
  } catch (err) {
    console.error('লক সেটিং লোড করা যায়নি:', err);
    current = null;
  }
  return current;
}

export function getLock() {
  return current;
}

export function lockEnabled() {
  return !!(current && current.enabled);
}

export async function setLock(cfg) {
  current = cfg;
  await Preferences.set({ key: KEY, value: JSON.stringify(cfg) });
}

export async function clearLock() {
  current = null;
  await Preferences.remove({ key: KEY });
}
