// ডেটা স্কিমা, ডিফল্ট ডেটা ও ছোট হেল্পার

export const DATA_VERSION = 1;

export const DEFAULT_CATEGORIES = {
  income: ['বেতন', 'ব্যবসা', 'উপহার', 'অন্যান্য আয়'],
  expense: ['খাবার', 'যাতায়াত', 'বাসা ভাড়া', 'বিল', 'চিকিৎসা', 'কেনাকাটা', 'শিক্ষা', 'অন্যান্য ব্যয়']
};

export function uid(prefix = 'id') {
  return `${prefix}_${Date.now().toString(36)}${Math.random().toString(36).slice(2, 7)}`;
}

export function todayISO() {
  const d = new Date();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${d.getFullYear()}-${m}-${day}`;
}

export function defaultData() {
  return {
    version: DATA_VERSION,
    settings: { currency: '৳', theme: 'auto', createdAt: todayISO() },
    wallets: [
      { id: 'w_cash', name: 'Cash', type: 'cash', openingBalance: 0 },
      { id: 'w_bkash', name: 'bKash', type: 'mobile', openingBalance: 0 },
      { id: 'w_nagad', name: 'Nagad', type: 'mobile', openingBalance: 0 },
      { id: 'w_bank', name: 'Bank', type: 'bank', openingBalance: 0 }
    ],
    categories: structuredClone(DEFAULT_CATEGORIES),
    transactions: [],
    dues: [],
    settlements: [],
    transfers: []
  };
}

// পুরনো/অসম্পূর্ণ ডেটা এলে মিসিং ফিল্ড ভরে দেয়
export function normalize(data) {
  const base = defaultData();
  const merged = { ...base, ...data };
  merged.settings = { ...base.settings, ...(data.settings || {}) };
  for (const key of ['wallets', 'transactions', 'dues', 'settlements', 'transfers']) {
    if (!Array.isArray(merged[key])) merged[key] = base[key];
  }
  if (!merged.categories) merged.categories = base.categories;
  merged.version = DATA_VERSION;
  return merged;
}
