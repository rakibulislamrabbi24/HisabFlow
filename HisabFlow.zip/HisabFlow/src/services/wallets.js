// মাল্টি-ওয়ালেট ও ট্রান্সফার লজিক (UI-মুক্ত)
import { uid } from '../models.js';
import { walletBalance } from './summary.js';
import { round2 } from './dues.js';
import { ensureCategory } from './transactions.js';
import { fmtNum } from '../utils/format.js';

export const WALLET_TYPES = {
  cash: { label: 'নগদ টাকা', icon: 'cash', rgb: '34,197,94' },
  mobile: { label: 'মোবাইল ব্যাংকিং', icon: 'phone', rgb: '236,72,153' },
  bank: { label: 'ব্যাংক', icon: 'bank', rgb: '59,130,246' },
  other: { label: 'অন্যান্য', icon: 'wallet', rgb: '168,85,247' }
};
export const FEE_CATEGORY = 'ট্রান্সফার ফি';
const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;

// ---------- ওয়ালেট ----------
export function validateWallet(input, state, editingId = null) {
  const name = String(input.name || '').trim();
  if (!name) return 'ওয়ালেটের নাম লিখুন';
  if (name.length > 30) return 'নাম ৩০ অক্ষরের মধ্যে রাখুন';
  if (state.wallets.some((w) => w.id !== editingId && w.name.trim().toLowerCase() === name.toLowerCase())) {
    return 'এই নামে আরেকটি ওয়ালেট আছে';
  }
  if (!WALLET_TYPES[input.type]) return 'ওয়ালেটের ধরন বাছাই করুন';
  const ob = input.openingBalance === '' || input.openingBalance == null ? 0 : Number(input.openingBalance);
  if (!isFinite(ob) || Math.abs(ob) > 1e12) return 'শুরুর ব্যালেন্স ঠিক নেই';
  return null;
}

export function addWallet(state, input) {
  const w = {
    id: uid('w'),
    name: String(input.name).trim(),
    type: input.type,
    openingBalance: round2(input.openingBalance === '' ? 0 : input.openingBalance)
  };
  state.wallets.push(w);
  return w;
}

export function updateWallet(state, id, input) {
  const i = state.wallets.findIndex((w) => w.id === id);
  if (i < 0) return null;
  state.wallets[i] = {
    ...state.wallets[i],
    name: String(input.name).trim(),
    type: input.type,
    openingBalance: round2(input.openingBalance === '' ? 0 : input.openingBalance)
  };
  return state.wallets[i];
}

// কোন ওয়ালেট কতগুলো রেকর্ডে ব্যবহৃত
export function walletUsage(state, id) {
  return {
    transactions: state.transactions.filter((t) => t.walletId === id).length,
    dues: state.dues.filter((d) => d.walletId === id).length,
    settlements: state.settlements.filter((s) => s.walletId === id).length,
    transfers: state.transfers.filter((t) => t.fromWalletId === id || t.toWalletId === id).length
  };
}

// মোছার অনুমতি: ব্যবহৃত হলে বা শেষ ওয়ালেট হলে মোছা যাবে না। (null = মোছা যাবে)
export function deleteBlockReason(state, id) {
  if (state.wallets.length <= 1) return 'অন্তত একটি ওয়ালেট রাখতেই হবে';
  const u = walletUsage(state, id);
  const total = u.transactions + u.dues + u.settlements + u.transfers;
  if (total > 0) return `এই ওয়ালেটে ${fmtNum(total)}টি রেকর্ড আছে, তাই মোছা যাবে না। চাইলে নাম বদলাতে পারেন।`;
  return null;
}

export function deleteWallet(state, id) {
  if (deleteBlockReason(state, id)) return false;
  state.wallets = state.wallets.filter((w) => w.id !== id);
  return true;
}

// ব্যালেন্সের ভাঙা হিসাব: শুরু + আয় − ব্যয় ± due/settlement ± ট্রান্সফার
export function walletBreakdown(state, id) {
  const w = state.wallets.find((x) => x.id === id);
  let income = 0;
  let expense = 0;
  let dues = 0;
  let transfersNet = 0;
  for (const t of state.transactions) {
    if (t.walletId !== id) continue;
    if (t.type === 'income') income += Number(t.amount) || 0;
    else expense += Number(t.amount) || 0;
  }
  for (const d of state.dues) {
    if (d.walletId === id) dues += d.kind === 'receivable' ? -(Number(d.amount) || 0) : Number(d.amount) || 0;
  }
  for (const s of state.settlements) {
    if (s.walletId !== id) continue;
    const due = state.dues.find((d) => d.id === s.dueId);
    if (due) dues += due.kind === 'receivable' ? Number(s.amount) || 0 : -(Number(s.amount) || 0);
  }
  for (const tr of state.transfers) {
    if (tr.fromWalletId === id) transfersNet -= Number(tr.amount) || 0;
    if (tr.toWalletId === id) transfersNet += Number(tr.amount) || 0;
  }
  return {
    opening: w ? Number(w.openingBalance) || 0 : 0,
    income: round2(income),
    expense: round2(expense),
    dues: round2(dues),
    transfers: round2(transfersNet),
    balance: w ? walletBalance(state, w) : 0
  };
}

// ওয়ালেটের সব নড়াচড়া (নতুন আগে); amount-এর চিহ্ন দেখায় টাকা বাড়ল না কমল
export function walletActivity(state, id, limit = 15) {
  const out = [];
  let ord = 0;
  const push = (e) => out.push({ ...e, ord: ord++ });
  const nameOf = (wid) => (state.wallets.find((w) => w.id === wid) || {}).name || '—';

  for (const t of state.transactions) {
    if (t.walletId !== id) continue;
    push({
      date: t.date, kind: t.transferId ? 'fee' : t.type,
      label: t.category + (t.note && !t.transferId ? ' · ' + t.note : ''),
      amount: t.type === 'income' ? Number(t.amount) : -Number(t.amount)
    });
  }
  for (const d of state.dues) {
    if (d.walletId !== id) continue;
    push({
      date: d.date, kind: 'due',
      label: (d.kind === 'receivable' ? 'পাওনা দেওয়া: ' : 'দেনা নেওয়া: ') + d.person,
      amount: d.kind === 'receivable' ? -Number(d.amount) : Number(d.amount)
    });
  }
  for (const s of state.settlements) {
    if (s.walletId !== id) continue;
    const due = state.dues.find((d) => d.id === s.dueId);
    if (!due) continue;
    push({
      date: s.date, kind: 'settlement',
      label: (due.kind === 'receivable' ? 'আদায়: ' : 'শোধ: ') + due.person,
      amount: due.kind === 'receivable' ? Number(s.amount) : -Number(s.amount)
    });
  }
  for (const tr of state.transfers) {
    if (tr.fromWalletId === id) push({ date: tr.date, kind: 'transfer', label: `ট্রান্সফার → ${nameOf(tr.toWalletId)}`, amount: -Number(tr.amount) });
    if (tr.toWalletId === id) push({ date: tr.date, kind: 'transfer', label: `ট্রান্সফার ← ${nameOf(tr.fromWalletId)}`, amount: Number(tr.amount) });
  }
  out.sort((a, b) => (b.date || '').localeCompare(a.date || '') || b.ord - a.ord);
  return limit ? out.slice(0, limit) : out;
}

// ---------- ট্রান্সফার ----------
// ফেরত: { error, warning } । error থাকলে সেভ হবে না; warning থাকলে ইউজার নিশ্চিত করলে সেভ হবে।
export function validateTransfer(input, state, editingId = null) {
  const from = state.wallets.find((w) => w.id === input.fromWalletId);
  const to = state.wallets.find((w) => w.id === input.toWalletId);
  if (!from) return { error: 'কোন ওয়ালেট থেকে পাঠাবেন তা বাছাই করুন' };
  if (!to) return { error: 'কোন ওয়ালেটে যাবে তা বাছাই করুন' };
  if (from.id === to.id) return { error: 'একই ওয়ালেটে ট্রান্সফার করা যায় না' };
  const amount = Number(input.amount);
  if (input.amount === '' || input.amount == null) return { error: 'পরিমাণ লিখুন' };
  if (!isFinite(amount) || amount <= 0) return { error: 'পরিমাণ ০-এর বেশি হতে হবে' };
  if (amount > 1e12) return { error: 'পরিমাণ অনেক বেশি হয়ে গেছে' };
  const fee = input.fee === '' || input.fee == null ? 0 : Number(input.fee);
  if (!isFinite(fee) || fee < 0) return { error: 'ফি ঠিক নেই' };
  if (!DATE_RE.test(input.date || '')) return { error: 'সঠিক তারিখ দিন' };

  // এডিটের সময় পুরনো ট্রান্সফারের প্রভাব বাদ দিয়ে ব্যালেন্স দেখা
  const base = editingId
    ? {
      ...state,
      transfers: state.transfers.filter((t) => t.id !== editingId),
      transactions: state.transactions.filter((t) => t.transferId !== editingId)
    }
    : state;
  const available = walletBalance(base, from);
  const need = round2(amount + fee);
  if (need > available) {
    return { warning: `${from.name}-এ ব্যালেন্স ${fmtNum(available)} টাকা, আপনি ${fmtNum(need)} টাকা পাঠাচ্ছেন। ব্যালেন্স মাইনাসে যাবে।` };
  }
  return {};
}

function cleanTransfer(input) {
  return {
    fromWalletId: input.fromWalletId,
    toWalletId: input.toWalletId,
    amount: round2(input.amount),
    fee: round2(input.fee === '' || input.fee == null ? 0 : input.fee),
    date: input.date,
    note: String(input.note || '').trim()
  };
}

function addFeeTx(state, tr) {
  if (!(tr.fee > 0)) return;
  ensureCategory(state, 'expense', FEE_CATEGORY);
  state.transactions.push({
    id: uid('t'), type: 'expense', amount: tr.fee, category: FEE_CATEGORY,
    walletId: tr.fromWalletId, date: tr.date, note: 'ট্রান্সফার ফি', transferId: tr.id,
    ...(tr.demo ? { demo: true } : {})
  });
}

// নতুন ট্রান্সফার: ফি থাকলে সোর্স ওয়ালেটে আলাদা ব্যয় হিসেবে যোগ হয়
export function addTransfer(state, input) {
  const tr = { id: uid('tr'), ...cleanTransfer(input) };
  state.transfers.push(tr);
  addFeeTx(state, tr);
  return tr;
}

export function updateTransfer(state, id, input) {
  const i = state.transfers.findIndex((t) => t.id === id);
  if (i < 0) return null;
  const tr = { ...state.transfers[i], ...cleanTransfer(input) };
  state.transfers[i] = tr;
  state.transactions = state.transactions.filter((t) => t.transferId !== id);
  addFeeTx(state, tr);
  return tr;
}

export function deleteTransfer(state, id) {
  state.transfers = state.transfers.filter((t) => t.id !== id);
  state.transactions = state.transactions.filter((t) => t.transferId !== id);
}

export function recentTransfers(state, limit = 10) {
  return [...state.transfers]
    .sort((a, b) => (b.date || '').localeCompare(a.date || '') || (b.id || '').localeCompare(a.id || ''))
    .slice(0, limit);
}
