// ড্যাশবোর্ডের সব হিসাব এখানে। ডেটা সেভ হয় না, প্রতিবার state থেকে হিসাব হয়।
import { monthKey } from '../utils/format.js';
import { remainingOf, round2 } from './dues.js';

const num = (v) => Number(v) || 0;

// একটি due-এর বাকি পরিমাণ (dues.js-এর লজিক)
export function dueRemaining(state, due) {
  return remainingOf(state, due);
}

// ওয়ালেট ব্যালেন্স = শুরুর ব্যালেন্স ± আয়/ব্যয় ± due ± settlement ± transfer
// নিয়ম: পাওনা (receivable) দিলে ওয়ালেট কমে, আদায়ে বাড়ে;
//        দেনা (payable) নিলে ওয়ালেট বাড়ে, শোধে কমে।
export function walletBalance(state, wallet) {
  let b = num(wallet.openingBalance);

  for (const t of state.transactions) {
    if (t.walletId !== wallet.id) continue;
    b += t.type === 'income' ? num(t.amount) : -num(t.amount);
  }
  for (const d of state.dues) {
    if (d.walletId !== wallet.id) continue;
    b += d.kind === 'receivable' ? -num(d.amount) : num(d.amount);
  }
  for (const s of state.settlements) {
    if (s.walletId !== wallet.id) continue;
    const due = state.dues.find((d) => d.id === s.dueId);
    if (!due) continue;
    b += due.kind === 'receivable' ? num(s.amount) : -num(s.amount);
  }
  for (const tr of state.transfers) {
    if (tr.fromWalletId === wallet.id) b -= num(tr.amount);
    if (tr.toWalletId === wallet.id) b += num(tr.amount);
  }
  return round2(b); // দশমিকের ছোট গোলমাল এড়াতে
}

export function walletBalances(state) {
  return state.wallets.map((w) => ({ wallet: w, balance: walletBalance(state, w) }));
}

// Net Balance = সব ওয়ালেটের মোট
export function netBalance(state) {
  return round2(walletBalances(state).reduce((sum, x) => sum + x.balance, 0));
}

// নির্দিষ্ট মাসের আয়/ব্যয় (key = "YYYY-MM")
export function monthSummary(state, key) {
  let income = 0;
  let expense = 0;
  for (const t of state.transactions) {
    if (monthKey(t.date) !== key) continue;
    if (t.type === 'income') income += num(t.amount);
    else expense += num(t.amount);
  }
  return { income, expense, saving: income - expense };
}

// মোট পাওনা ও দেনা (বাকি অংশ)
export function duesSummary(state, todayStr) {
  let receivable = 0;
  let payable = 0;
  let overdue = 0;
  let openCount = 0;
  for (const d of state.dues) {
    const rem = dueRemaining(state, d);
    if (rem <= 0) continue;
    openCount += 1;
    if (d.kind === 'receivable') receivable += rem;
    else payable += rem;
    if (d.dueDate && d.dueDate < todayStr) overdue += 1;
  }
  return { receivable, payable, overdue, openCount, net: receivable - payable };
}

export function recentTransactions(state, limit = 5) {
  return [...state.transactions]
    .sort((a, b) => (b.date || '').localeCompare(a.date || '') || (b.id || '').localeCompare(a.id || ''))
    .slice(0, limit);
}
