// অ্যাপ লকের মূল লজিক (UI-মুক্ত)। পিন কখনো সরাসরি সেভ হয় না, শুধু salt সহ PBKDF2 হ্যাশ সেভ হয়।
import { fmtNum } from '../utils/format.js';
import { isEn } from '../i18n/core.js';

export const PIN_LENGTHS = [4, 6];
export const TIMEOUTS = [
  { sec: 0, label: 'সাথে সাথে' },
  { sec: 30, label: '৩০ সেকেন্ড পর' },
  { sec: 60, label: '১ মিনিট পর' },
  { sec: 300, label: '৫ মিনিট পর' }
];
export const FREE_ATTEMPTS = 5; // এতবার ভুলের পর অপেক্ষা শুরু
const ITERATIONS = 100000;
const enc = new TextEncoder();

const toB64 = (buf) => btoa(String.fromCharCode(...new Uint8Array(buf)));
const fromB64 = (s) => Uint8Array.from(atob(s), (c) => c.charCodeAt(0));

export function cryptoAvailable() {
  return !!(globalThis.crypto && globalThis.crypto.subtle && globalThis.crypto.getRandomValues);
}

export function validatePin(pin, length) {
  return typeof pin === 'string' && /^\d+$/.test(pin) && pin.length === length;
}

// সহজ পিন: সব এক সংখ্যা (0000) বা ক্রমানুসারে (1234, 4321)
export function isWeakPin(pin) {
  if (/^(\d)\1+$/.test(pin)) return true;
  const d = pin.split('').map(Number);
  const step = d[1] - d[0];
  if (Math.abs(step) !== 1) return false;
  return d.every((x, i) => i === 0 || x - d[i - 1] === step);
}

export async function hashPin(pin, saltB64, iterations = ITERATIONS) {
  const key = await crypto.subtle.importKey('raw', enc.encode(pin), 'PBKDF2', false, ['deriveBits']);
  const bits = await crypto.subtle.deriveBits(
    { name: 'PBKDF2', hash: 'SHA-256', salt: fromB64(saltB64), iterations }, key, 256
  );
  return toB64(bits);
}

function safeEqual(a, b) {
  if (typeof a !== 'string' || typeof b !== 'string' || a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}

// নতুন লক কনফিগ। prev দিলে ফিঙ্গারপ্রিন্ট ও টাইমআউট সেটিং থেকে যায় (পিন বদলের সময়)।
export async function makeLockConfig(pin, length, prev = {}) {
  const salt = toB64(crypto.getRandomValues(new Uint8Array(16)));
  return {
    version: 1,
    enabled: true,
    pinLength: length,
    salt,
    iterations: ITERATIONS,
    hash: await hashPin(pin, salt, ITERATIONS),
    biometric: !!prev.biometric,
    timeoutSec: typeof prev.timeoutSec === 'number' ? prev.timeoutSec : 30,
    fails: 0,
    lockUntil: 0
  };
}

export async function verifyPin(cfg, pin) {
  if (!cfg || !cfg.enabled || !validatePin(pin, cfg.pinLength)) return false;
  return safeEqual(await hashPin(pin, cfg.salt, cfg.iterations), cfg.hash);
}

// ভুলের সংখ্যা অনুযায়ী অপেক্ষা: ৫ বারে ৩০ সেকেন্ড, তারপর বাড়তে থাকে
export function lockoutMs(fails) {
  if (fails < FREE_ATTEMPTS) return 0;
  if (fails === FREE_ATTEMPTS) return 30 * 1000;
  if (fails === FREE_ATTEMPTS + 1) return 60 * 1000;
  if (fails === FREE_ATTEMPTS + 2) return 5 * 60 * 1000;
  return 15 * 60 * 1000;
}

export function registerFail(cfg, now = Date.now()) {
  const fails = (cfg.fails || 0) + 1;
  const wait = lockoutMs(fails);
  return { ...cfg, fails, lockUntil: wait > 0 ? now + wait : 0 };
}

export function registerSuccess(cfg) {
  return { ...cfg, fails: 0, lockUntil: 0 };
}

export function remainingLockMs(cfg, now = Date.now()) {
  return Math.max(0, (cfg && cfg.lockUntil ? cfg.lockUntil : 0) - now);
}

export function formatWait(ms) {
  const total = Math.ceil(ms / 1000);
  const m = Math.floor(total / 60);
  const s = total % 60;
  if (isEn()) {
    if (m > 0 && s > 0) return `${m} min ${s} sec`;
    return m > 0 ? `${m} min` : `${s} sec`;
  }
  if (m > 0 && s > 0) return `${fmtNum(m)} মিনিট ${fmtNum(s)} সেকেন্ড`;
  if (m > 0) return `${fmtNum(m)} মিনিট`;
  return `${fmtNum(s)} সেকেন্ড`;
}

// অ্যাপ ব্যাকগ্রাউন্ড থেকে ফিরলে আবার লক করতে হবে কিনা। leftAt = ব্যাকগ্রাউন্ডে যাওয়ার সময় (না থাকলে null)
export function shouldRelock(cfg, leftAt, now = Date.now()) {
  if (!cfg || !cfg.enabled || leftAt == null) return false;
  return (now - leftAt) / 1000 >= (cfg.timeoutSec || 0);
}
