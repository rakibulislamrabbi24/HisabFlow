// দেনা-পাওনা (Due/Loan) ও আংশিক শোধ/আদায়ের লজিক
// kind: 'receivable' = পাওনা (আমি পাবো), 'payable' = দেনা (আমি দেবো)
import { uid } from '../models.js';
import { fmtNum } from '../utils/format.js';

export const round2 = (n) => Math.round((Number(n) || 0) * 100) / 100;

export function paidOf(state, dueId) {
  return round2(
    state.settlements.filter((s) => s.dueId === dueId).reduce((sum, s) => sum + (Number(s.amount) || 0), 0)
  );
}

export function remainingOf(state, due) {
  return Math.max(0, round2(Number(due.amount) - paidOf(state, due.id)));
}

// একটি due-এর পূর্ণ অবস্থা: paid, remaining, status (open/partial/settled), overdue, pct
export function dueInfo(state, due, todayStr) {
  const paid = paidOf(state, due.id);
  const remaining = remainingOf(state, due);
  const status = remaining <= 0 ? 'settled' : paid > 0 ? 'partial' : 'open';
  const overdue = remaining > 0 && !!due.dueDate && due.dueDate < todayStr;
  const amount = Number(due.amount) || 0;
  const pct = amount > 0 ? Math.min(100, Math.round((paid / amount) * 100)) : 0;
  return { paid, remaining, status, overdue, pct };
}

const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;

// due ইনপুট যাচাই। editingId দিলে এডিট মোড (আগের শোধের চেয়ে কম পরিমাণ দেওয়া যাবে না)
export function validateDue(input, state, editingId = null) {
  if (input.kind !== 'receivable' && input.kind !== 'payable') return 'পাওনা না দেনা বাছাই করুন';
  if (!String(input.person || '').trim()) return 'ব্যক্তির নাম লিখুন';
  const amount = Number(input.amount);
  if (input.amount === '' || input.amount == null) return 'পরিমাণ লিখুন';
  if (!isFinite(amount) || amount <= 0) return 'পরিমাণ ০-এর বেশি হতে হবে';
  if (amount > 1e12) return 'পরিমাণ অনেক বেশি হয়ে গেছে';
  if (input.walletId && !state.wallets.some((w) => w.id === input.walletId)) return 'ওয়ালেট ঠিক নেই';
  if (!DATE_RE.test(input.date || '')) return 'সঠিক তারিখ দিন';
  if (input.dueDate && !DATE_RE.test(input.dueDate)) return 'মেয়াদের তারিখ ঠিক নেই';
  if (input.dueDate && input.dueDate < input.date) return 'মেয়াদ তারিখ শুরুর তারিখের আগে হতে পারে না';
  if (editingId) {
    const paid = paidOf(state, editingId);
    if (round2(amount) < paid) return `ইতিমধ্যে ${fmtNum(paid)} টাকা শোধ/আদায় হয়েছে, পরিমাণ এর কম হতে পারে না`;
  }
  return null;
}

function cleanDue(input) {
  return {
    kind: input.kind,
    person: String(input.person).trim(),
    amount: round2(input.amount),
    walletId: input.walletId || null, // null = ওয়ালেটে প্রভাব নেই
    date: input.date,
    dueDate: input.dueDate || '',
    note: String(input.note || '').trim()
  };
}

export function addDue(state, input) {
  const due = { id: uid('d'), ...cleanDue(input) };
  state.dues.push(due);
  return due;
}

export function updateDue(state, id, input) {
  const i = state.dues.findIndex((d) => d.id === id);
  if (i < 0) return null;
  const old = state.dues[i];
  const next = { ...old, ...cleanDue(input) };
  // শোধ/আদায় শুরু হয়ে গেলে ধরন (পাওনা/দেনা) বদলানো যাবে না
  if (state.settlements.some((s) => s.dueId === id)) next.kind = old.kind;
  state.dues[i] = next;
  return next;
}

// due মুছলে তার সব settlement-ও মোছে
export function deleteDue(state, id) {
  state.dues = state.dues.filter((d) => d.id !== id);
  state.settlements = state.settlements.filter((s) => s.dueId !== id);
}

// আংশিক শোধ/আদায় যাচাই
export function validateSettlement(input, state, due) {
  const amount = Number(input.amount);
  if (input.amount === '' || input.amount == null) return 'পরিমাণ লিখুন';
  if (!isFinite(amount) || amount <= 0) return 'পরিমাণ ০-এর বেশি হতে হবে';
  const remaining = remainingOf(state, due);
  if (remaining <= 0) return 'এই হিসাব আগেই পুরো মিটে গেছে';
  if (round2(amount) > remaining) return `বাকির (${fmtNum(remaining)} টাকা) চেয়ে বেশি দেওয়া যাবে না`;
  if (!state.wallets.some((w) => w.id === input.walletId)) return 'ওয়ালেট বাছাই করুন';
  if (!DATE_RE.test(input.date || '')) return 'সঠিক তারিখ দিন';
  return null;
}

export function addSettlement(state, dueId, input) {
  const s = {
    id: uid('s'),
    dueId,
    amount: round2(input.amount),
    walletId: input.walletId,
    date: input.date,
    note: String(input.note || '').trim()
  };
  state.settlements.push(s);
  return s;
}

export function deleteSettlement(state, id) {
  state.settlements = state.settlements.filter((s) => s.id !== id);
}

export function settlementsOf(state, dueId) {
  return state.settlements
    .filter((s) => s.dueId === dueId)
    .sort((a, b) => (b.date || '').localeCompare(a.date || '') || (b.id || '').localeCompare(a.id || ''));
}

// ফিল্টার: kind, status ('open' | 'settled' | 'all'), q (নাম/নোট সার্চ)
export function filterDues(state, f, todayStr) {
  const q = (f.q || '').trim().toLowerCase();
  return state.dues.filter((d) => {
    if (d.kind !== f.kind) return false;
    const info = dueInfo(state, d, todayStr);
    if (f.status === 'open' && info.remaining <= 0) return false;
    if (f.status === 'settled' && info.remaining > 0) return false;
    if (q && !`${d.person} ${d.note || ''}`.toLowerCase().includes(q)) return false;
    return true;
  });
}

// ব্যক্তি অনুযায়ী গ্রুপ (বাকির বেশি আগে)
export function groupByPerson(state, dues, todayStr) {
  const map = new Map();
  for (const d of dues) {
    const key = d.person.trim().toLowerCase();
    if (!map.has(key)) map.set(key, { person: d.person.trim(), dues: [], remaining: 0 });
    const g = map.get(key);
    g.dues.push(d);
    g.remaining = round2(g.remaining + remainingOf(state, d));
  }
  const groups = [...map.values()];
  for (const g of groups) {
    g.dues.sort((a, b) => {
      const ra = remainingOf(state, a) > 0 ? 0 : 1;
      const rb = remainingOf(state, b) > 0 ? 0 : 1;
      return ra - rb || (b.date || '').localeCompare(a.date || '') || (b.id || '').localeCompare(a.id || '');
    });
  }
  return groups.sort((a, b) => b.remaining - a.remaining || a.person.localeCompare(b.person));
}

// নির্দিষ্ট ধরনের মোট বাকি, খোলা হিসাব ও মেয়াদোত্তীর্ণ সংখ্যা
export function kindTotals(state, kind, todayStr) {
  let remaining = 0;
  let openCount = 0;
  let overdue = 0;
  for (const d of state.dues) {
    if (d.kind !== kind) continue;
    const info = dueInfo(state, d, todayStr);
    if (info.remaining <= 0) continue;
    remaining += info.remaining;
    openCount += 1;
    if (info.overdue) overdue += 1;
  }
  return { remaining: round2(remaining), openCount, overdue };
}

export function knownPeople(state) {
  return [...new Set(state.dues.map((d) => d.person.trim()).filter(Boolean))];
}
