// চার্টের জন্য ডেটা হিসাব (UI-মুক্ত)
import { monthKey, shiftMonth } from '../utils/format.js';

const num = (v) => Number(v) || 0;
const round2 = (n) => Math.round(n * 100) / 100;

// ক্যাটাগরি অনুযায়ী ভাগ। বেশি হলে ছোটগুলো "অন্যান্য"-তে জমা হয়।
export function categoryBreakdown(state, month, type, maxItems = 7) {
  const map = new Map();
  let total = 0;
  for (const t of state.transactions) {
    if (t.type !== type || monthKey(t.date) !== month) continue;
    const name = t.category || 'অন্যান্য';
    map.set(name, round2((map.get(name) || 0) + num(t.amount)));
    total = round2(total + num(t.amount));
  }
  let items = [...map.entries()].map(([label, value]) => ({ label, value })).sort((a, b) => b.value - a.value);
  if (items.length > maxItems) {
    const rest = items.slice(maxItems - 1);
    items = items.slice(0, maxItems - 1);
    items.push({ label: 'অন্যান্য (বাকি)', value: round2(rest.reduce((s, x) => s + x.value, 0)) });
  }
  items = items.map((x) => ({ ...x, pct: total > 0 ? (x.value / total) * 100 : 0 }));
  return { total, items };
}

// endMonth সহ শেষ n মাসের আয়/ব্যয় (পুরনো থেকে নতুন ক্রমে)
export function monthlySeries(state, endMonth, n = 6) {
  const keys = [];
  for (let i = n - 1; i >= 0; i--) keys.push(shiftMonth(endMonth, -i));
  const rows = keys.map((key) => ({ key, income: 0, expense: 0, net: 0 }));
  const idx = new Map(keys.map((k, i) => [k, i]));
  for (const t of state.transactions) {
    const i = idx.get(monthKey(t.date));
    if (i === undefined) continue;
    if (t.type === 'income') rows[i].income = round2(rows[i].income + num(t.amount));
    else rows[i].expense = round2(rows[i].expense + num(t.amount));
  }
  for (const r of rows) r.net = round2(r.income - r.expense);
  return rows;
}

// মাসের দৈনিক ব্যয়। গড় = মোট ÷ (চলতি মাস হলে আজ পর্যন্ত দিন, নাহলে মাসের সব দিন)
export function dailyExpense(state, month, todayStr) {
  const [y, m] = month.split('-').map(Number);
  const daysInMonth = new Date(y, m, 0).getDate();
  const days = Array.from({ length: daysInMonth }, (_, i) => ({ day: i + 1, value: 0 }));
  let total = 0;
  for (const t of state.transactions) {
    if (t.type !== 'expense' || monthKey(t.date) !== month) continue;
    const d = Number(String(t.date).slice(8, 10));
    if (d >= 1 && d <= daysInMonth) {
      days[d - 1].value = round2(days[d - 1].value + num(t.amount));
      total = round2(total + num(t.amount));
    }
  }
  const isCurrent = monthKey(todayStr) === month;
  const elapsed = isCurrent ? Number(todayStr.slice(8, 10)) : daysInMonth;
  const avg = elapsed > 0 ? round2(total / elapsed) : 0;
  const max = days.reduce((best, d) => (d.value > best.value ? d : best), { day: 0, value: 0 });
  return { days, total, avg, max, daysInMonth, elapsed };
}
