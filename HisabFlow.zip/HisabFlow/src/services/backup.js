// JSON ব্যাকআপ তৈরি, যাচাই ও মার্জের লজিক (UI-মুক্ত, ব্রাউজার/Node দুই জায়গায় চলে)
import { DATA_VERSION, normalize } from '../models.js';

export const BACKUP_APP = 'HisabFlow';
export const BACKUP_FORMAT = 1;
const MAX_BYTES = 20 * 1024 * 1024;
const COLLECTIONS = ['wallets', 'transactions', 'dues', 'settlements', 'transfers'];
const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;
const MAX_ERRORS = 6;

export function countsOf(data) {
  return Object.fromEntries(COLLECTIONS.map((k) => [k, (data[k] || []).length]));
}

// ব্যাকআপ ফাইলের কাঠামো: হেডার + পুরো ডেটা
export function buildBackup(state, now = new Date()) {
  return {
    app: BACKUP_APP,
    format: BACKUP_FORMAT,
    exportedAt: now.toISOString(),
    counts: countsOf(state),
    data: state
  };
}

export function backupFilename(now = new Date()) {
  const p = (n) => String(n).padStart(2, '0');
  return `HisabFlow-backup-${now.getFullYear()}-${p(now.getMonth() + 1)}-${p(now.getDate())}-${p(now.getHours())}${p(now.getMinutes())}.json`;
}

export function serialize(backup) {
  return JSON.stringify(backup, null, 2);
}

const isObj = (v) => v && typeof v === 'object' && !Array.isArray(v);
const isStr = (v) => typeof v === 'string' && v.trim() !== '';
const isPos = (v) => typeof v === 'number' && isFinite(v) && v > 0 && v <= 1e12;

// ডেটার অখণ্ডতা যাচাই। ত্রুটির তালিকা ফেরত দেয় (ফাঁকা = ঠিক আছে)।
export function validateData(d) {
  const errors = [];
  const err = (msg) => { if (errors.length < MAX_ERRORS) errors.push(msg); };

  if (!isObj(d)) return ['ডেটার কাঠামো ঠিক নেই'];
  for (const k of COLLECTIONS) {
    if (!Array.isArray(d[k])) err(`"${k}" তালিকা পাওয়া যায়নি`);
  }
  if (errors.length) return errors;

  const unique = (list, label) => {
    const seen = new Set();
    list.forEach((x, i) => {
      if (!isObj(x) || !isStr(x.id)) { err(`${label} #${i + 1}: আইডি নেই`); return; }
      if (seen.has(x.id)) err(`${label} #${i + 1}: আইডি দুবার আছে`);
      seen.add(x.id);
    });
    return seen;
  };

  if (d.wallets.length === 0) err('অন্তত একটি ওয়ালেট থাকতে হবে');
  const walletIds = unique(d.wallets, 'ওয়ালেট');
  d.wallets.forEach((w, i) => {
    if (!isObj(w)) return;
    if (!isStr(w.name)) err(`ওয়ালেট #${i + 1}: নাম নেই`);
    if (w.openingBalance != null && !(typeof w.openingBalance === 'number' && isFinite(w.openingBalance))) err(`ওয়ালেট #${i + 1}: শুরুর ব্যালেন্স ঠিক নেই`);
  });

  unique(d.transactions, 'লেনদেন');
  d.transactions.forEach((t, i) => {
    if (!isObj(t)) return;
    const n = `লেনদেন #${i + 1}`;
    if (t.type !== 'income' && t.type !== 'expense') err(`${n}: ধরন ঠিক নেই`);
    if (!isPos(t.amount)) err(`${n}: পরিমাণ ঠিক নেই`);
    if (!walletIds.has(t.walletId)) err(`${n}: ওয়ালেট পাওয়া যায়নি`);
    if (!DATE_RE.test(t.date || '')) err(`${n}: তারিখ ঠিক নেই`);
    if (!isStr(t.category)) err(`${n}: ক্যাটাগরি নেই`);
  });

  const dueIds = unique(d.dues, 'দেনা-পাওনা');
  const dueAmount = new Map();
  d.dues.forEach((x, i) => {
    if (!isObj(x)) return;
    const n = `দেনা-পাওনা #${i + 1}`;
    if (x.kind !== 'receivable' && x.kind !== 'payable') err(`${n}: ধরন ঠিক নেই`);
    if (!isStr(x.person)) err(`${n}: নাম নেই`);
    if (!isPos(x.amount)) err(`${n}: পরিমাণ ঠিক নেই`);
    if (x.walletId && !walletIds.has(x.walletId)) err(`${n}: ওয়ালেট পাওয়া যায়নি`);
    if (!DATE_RE.test(x.date || '')) err(`${n}: তারিখ ঠিক নেই`);
    dueAmount.set(x.id, x.amount);
  });

  unique(d.settlements, 'শোধ/আদায়');
  const paid = new Map();
  d.settlements.forEach((s, i) => {
    if (!isObj(s)) return;
    const n = `শোধ/আদায় #${i + 1}`;
    if (!dueIds.has(s.dueId)) err(`${n}: মূল হিসাব পাওয়া যায়নি`);
    if (!isPos(s.amount)) err(`${n}: পরিমাণ ঠিক নেই`);
    if (!walletIds.has(s.walletId)) err(`${n}: ওয়ালেট পাওয়া যায়নি`);
    if (!DATE_RE.test(s.date || '')) err(`${n}: তারিখ ঠিক নেই`);
    paid.set(s.dueId, (paid.get(s.dueId) || 0) + (Number(s.amount) || 0));
  });
  for (const [id, sum] of paid) {
    if (dueAmount.has(id) && Math.round(sum * 100) > Math.round(dueAmount.get(id) * 100)) err('কোনো হিসাবে শোধ/আদায় মোট পরিমাণের চেয়ে বেশি');
  }

  unique(d.transfers, 'ট্রান্সফার');
  d.transfers.forEach((t, i) => {
    if (!isObj(t)) return;
    const n = `ট্রান্সফার #${i + 1}`;
    if (!walletIds.has(t.fromWalletId) || !walletIds.has(t.toWalletId)) err(`${n}: ওয়ালেট পাওয়া যায়নি`);
    else if (t.fromWalletId === t.toWalletId) err(`${n}: একই ওয়ালেটে ট্রান্সফার`);
    if (!isPos(t.amount)) err(`${n}: পরিমাণ ঠিক নেই`);
    if (t.fee != null && !(typeof t.fee === 'number' && isFinite(t.fee) && t.fee >= 0)) err(`${n}: ফি ঠিক নেই`);
    if (!DATE_RE.test(t.date || '')) err(`${n}: তারিখ ঠিক নেই`);
  });

  return errors;
}

// ফাইলের লেখা পড়ে যাচাই করে। ফেরত: { ok, errors, data, exportedAt, counts }
export function parseBackup(text) {
  const fail = (...errors) => ({ ok: false, errors });
  if (typeof text !== 'string' || text.trim() === '') return fail('ফাইলটি খালি');
  if (text.length > MAX_BYTES) return fail('ফাইলটি অনেক বড় (২০ MB-এর বেশি)');

  let obj;
  try {
    obj = JSON.parse(text);
  } catch {
    return fail('এটি বৈধ JSON ফাইল নয়, ফাইলটি নষ্ট বা অসম্পূর্ণ হতে পারে');
  }
  if (!isObj(obj)) return fail('এটি HisabFlow-এর ব্যাকআপ ফাইল নয়');

  let raw;
  let exportedAt = null;
  let declared = null;
  if (obj.app === BACKUP_APP && isObj(obj.data)) {
    raw = obj.data;
    exportedAt = typeof obj.exportedAt === 'string' ? obj.exportedAt : null;
    declared = isObj(obj.counts) ? obj.counts : null;
  } else if (Array.isArray(obj.wallets) && Array.isArray(obj.transactions)) {
    raw = obj; // হেডারবিহীন সরাসরি ডেটা
  } else {
    return fail('এটি HisabFlow-এর ব্যাকআপ ফাইল নয়');
  }

  if (typeof raw.version === 'number' && raw.version > DATA_VERSION) {
    return fail('এই ব্যাকআপ অ্যাপের নতুন ভার্সনে বানানো। আগে অ্যাপ আপডেট করুন।');
  }

  // শুধু জানা ফিল্ডগুলো রাখা হয়
  const picked = {
    version: raw.version,
    settings: isObj(raw.settings) ? raw.settings : {},
    categories: isObj(raw.categories) ? raw.categories : undefined,
    wallets: raw.wallets, transactions: raw.transactions, dues: raw.dues,
    settlements: raw.settlements, transfers: raw.transfers
  };
  // পুরনো ফাইলে transfers না থাকলে ফাঁকা ধরা হয়
  for (const k of COLLECTIONS) if (picked[k] === undefined && k !== 'wallets') picked[k] = [];

  const errors = validateData(picked);
  if (errors.length) return { ok: false, errors };

  const data = normalize(picked);
  const counts = countsOf(data);
  if (declared) {
    for (const k of COLLECTIONS) {
      if (typeof declared[k] === 'number' && declared[k] !== counts[k]) {
        return fail('ফাইলের তথ্য আর হেডারের সংখ্যা মিলছে না, ফাইলটি বদলে গেছে বা অসম্পূর্ণ');
      }
    }
  }
  return { ok: true, errors: [], data, exportedAt, counts };
}

// মার্জ: বর্তমান ডেটা অপরিবর্তিত থাকে, ব্যাকআপের শুধু নতুন আইডির রেকর্ড যোগ হয়
export function mergeData(current, incoming) {
  const merged = structuredClone(current);
  const added = {};
  for (const k of COLLECTIONS) {
    const have = new Set(merged[k].map((x) => x.id));
    added[k] = 0;
    for (const item of incoming[k]) {
      if (!have.has(item.id)) {
        merged[k].push(structuredClone(item));
        have.add(item.id);
        added[k] += 1;
      }
    }
  }
  for (const type of ['income', 'expense']) {
    const list = merged.categories[type] || (merged.categories[type] = []);
    for (const c of (incoming.categories && incoming.categories[type]) || []) {
      if (!list.includes(c)) list.push(c);
    }
  }
  return { merged, added, errors: validateData(merged) };
}
