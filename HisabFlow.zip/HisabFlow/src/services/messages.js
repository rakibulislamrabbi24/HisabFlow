// দেনা-পাওনার হিসাবের জন্য তৈরি মেসেজ (পরিষ্কার লেখা, সম্পাদনাযোগ্য)
import { fmtNum, fmtDateFull } from '../utils/format.js';
import { bnDigits } from './contacts.js';

const taka = (n) => `${fmtNum(n)} টাকা`;

// due = হিসাব, info = dueInfo(...), history = settlementsOf(...), profile = {name, phone}
export function buildDueMessage({ due, info, history, profile }) {
  const lines = [];
  const p = due.person;
  const whenText = due.date ? `${fmtDateFull(due.date)} তারিখের ` : '';
  const noteText = due.note ? ` (${due.note})` : '';

  if (due.kind === 'receivable') {
    if (info.remaining <= 0) {
      lines.push(`প্রিয় ${p}, আপনার কাছে আমার ${whenText}পাওনা ${taka(due.amount)} সম্পূর্ণ পরিশোধ হয়েছে। ধন্যবাদ।`);
    } else {
      lines.push(`প্রিয় ${p},`);
      lines.push(`আপনার কাছে আমার ${whenText}পাওনা ${taka(due.amount)}${noteText}।`);
      lines.push(info.paid > 0
        ? `এর মধ্যে ${taka(info.paid)} পেয়েছি, বাকি আছে ${taka(info.remaining)}।`
        : `বাকি আছে ${taka(info.remaining)}।`);
      if (due.dueDate) lines.push(`মেয়াদ: ${fmtDateFull(due.dueDate)}${info.overdue ? ' (পার হয়ে গেছে)' : ''}।`);
      lines.push('সুবিধামতো সময়ে পরিশোধ করলে উপকৃত হব। ধন্যবাদ।');
    }
  } else if (info.remaining <= 0) {
    lines.push(`প্রিয় ${p}, আপনার কাছ থেকে নেওয়া ${whenText}${taka(due.amount)} সম্পূর্ণ পরিশোধ করেছি। ধন্যবাদ।`);
  } else {
    lines.push(`প্রিয় ${p},`);
    lines.push(`আপনার কাছ থেকে ${whenText}নেওয়া ${taka(due.amount)}${noteText}।`);
    lines.push(info.paid > 0
      ? `এর মধ্যে ${taka(info.paid)} পরিশোধ করেছি, বাকি ${taka(info.remaining)}।`
      : `বাকি ${taka(info.remaining)}।`);
    lines.push(due.dueDate ? `${fmtDateFull(due.dueDate)} তারিখের মধ্যে বাকিটা পরিশোধ করব।` : 'বাকিটা দ্রুত পরিশোধ করব।');
    lines.push('ধন্যবাদ।');
  }

  if (info.paid > 0 && history.length) {
    lines.push('');
    lines.push(due.kind === 'receivable' ? 'আদায়ের তালিকা:' : 'পরিশোধের তালিকা:');
    for (const s of history.slice(0, 5)) lines.push(`• ${fmtDateFull(s.date)} — ${taka(s.amount)}`);
  }

  const name = (profile && profile.name) || '';
  const phone = profile && profile.phone ? bnDigits(profile.phone) : '';
  if (name || phone) {
    lines.push('');
    lines.push(`— ${[name, phone].filter(Boolean).join(', ')}`);
  }
  return lines.join('\n');
}
