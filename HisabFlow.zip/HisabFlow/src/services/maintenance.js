// নমুনা (demo) ডেটা পরিষ্কার: আগের ভার্সনে যোগ হওয়া demo:true রেকর্ড নিয়ে কাজ
const LISTS = ['transactions', 'dues', 'settlements', 'transfers'];

export function demoCounts(state) {
  const out = {};
  for (const k of LISTS) out[k] = (state[k] || []).filter((x) => x && x.demo).length;
  return out;
}

export function hasDemoData(state) {
  return Object.values(demoCounts(state)).some((n) => n > 0);
}

// নমুনা রেকর্ড মুছে ফেলা (ট্রান্সফারের ফি-এন্ট্রিসহ, কারণ সেগুলোও demo চিহ্নিত)
export function removeDemoData(state) {
  for (const k of LISTS) state[k] = (state[k] || []).filter((x) => !(x && x.demo));
}

// রেখে দেওয়া: demo চিহ্ন তুলে নিয়ে আসল ডেটা হিসেবে ধরা
export function keepDemoAsReal(state) {
  for (const k of LISTS) {
    for (const x of state[k] || []) if (x && x.demo) delete x.demo;
  }
}
