// ফোন নম্বর ও নাম যাচাই/ফরম্যাট (UI-মুক্ত)
const BN = '০১২৩৪৫৬৭৮৯';

export function toLatinDigits(s) {
  return String(s || '').replace(/[০-৯]/g, (d) => String(BN.indexOf(d)));
}

export function bnDigits(s) {
  return String(s || '').replace(/\d/g, (d) => BN[Number(d)]);
}

// "+৮৮০ ১৭১২-৩৪৫৬৭৮" → "01712345678"
export function normalizePhone(raw) {
  let p = toLatinDigits(raw).replace(/[\s\-().]/g, '');
  if (p.startsWith('+880')) p = '0' + p.slice(4);
  else if (p.startsWith('880')) p = '0' + p.slice(3);
  return p;
}

export function isValidPhone(p) {
  return /^01[3-9]\d{8}$/.test(p);
}

// ফাঁকা হলে ঠিক আছে (ঐচ্ছিক)। ভুল হলে বাংলা মেসেজ।
export function validatePhone(raw) {
  if (!String(raw || '').trim()) return null;
  return isValidPhone(normalizePhone(raw)) ? null : 'ফোন নম্বর ঠিক নেই (যেমন: ০১৭১২৩৪৫৬৭৮)';
}

// WhatsApp-এর জন্য দেশের কোডসহ নম্বর: 8801712345678
export function toWaNumber(raw) {
  const n = normalizePhone(raw);
  return isValidPhone(n) ? '88' + n : '';
}

export function validateProfile(input) {
  const name = String(input.name || '').trim();
  if (name.length > 30) return { error: 'নাম ৩০ অক্ষরের মধ্যে রাখুন' };
  const phoneErr = validatePhone(input.phone);
  if (phoneErr) return { error: phoneErr };
  const phone = String(input.phone || '').trim() ? normalizePhone(input.phone) : '';
  return { clean: { name, phone } };
}

export function initialOf(name) {
  const t = String(name || '').trim();
  return t ? Array.from(t)[0].toUpperCase() : '';
}

// নাম থেকে স্থির একটি রঙের মান (অ্যাভাটারের জন্য, 0-359)
export function hueOf(name) {
  let h = 0;
  for (const ch of String(name || '')) h = (h * 31 + ch.codePointAt(0)) % 360;
  return h;
}
