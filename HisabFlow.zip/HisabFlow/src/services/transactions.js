// আয়/ব্যয় লেনদেনের লজিক (UI-মুক্ত, state-এর উপর কাজ করে)
import { uid } from '../models.js';
import { monthKey } from '../utils/format.js';

// ইনপুট যাচাই: ঠিক থাকলে null, নাহলে বাংলা এরর মেসেজ
export function validateTx(input, state) {
  const amount = Number(input.amount);
  if (!input.amount && input.amount !== 0) return 'পরিমাণ লিখুন';
  if (!isFinite(amount) || amount <= 0) return 'পরিমাণ ০-এর বেশি হতে হবে';
  if (amount > 1e12) return 'পরিমাণ অনেক বেশি হয়ে গেছে';
  if (!input.category || !String(input.category).trim()) return 'ক্যাটাগরি বাছাই করুন';
  if (!state.wallets.some((w) => w.id === input.walletId)) return 'ওয়ালেট বাছাই করুন';
  if (!/^\d{4}-\d{2}-\d{2}$/.test(input.date || '')) return 'সঠিক তারিখ দিন';
  if (input.type !== 'income' && input.type !== 'expense') return 'আয় বা ব্যয় বাছাই করুন';
  return null;
}

// নতুন ক্যাটাগরি হলে তালিকায় যোগ করে
export function ensureCategory(state, type, name) {
  const list = state.categories[type] || (state.categories[type] = []);
  if (!list.includes(name)) list.push(name);
}

function clean(input) {
  return {
    type: input.type,
    amount: Math.round(Number(input.amount) * 100) / 100,
    category: String(input.category).trim(),
    walletId: input.walletId,
    date: input.date,
    note: String(input.note || '').trim()
  };
}

export function addTx(state, input) {
  const tx = { id: uid('t'), ...clean(input) };
  ensureCategory(state, tx.type, tx.category);
  state.transactions.push(tx);
  return tx;
}

export function updateTx(state, id, input) {
  const i = state.transactions.findIndex((t) => t.id === id);
  if (i < 0) return null;
  const old = state.transactions[i];
  const tx = { ...old, ...clean(input) }; // id ও demo চিহ্ন থেকে যায়
  ensureCategory(state, tx.type, tx.category);
  state.transactions[i] = tx;
  return tx;
}

export function deleteTx(state, id) {
  state.transactions = state.transactions.filter((t) => t.id !== id);
}

// ফিল্টার: month ('all' বা 'YYYY-MM'), type, category, walletId, q (সার্চ)
export function filterTx(state, f) {
  const q = (f.q || '').trim().toLowerCase();
  return state.transactions
    .filter((t) => (f.month === 'all' || monthKey(t.date) === f.month)
      && (f.type === 'all' || t.type === f.type)
      && (f.category === 'all' || t.category === f.category)
      && (f.walletId === 'all' || t.walletId === f.walletId)
      && (!q || `${t.note || ''} ${t.category || ''}`.toLowerCase().includes(q)))
    .sort((a, b) => (b.date || '').localeCompare(a.date || '') || (b.id || '').localeCompare(a.id || ''));
}

export function totals(list) {
  let income = 0;
  let expense = 0;
  for (const t of list) {
    if (t.type === 'income') income += Number(t.amount) || 0;
    else expense += Number(t.amount) || 0;
  }
  return { income, expense, net: income - expense };
}

// ফিল্টারের জন্য সব ক্যাটাগরি (তালিকা + আগের লেনদেনে ব্যবহৃত)
export function allCategories(state) {
  const set = new Set([
    ...(state.categories.income || []),
    ...(state.categories.expense || []),
    ...state.transactions.map((t) => t.category).filter(Boolean)
  ]);
  return [...set];
}
