// দেনা-পাওনার "ফটো কার্ড" (PNG) আঁকে। শুধু canvas ব্যবহার করে, কোনো প্যাকেজ লাগে না।
import { tr } from '../i18n/translate.js';

export const CARD_W = 1080;
export const CARD_H = 1440;
const FONT = '"Noto Sans Bengali", "Hind Siliguri", system-ui, sans-serif';

function font(ctx, size, weight = 400) {
  ctx.font = `${weight} ${size}px ${FONT}`;
}

function roundRect(ctx, x, y, w, h, r) {
  const rr = Math.min(r, w / 2, h / 2);
  ctx.beginPath();
  ctx.moveTo(x + rr, y);
  ctx.arcTo(x + w, y, x + w, y + h, rr);
  ctx.arcTo(x + w, y + h, x, y + h, rr);
  ctx.arcTo(x, y + h, x, y, rr);
  ctx.arcTo(x, y, x + w, y, rr);
  ctx.closePath();
}

// জায়গার বেশি হলে শেষে "…" দিয়ে ছোট করা
function fit(ctx, text, maxW) {
  let t = String(text || '');
  if (ctx.measureText(t).width <= maxW) return t;
  while (t.length > 1 && ctx.measureText(t + '…').width > maxW) t = t.slice(0, -1);
  return t + '…';
}

function text(ctx, str, x, y, { size = 32, weight = 400, color = '#1c1517', align = 'left', maxW = null } = {}) {
  font(ctx, size, weight);
  ctx.fillStyle = color;
  ctx.textAlign = align;
  ctx.textBaseline = 'alphabetic';
  const shown = tr(str);
  ctx.fillText(maxW ? fit(ctx, shown, maxW) : String(shown), x, y);
}

// data: { isReceivable, kindLabel, person, subline, remainingText, statusText, pct,
//         totalText, paidText, paidLabel, dueText, overdue, historyTitle, history:[{left,right}],
//         sender, brand }
export function drawDueCard(ctx, data, logo = null) {
  const W = CARD_W;
  const H = CARD_H;
  const accent = data.isReceivable ? '#16a34a' : '#dc2626';

  // ব্যাকগ্রাউন্ড
  const g = ctx.createLinearGradient(0, 0, W, H);
  g.addColorStop(0, '#c8102e');
  g.addColorStop(0.6, '#8e0b2e');
  g.addColorStop(1, '#590822');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, W, H);
  ctx.fillStyle = 'rgba(255,255,255,0.07)';
  ctx.beginPath(); ctx.arc(W - 120, 120, 260, 0, Math.PI * 2); ctx.fill();
  ctx.strokeStyle = 'rgba(231,184,102,0.35)';
  ctx.lineWidth = 3;
  ctx.beginPath(); ctx.arc(120, H - 80, 220, 0, Math.PI * 2); ctx.stroke();

  // হেডার: লোগো + নাম + ধরন
  if (logo) {
    ctx.save();
    roundRect(ctx, 64, 62, 96, 96, 24);
    ctx.clip();
    ctx.drawImage(logo, 64, 62, 96, 96);
    ctx.restore();
  }
  text(ctx, data.brand || 'HisabFlow', logo ? 184 : 64, 124, { size: 46, weight: 800, color: '#ffffff' });
  font(ctx, 30, 700);
  const pillW = Math.min(420, ctx.measureText(tr(data.kindLabel)).width + 64);
  ctx.fillStyle = 'rgba(255,255,255,0.18)';
  roundRect(ctx, W - 64 - pillW, 78, pillW, 64, 32);
  ctx.fill();
  text(ctx, data.kindLabel, W - 64 - pillW / 2, 120, { size: 30, weight: 700, color: '#ffffff', align: 'center' });

  // সাদা কার্ড
  const cx = 48;
  const cy = 210;
  const cw = W - 96;
  const ch = 1100;
  ctx.save();
  ctx.shadowColor = 'rgba(0,0,0,0.35)';
  ctx.shadowBlur = 40;
  ctx.shadowOffsetY = 16;
  ctx.fillStyle = '#ffffff';
  roundRect(ctx, cx, cy, cw, ch, 44);
  ctx.fill();
  ctx.restore();

  const px = cx + 56;
  const inner = cw - 112;

  text(ctx, data.person, px, cy + 108, { size: 62, weight: 800, maxW: inner });
  if (data.subline) text(ctx, data.subline, px, cy + 160, { size: 30, color: '#7b6f73', maxW: inner });

  text(ctx, 'বাকি', px, cy + 250, { size: 34, color: '#7b6f73' });
  text(ctx, data.remainingText, px, cy + 370, { size: 124, weight: 800, color: accent, maxW: inner });
  text(ctx, data.statusText, px, cy + 425, { size: 32, weight: 700, color: accent });

  // প্রগ্রেস বার
  const barY = cy + 460;
  ctx.fillStyle = '#eee8ea';
  roundRect(ctx, px, barY, inner, 26, 13);
  ctx.fill();
  const fillW = Math.max(0, Math.min(1, (data.pct || 0) / 100)) * inner;
  if (fillW > 0) {
    ctx.fillStyle = accent;
    roundRect(ctx, px, barY, Math.max(26, fillW), 26, 13);
    ctx.fill();
  }

  // তিনটি বক্স: মোট / পরিশোধ / বাকি
  const boxY = cy + 530;
  const gap = 24;
  const bw = (inner - gap * 2) / 3;
  const boxes = [
    ['মোট', data.totalText, '#1c1517'],
    [data.paidLabel, data.paidText, accent],
    ['বাকি', data.remainingText, '#1c1517']
  ];
  boxes.forEach(([label, value, color], i) => {
    const bx = px + i * (bw + gap);
    ctx.fillStyle = '#f6f3f4';
    roundRect(ctx, bx, boxY, bw, 140, 24);
    ctx.fill();
    text(ctx, label, bx + bw / 2, boxY + 48, { size: 26, color: '#7b6f73', align: 'center', maxW: bw - 20 });
    text(ctx, value, bx + bw / 2, boxY + 104, { size: 38, weight: 800, color, align: 'center', maxW: bw - 20 });
  });

  let y = boxY + 205;
  if (data.dueText) {
    text(ctx, data.dueText, px, y, { size: 32, weight: 700, color: data.overdue ? '#d97706' : '#7b6f73', maxW: inner });
    y += 70;
  }

  if (data.history && data.history.length) {
    text(ctx, data.historyTitle, px, y, { size: 30, weight: 700, color: '#1c1517' });
    y += 24;
    ctx.strokeStyle = '#eee8ea';
    ctx.lineWidth = 2;
    // কার্ডের ভেতরে যতগুলো সারি ধরে ততগুলোই দেখানো হয় (সর্বোচ্চ ৪)
    const limit = cy + ch - 36;
    const fitRows = Math.max(0, Math.floor((limit - (y + 52)) / 54) + 1);
    data.history.slice(0, Math.min(4, fitRows)).forEach((h, i) => {
      const ry = y + 52 + i * 54;
      text(ctx, h.left, px, ry, { size: 30, color: '#7b6f73', maxW: inner * 0.6 });
      text(ctx, h.right, px + inner, ry, { size: 32, weight: 700, color: accent, align: 'right' });
    });
  }

  // ফুটার
  if (data.sender) text(ctx, data.sender, W / 2, cy + ch + 56, { size: 32, weight: 600, color: '#ffffff', align: 'center', maxW: W - 120 });
  text(ctx, 'HisabFlow দিয়ে তৈরি', W / 2, H - 44, { size: 26, color: 'rgba(255,255,255,0.7)', align: 'center' });
}

function loadLogo(src = './icon.png') {
  return new Promise((resolve) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => resolve(null);
    img.src = src;
  });
}

// ফেরত: { dataUrl, base64 } — base64 অংশে "data:" প্রিফিক্স নেই
export async function makeDueCard(data) {
  const canvas = document.createElement('canvas');
  canvas.width = CARD_W;
  canvas.height = CARD_H;
  const ctx = canvas.getContext('2d');
  const logo = await loadLogo();
  drawDueCard(ctx, data, logo);
  const dataUrl = canvas.toDataURL('image/png');
  return { dataUrl, base64: dataUrl.split(',')[1] };
}
