// নির্ভরতা-মুক্ত ছোট SVG চার্ট জেনারেটর (ডোনাট, গ্রুপড বার, দৈনিক বার)
import { fmtNum, esc } from './format.js';
import { isEn } from '../i18n/core.js';

export const PALETTE = ['#c4222f', '#2563eb', '#d97706', '#7c3aed', '#0d9488', '#db2777', '#65a30d', '#64748b'];
const f = (n) => Math.round(n * 100) / 100;

// অক্ষের ছোট লেবেল: ১২০০০ → "১২ হা"
export function compact(n) {
  const v = Math.abs(Number(n) || 0);
  const sc = (x, suf) => fmtNum(Math.round(x * 10) / 10) + suf;
  if (isEn()) {
    if (v >= 1e9) return sc(v / 1e9, 'B');
    if (v >= 1e6) return sc(v / 1e6, 'M');
    if (v >= 1e3) return sc(v / 1e3, 'K');
    return fmtNum(v);
  }
  if (v >= 1e7) return sc(v / 1e7, ' কো');
  if (v >= 1e5) return sc(v / 1e5, ' লা');
  if (v >= 1e3) return sc(v / 1e3, ' হা');
  return fmtNum(v);
}

// অক্ষের সুন্দর সর্বোচ্চ মান (৪ ভাগে সমান ভাগ হয়)
export function niceMax(max) {
  if (!(max > 0)) return 100;
  const p = Math.pow(10, Math.floor(Math.log10(max)));
  for (const m of [1, 2, 4, 6, 8, 10]) if (m * p >= max) return m * p;
  return 10 * p;
}

// items: [{label, value, color}]
export function donut(items, { selected = -1, centerLabel = '', centerValue = '', ariaLabel = 'ডোনাট চার্ট' } = {}) {
  const R = 70;
  const C = 2 * Math.PI * R;
  const total = items.reduce((s, i) => s + i.value, 0);
  let acc = 0;
  let circles = '';
  items.forEach((it, idx) => {
    const len = total > 0 ? (it.value / total) * C : 0;
    const gap = items.length > 1 && len > 3 ? 1.5 : 0;
    const dash = Math.max(0, len - gap);
    const dim = selected >= 0 && selected !== idx;
    circles += `<circle class="seg" data-idx="${idx}" cx="100" cy="100" r="${R}" fill="none" stroke="${it.color}" `
      + `stroke-width="${selected === idx ? 34 : 28}" stroke-dasharray="${f(dash)} ${f(C - dash)}" `
      + `stroke-dashoffset="${f(-acc)}" opacity="${dim ? 0.3 : 1}" transform="rotate(-90 100 100)"/>`;
    acc += len;
  });
  return `<svg viewBox="0 0 200 200" class="chart donut" role="img" aria-label="${esc(ariaLabel)}">
    ${circles}
    <text x="100" y="95" text-anchor="middle" class="ch-sub">${esc(centerLabel)}</text>
    <text x="100" y="117" text-anchor="middle" class="ch-val">${esc(centerValue)}</text>
  </svg>`;
}

function gridAndAxis(W, H, L, R, T, B, top) {
  const plotH = H - T - B;
  let out = '';
  for (let i = 0; i <= 4; i++) {
    const y = f(T + plotH - (plotH * i) / 4);
    out += `<line x1="${L}" x2="${W - R}" y1="${y}" y2="${y}" class="ch-grid"/>`;
    out += `<text x="${L - 6}" y="${f(y + 3.5)}" text-anchor="end" class="ch-tick">${compact((top * i) / 4)}</text>`;
  }
  return out;
}

// groups: [{label, values:[আয়, ব্যয়]}]
export function groupedBars(groups, { colors = ['#1b8a3a', '#c4222f'], height = 200, ariaLabel = 'বার চার্ট' } = {}) {
  const W = 340, H = height, L = 46, R = 8, T = 12, B = 26;
  const plotW = W - L - R;
  const plotH = H - T - B;
  const max = Math.max(0, ...groups.flatMap((g) => g.values));
  const top = niceMax(max);
  let out = gridAndAxis(W, H, L, R, T, B, top);
  const gw = plotW / Math.max(1, groups.length);
  groups.forEach((g, gi) => {
    const cx = L + gw * gi + gw / 2;
    const bw = Math.min(20, gw * 0.3);
    g.values.forEach((v, vi) => {
      const h = v > 0 ? Math.max(1.5, (plotH * v) / top) : 0;
      const x = vi === 0 ? cx - bw - 1 : cx + 1;
      out += `<rect x="${f(x)}" y="${f(T + plotH - h)}" width="${f(bw)}" height="${f(h)}" rx="3" fill="${colors[vi]}"/>`;
    });
    out += `<text x="${f(cx)}" y="${H - 8}" text-anchor="middle" class="ch-tick">${esc(g.label)}</text>`;
  });
  return `<svg viewBox="0 0 ${W} ${H}" class="chart" role="img" aria-label="${esc(ariaLabel)}">${out}</svg>`;
}

// days: [{day, value}], avg: গড় রেখা
export function dailyBars(days, avg, { color = '#c4222f', height = 170, ariaLabel = 'দৈনিক ব্যয় চার্ট' } = {}) {
  const W = 340, H = height, L = 46, R = 8, T = 12, B = 26;
  const plotW = W - L - R;
  const plotH = H - T - B;
  const max = Math.max(0, ...days.map((d) => d.value));
  const top = niceMax(max);
  let out = gridAndAxis(W, H, L, R, T, B, top);
  const gw = plotW / Math.max(1, days.length);
  const bw = Math.max(2, gw * 0.68);
  days.forEach((d, i) => {
    const h = d.value > 0 ? Math.max(1.5, (plotH * d.value) / top) : 0;
    const x = L + gw * i + (gw - bw) / 2;
    if (h > 0) out += `<rect x="${f(x)}" y="${f(T + plotH - h)}" width="${f(bw)}" height="${f(h)}" rx="1.5" fill="${color}"/>`;
    const n = d.day;
    if (n === 1 || n % 5 === 0 || n === days.length) {
      out += `<text x="${f(L + gw * i + gw / 2)}" y="${H - 8}" text-anchor="middle" class="ch-tick">${fmtNum(n)}</text>`;
    }
  });
  if (avg > 0) {
    const y = f(T + plotH - (plotH * Math.min(avg, top)) / top);
    out += `<line x1="${L}" x2="${W - R}" y1="${y}" y2="${y}" class="ch-avg"/>`;
    out += `<text x="${W - R}" y="${f(y - 4)}" text-anchor="end" class="ch-avg-label">গড়</text>`;
  }
  return `<svg viewBox="0 0 ${W} ${H}" class="chart" role="img" aria-label="${esc(ariaLabel)}">${out}</svg>`;
}
