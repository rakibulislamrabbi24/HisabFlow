// ফাইল সেভ/শেয়ার ও ফাইল বাছাই (Android অ্যাপে নেটিভ, ব্রাউজারে সাধারণ ডাউনলোড)
import { Capacitor } from '@capacitor/core';
import { Filesystem, Directory, Encoding } from '@capacitor/filesystem';
import { Share } from '@capacitor/share';

// ফেরত: 'shared' | 'downloaded' | 'cancelled'
export async function saveAndShare(filename, text) {
  if (Capacitor.isNativePlatform()) {
    const written = await Filesystem.writeFile({
      path: filename,
      data: text,
      directory: Directory.Cache,
      encoding: Encoding.UTF8
    });
    try {
      await Share.share({
        title: 'HisabFlow ব্যাকআপ',
        text: 'HisabFlow ব্যাকআপ ফাইল',
        files: [written.uri],
        dialogTitle: 'ব্যাকআপ কোথায় সেভ করবেন?'
      });
      return 'shared';
    } catch (err) {
      if (/cancel/i.test(String(err && (err.message || err)))) return 'cancelled';
      throw err;
    }
  }
  const blob = new Blob([text], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
  return 'downloaded';
}

// ফাইল বাছাইয়ের ডায়ালগ খুলে বাছাই করা ফাইলের নাম ও লেখা ফেরত দেয় (বাতিল করলে null)
export function pickTextFile(accept = '.json,application/json') {
  return new Promise((resolve, reject) => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = accept;
    input.style.display = 'none';
    document.body.appendChild(input);
    const done = () => input.remove();
    input.addEventListener('change', async () => {
      const file = input.files && input.files[0];
      if (!file) { done(); resolve(null); return; }
      try {
        const text = await file.text();
        done();
        resolve({ name: file.name, size: file.size, text });
      } catch (err) {
        done();
        reject(err);
      }
    });
    input.addEventListener('cancel', () => { done(); resolve(null); });
    input.click();
  });
}

// ---- দেনা-পাওনা শেয়ারের জন্য ----

// ক্লিপবোর্ডে কপি। ফেরত: true/false
export async function copyText(text) {
  try {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      await navigator.clipboard.writeText(text);
      return true;
    }
  } catch {
    // নিচের বিকল্প পদ্ধতি চেষ্টা হবে
  }
  try {
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.setAttribute('readonly', '');
    ta.style.position = 'fixed';
    ta.style.opacity = '0';
    document.body.appendChild(ta);
    ta.select();
    const ok = document.execCommand('copy');
    ta.remove();
    return !!ok;
  } catch {
    return false;
  }
}

// ফেরত: 'shared' | 'cancelled' | 'copied'(শেয়ার সাপোর্ট না থাকলে কপি)
export async function shareText(text, title = 'HisabFlow') {
  if (Capacitor.isNativePlatform()) {
    try {
      await Share.share({ title, text, dialogTitle: 'হিসাব পাঠান' });
      return 'shared';
    } catch (err) {
      if (/cancel/i.test(String(err && (err.message || err)))) return 'cancelled';
      throw err;
    }
  }
  if (navigator.share) {
    try { await navigator.share({ title, text }); return 'shared'; } catch { return 'cancelled'; }
  }
  return (await copyText(text)) ? 'copied' : 'cancelled';
}

// PNG (base64) ফাইল বানিয়ে শেয়ার মেনু খোলে — সেখান থেকে গ্যালারি/ড্রাইভে সেভ বা অ্যাপে পাঠানো যায়
export async function shareImage(base64, filename, title = 'HisabFlow হিসাব') {
  if (Capacitor.isNativePlatform()) {
    const written = await Filesystem.writeFile({ path: filename, data: base64, directory: Directory.Cache });
    try {
      await Share.share({ title, files: [written.uri], dialogTitle: 'ছবি কোথায় সেভ/পাঠাবেন?' });
      return 'shared';
    } catch (err) {
      if (/cancel/i.test(String(err && (err.message || err)))) return 'cancelled';
      throw err;
    }
  }
  const a = document.createElement('a');
  a.href = 'data:image/png;base64,' + base64;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  return 'downloaded';
}

// ফোন কল/WhatsApp ইত্যাদি বাইরের অ্যাপে খোলা
export function openExternal(url) {
  if (url.startsWith('tel:')) { window.location.href = url; return; }
  window.open(url, '_blank');
}
