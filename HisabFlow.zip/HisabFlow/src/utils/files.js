// ফাইল সেভ/শেয়ার ও ফাইল বাছাই (Android অ্যাপে নেটিভ, ব্রাউজারে সাধারণ ডাউনলোড)
import { Capacitor } from '@capacitor/core';
import { Filesystem, Directory, Encoding } from '@capacitor/filesystem';
import { Share } from '@capacitor/share';

// ফেরত: 'shared' | 'downloaded' | 'cancelled'
export async function saveAndShare(filename, text) {
  if (Capacitor.isNativePlatform()) {
    const written = await Filesystem.writeFile({
      path: filename,
      data: text,
      directory: Directory.Cache,
      encoding: Encoding.UTF8
    });
    try {
      await Share.share({
        title: 'HisabFlow ব্যাকআপ',
        text: 'HisabFlow ব্যাকআপ ফাইল',
        files: [written.uri],
        dialogTitle: 'ব্যাকআপ কোথায় সেভ করবেন?'
      });
      return 'shared';
    } catch (err) {
      if (/cancel/i.test(String(err && (err.message || err)))) return 'cancelled';
      throw err;
    }
  }
  const blob = new Blob([text], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
  return 'downloaded';
}

// ফাইল বাছাইয়ের ডায়ালগ খুলে বাছাই করা ফাইলের নাম ও লেখা ফেরত দেয় (বাতিল করলে null)
export function pickTextFile(accept = '.json,application/json') {
  return new Promise((resolve, reject) => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = accept;
    input.style.display = 'none';
    document.body.appendChild(input);
    const done = () => input.remove();
    input.addEventListener('change', async () => {
      const file = input.files && input.files[0];
      if (!file) { done(); resolve(null); return; }
      try {
        const text = await file.text();
        done();
        resolve({ name: file.name, size: file.size, text });
      } catch (err) {
        done();
        reject(err);
      }
    });
    input.addEventListener('cancel', () => { done(); resolve(null); });
    input.click();
  });
}
