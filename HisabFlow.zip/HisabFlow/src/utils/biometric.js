// ফিঙ্গারপ্রিন্ট/ফেস আনলক (শুধু Android অ্যাপে; ব্রাউজারে বন্ধ থাকে)
import { Capacitor } from '@capacitor/core';
import { BiometricAuth } from '@aparajita/capacitor-biometric-auth';
import { withoutRelock } from '../lockState.js';

export async function biometricAvailable() {
  if (!Capacitor.isNativePlatform()) return false;
  try {
    const info = await BiometricAuth.checkBiometry();
    return !!info.isAvailable;
  } catch {
    return false;
  }
}

// সফল হলে true, বাতিল/ব্যর্থ হলে false
export async function biometricPrompt(reason = 'HisabFlow আনলক করুন') {
  try {
    await withoutRelock(() => BiometricAuth.authenticate({
      reason,
      cancelTitle: 'বাতিল',
      allowDeviceCredential: false,
      androidTitle: 'HisabFlow',
      androidSubtitle: reason,
      androidConfirmationRequired: false
    }));
    return true;
  } catch {
    return false;
  }
}
