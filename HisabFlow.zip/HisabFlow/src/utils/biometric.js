// ফিঙ্গারপ্রিন্ট আনলক: আপাতত বন্ধ রাখা হয়েছে (কারণ: প্লাগইনটি Gradle বিল্ড ভেঙে দিয়েছিল)।
// অ্যাপ লক এখন শুধু পিন দিয়ে চলে। ফিঙ্গারপ্রিন্ট ফেরাতে এই ফাইলের জায়গায়
// extras/biometric-with-plugin.js.txt বসাতে হবে এবং package.json-এ প্লাগইন যোগ করতে হবে।

export async function biometricAvailable() {
  return false;
}

export async function biometricPrompt() {
  return false;
}
