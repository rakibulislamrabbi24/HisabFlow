// ফরম্যাটিং ও তারিখ হেল্পার

import { isEn } from '../i18n/core.js';

// বর্তমান ভাষার লোকেল: বাংলা মোডে bn-BD, English মোডে en-US
const loc = () => (isEn() ? 'en-US' : 'bn-BD');

const nfCache = {};
function nf() {
  const l = loc();
  if (!nfCache[l]) {
    try {
      nfCache[l] = new Intl.NumberFormat(l, { maximumFractionDigits: 2 });
    } catch {
      nfCache[l] = new Intl.NumberFormat('en-US', { maximumFractionDigits: 2 });
    }
  }
  return nfCache[l];
}

export function fmtNum(n) {
  return nf().format(Number(n) || 0);
}

export function fmtMoney(n, currency = '৳') {
  const v = Number(n) || 0;
  const sign = v < 0 ? '-' : '';
  return `${sign}${currency}${fmtNum(Math.abs(v))}`;
}

// "2026-11-23" → "2026-11"
export function monthKey(dateStr) {
  return String(dateStr).slice(0, 7);
}

export function currentMonthKey() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
}

export function shiftMonth(key, delta) {
  const [y, m] = key.split('-').map(Number);
  const d = new Date(y, m - 1 + delta, 1);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
}

export function monthLabel(key) {
  const [y, m] = key.split('-').map(Number);
  const d = new Date(y, m - 1, 1);
  try {
    return d.toLocaleDateString(loc(), { month: 'long', year: 'numeric' });
  } catch {
    return key;
  }
}

export function fmtDate(dateStr) {
  const d = new Date(dateStr + 'T00:00:00');
  if (isNaN(d)) return dateStr;
  try {
    return d.toLocaleDateString(loc(), { day: 'numeric', month: 'short' });
  } catch {
    return dateStr;
  }
}

// ইউজারের লেখা টেক্সট HTML-এ বসানোর আগে নিরাপদ করা
export function esc(s) {
  return String(s ?? '').replace(/[&<>"']/g, (c) => (
    { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]
  ));
}

// "২৩ নভেম্বর, সোমবার" ধরনের লম্বা তারিখ
export function fmtDateLong(dateStr) {
  const d = new Date(dateStr + 'T00:00:00');
  if (isNaN(d)) return dateStr;
  try {
    return d.toLocaleDateString(loc(), { day: 'numeric', month: 'long', weekday: 'long' });
  } catch {
    return dateStr;
  }
}

// "নভে" ধরনের ছোট মাসের নাম (চার্টের লেবেলের জন্য)
export function monthShort(key) {
  const [y, m] = key.split('-').map(Number);
  const d = new Date(y, m - 1, 1);
  try {
    return d.toLocaleDateString(loc(), { month: 'short' });
  } catch {
    return String(m);
  }
}

// "২৩ নভেম্বর ২০২৬, ১০:৩০ AM" ধরনের তারিখ-সময় (ISO স্ট্রিং থেকে)
export function fmtDateTime(iso) {
  const d = new Date(iso);
  if (isNaN(d)) return String(iso || '');
  try {
    return d.toLocaleString(loc(), { day: 'numeric', month: 'long', year: 'numeric', hour: 'numeric', minute: '2-digit' });
  } catch {
    return d.toISOString();
  }
}

// "২৩ নভেম্বর ২০২৬" ধরনের পূর্ণ তারিখ
export function fmtDateFull(dateStr) {
  const d = new Date(dateStr + 'T00:00:00');
  if (isNaN(d)) return String(dateStr || '');
  try {
    return d.toLocaleDateString(loc(), { day: 'numeric', month: 'long', year: 'numeric' });
  } catch {
    return String(dateStr);
  }
}
