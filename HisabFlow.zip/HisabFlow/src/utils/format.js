// ফরম্যাটিং ও তারিখ হেল্পার

const nf = (() => {
  try {
    return new Intl.NumberFormat('bn-BD', { maximumFractionDigits: 2 });
  } catch {
    return new Intl.NumberFormat('en-US', { maximumFractionDigits: 2 });
  }
})();

export function fmtNum(n) {
  return nf.format(Number(n) || 0);
}

export function fmtMoney(n, currency = '৳') {
  const v = Number(n) || 0;
  const sign = v < 0 ? '-' : '';
  return `${sign}${currency}${fmtNum(Math.abs(v))}`;
}

// "2026-11-23" → "2026-11"
export function monthKey(dateStr) {
  return String(dateStr).slice(0, 7);
}

export function currentMonthKey() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
}

export function shiftMonth(key, delta) {
  const [y, m] = key.split('-').map(Number);
  const d = new Date(y, m - 1 + delta, 1);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
}

export function monthLabel(key) {
  const [y, m] = key.split('-').map(Number);
  const d = new Date(y, m - 1, 1);
  try {
    return d.toLocaleDateString('bn-BD', { month: 'long', year: 'numeric' });
  } catch {
    return key;
  }
}

export function fmtDate(dateStr) {
  const d = new Date(dateStr + 'T00:00:00');
  if (isNaN(d)) return dateStr;
  try {
    return d.toLocaleDateString('bn-BD', { day: 'numeric', month: 'short' });
  } catch {
    return dateStr;
  }
}

// ইউজারের লেখা টেক্সট HTML-এ বসানোর আগে নিরাপদ করা
export function esc(s) {
  return String(s ?? '').replace(/[&<>"']/g, (c) => (
    { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]
  ));
}
