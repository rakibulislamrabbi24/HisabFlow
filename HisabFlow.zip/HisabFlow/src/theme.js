// লাইট/ডার্ক থিম ও Android স্ট্যাটাস বারের রঙ
import { Capacitor } from '@capacitor/core';
import { StatusBar, Style } from '@capacitor/status-bar';

let mode = 'auto';
let override = null; // লক স্ক্রিনের মতো জায়গায় বিশেষ রঙ
const mq = typeof window !== 'undefined' && window.matchMedia ? window.matchMedia('(prefers-color-scheme: dark)') : null;

export function isDark() {
  return mode === 'dark' || (mode === 'auto' && !!(mq && mq.matches));
}

export async function syncStatusBar() {
  if (!Capacitor.isNativePlatform()) return;
  try {
    const cssBg = getComputedStyle(document.documentElement).getPropertyValue('--bg').trim();
    const color = override || (/^#[0-9a-fA-F]{6}$/.test(cssBg) ? cssBg : '#0D0A0B');
    await StatusBar.setBackgroundColor({ color });
    await StatusBar.setStyle({ style: override || isDark() ? Style.Dark : Style.Light });
  } catch {
    // কিছু ডিভাইসে সাপোর্ট না থাকলে চুপচাপ বাদ
  }
}

export function applyTheme(m = 'auto') {
  mode = m === 'light' || m === 'dark' ? m : 'auto';
  const root = document.documentElement;
  if (mode === 'auto') root.removeAttribute('data-theme');
  else root.setAttribute('data-theme', mode);
  syncStatusBar();
}

export function setStatusBarOverride(color) {
  override = color || null;
  syncStatusBar();
}

if (mq && mq.addEventListener) {
  mq.addEventListener('change', () => { if (mode === 'auto') syncStatusBar(); });
}
