// ফাইল বাছাই/শেয়ার/ফিঙ্গারপ্রিন্টের সময় অ্যাপ সাময়িক ব্যাকগ্রাউন্ডে যায়। তখন যেন আবার লক না হয়।
let suspendUntil = 0;

export function relockSuspended() {
  return Date.now() < suspendUntil;
}

export async function withoutRelock(fn) {
  suspendUntil = Date.now() + 20000; // শুরুতে ২০ সেকেন্ডের ছাড়, আটকে গেলেও নিজে শেষ হয়
  try {
    return await fn();
  } finally {
    suspendUntil = Date.now() + 1500; // কাজ শেষে একটু সময় (দেরিতে আসা ইভেন্টের জন্য)
  }
}
