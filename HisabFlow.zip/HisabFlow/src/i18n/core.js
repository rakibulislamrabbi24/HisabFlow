// ভাষা অবস্থা ('bn' = বাংলা, 'en' = English (US))। অন্য ফাইলগুলো এখান থেকে isEn() পড়ে।
export const LANGS = [
  { k: 'bn', label: 'বাংলা' },
  { k: 'en', label: 'English (US)' }
];

let lang = 'bn';
const listeners = new Set();

export function getLang() {
  return lang;
}

export function isEn() {
  return lang === 'en';
}

export function normalizeLang(v) {
  return v === 'en' ? 'en' : 'bn';
}

// শুধু অবস্থা বদলায় (DOM বদলানো translator-এর কাজ)
export function setLangValue(v) {
  lang = normalizeLang(v);
  if (typeof document !== 'undefined' && document.documentElement) {
    document.documentElement.lang = lang === 'en' ? 'en-US' : 'bn';
  }
}

export function onLangChange(fn) {
  listeners.add(fn);
  return () => listeners.delete(fn);
}

export function emitLangChange() {
  listeners.forEach((fn) => fn(lang));
}
