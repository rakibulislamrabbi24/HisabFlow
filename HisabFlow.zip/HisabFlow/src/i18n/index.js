// i18n-এর একমাত্র প্রবেশপথ
import { getLang, isEn, setLangValue, normalizeLang, onLangChange, emitLangChange, LANGS } from './core.js';
import { tr, translateEn } from './translate.js';
import { startDomTranslation, retranslateAll } from './dom.js';

export { getLang, isEn, onLangChange, LANGS, tr, translateEn, normalizeLang };

// অ্যাপ চালুর সময়: ভাষা বসানো ও স্বয়ংক্রিয় অনুবাদ শুরু
export function initLanguage(value) {
  setLangValue(value);
  startDomTranslation();
}

// ভাষা বদল: অবস্থা, পর্দা ও শুনছে এমন সবকিছু হালনাগাদ
export function switchLanguage(value) {
  setLangValue(value);
  retranslateAll();
  emitLangChange();
}
