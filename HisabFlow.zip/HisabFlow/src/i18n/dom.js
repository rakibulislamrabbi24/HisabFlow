// পর্দার লেখা নিজে থেকে অনুবাদ করে: DOM বদলালেই (MutationObserver) নতুন লেখা English হয়ে যায়।
import { isEn } from './core.js';
import { translateEn } from './translate.js';

const ATTRS = ['placeholder', 'aria-label', 'title', 'alt'];
const SKIP_TAGS = new Set(['SCRIPT', 'STYLE', 'TEXTAREA']);
const textState = new WeakMap(); // টেক্সট নোড → { orig, out }
const attrState = new WeakMap(); // এলিমেন্ট → { attr: { orig, out } }
let observer = null;

function processText(node) {
  const parent = node.parentNode;
  if (parent && SKIP_TAGS.has(parent.nodeName)) return;
  const v = node.nodeValue;
  const st = textState.get(node);
  if (!isEn()) {
    // বাংলা মোড: আগে অনুবাদ করা নোড থাকলে মূল লেখা ফিরিয়ে দেওয়া
    if (st) { if (v === st.out) node.nodeValue = st.orig; textState.delete(node); }
    return;
  }
  if (st && v === st.out) return; // এটি আমাদেরই আগের আউটপুট
  const out = translateEn(v);
  if (out !== v) { textState.set(node, { orig: v, out }); node.nodeValue = out; }
  else if (st) textState.delete(node);
}

function processAttrs(el) {
  for (const a of ATTRS) {
    if (!el.hasAttribute || !el.hasAttribute(a)) continue;
    const v = el.getAttribute(a);
    let map = attrState.get(el);
    const st = map && map[a];
    if (!isEn()) {
      if (st) { if (v === st.out) el.setAttribute(a, st.orig); delete map[a]; }
      continue;
    }
    if (st && v === st.out) continue;
    const out = translateEn(v);
    if (out !== v) {
      if (!map) { map = {}; attrState.set(el, map); }
      map[a] = { orig: v, out };
      el.setAttribute(a, out);
    } else if (st) delete map[a];
  }
}

function walk(root) {
  if (!root) return;
  if (root.nodeType === 3) { processText(root); return; }
  if (root.nodeType !== 1) return;
  processAttrs(root);
  const w = document.createTreeWalker(root, 1 | 4); // এলিমেন্ট + টেক্সট
  let n = w.nextNode();
  while (n) {
    if (n.nodeType === 3) processText(n); else processAttrs(n);
    n = w.nextNode();
  }
}

// পুরো পেজ আবার পার হয়ে বর্তমান ভাষায় আনা (ভাষা বদলের সময়)
export function retranslateAll() {
  walk(document.body);
  if (document.title !== undefined) document.title = 'HisabFlow';
}

export function startDomTranslation() {
  if (observer || typeof MutationObserver === 'undefined') return;
  observer = new MutationObserver((muts) => {
    for (const m of muts) {
      if (m.type === 'childList') m.addedNodes.forEach((n) => walk(n));
      else if (m.type === 'characterData') processText(m.target);
      else if (m.type === 'attributes') processAttrs(m.target);
    }
  });
  observer.observe(document.body, {
    childList: true, subtree: true, characterData: true, attributes: true, attributeFilter: ATTRS
  });
  retranslateAll();
}
