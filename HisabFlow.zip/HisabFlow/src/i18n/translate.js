// বাংলা → English অনুবাদ। বাংলা লেখা সোর্স হিসেবে থাকে; English মোডে পর্দার লেখা বদলে দেওয়া হয়।
// ব্যবহারকারীর নিজের লেখা (নাম, নোট) শুধু তখনই বদলায় যদি ঠিক অভিধানের শব্দের সাথে হুবহু মিলে যায়।
import { DICT, PATTERNS } from './en.js';
import { isEn } from './core.js';

const BN_ANY = /[\u0980-\u09FF]/;
const BN_LETTER = /[\u0980-\u09E5\u09F0-\u09F2\u09F4-\u09FF]/;
const BN_DIGITS = '০১২৩৪৫৬৭৮৯';

export function toLatin(s) {
  return String(s).replace(/[০-৯]/g, (d) => String(BN_DIGITS.indexOf(d)));
}

function lookup(core) {
  if (Object.prototype.hasOwnProperty.call(DICT, core)) return DICT[core];
  for (const [re, fn] of PATTERNS) {
    const m = re.exec(core);
    if (m) {
      const r = fn(...m.slice(1));
      if (r !== null && r !== undefined) return r;
    }
  }
  return null;
}

// একটি টুকরো: অভিধান → প্যাটার্ন → শেষের কোলন বাদ দিয়ে → " · " ভাগ করে
function translateCore(core) {
  let out = lookup(core);
  if (out !== null) return out;
  // বাংলা সংখ্যা থাকলে ল্যাটিন করে আবার চেষ্টা (প্যাটার্ন ল্যাটিন সংখ্যা ধরে)
  const latin = toLatin(core);
  if (latin !== core) {
    out = lookup(latin);
    if (out !== null) return out;
  }

  const colon = /^(.*?)\s*([:：])$/.exec(core);
  if (colon && colon[1]) {
    const r = lookup(colon[1]);
    if (r !== null) return r + ':';
  }

  if (/·/.test(core)) {
    const parts = core.split(/(\s*·\s*)/);
    let changed = false;
    const mapped = parts.map((p, i) => {
      if (i % 2 === 1 || !BN_LETTER.test(p)) return p;
      const lead = /^\s*/.exec(p)[0];
      const trail = /\s*$/.exec(p)[0];
      const r = translateCore(p.trim());
      if (r !== p.trim()) { changed = true; return lead + r + trail; }
      return p;
    });
    if (changed) return mapped.join('');
  }
  return core;
}

// পুরো লেখা (শুরু/শেষের ফাঁকা অংশ ঠিক রেখে) English-এ। বাংলা সংখ্যা সবসময় ল্যাটিন সংখ্যা হয়।
export function translateEn(raw) {
  const s = String(raw);
  if (!BN_ANY.test(s)) return s;
  let out = s;
  if (BN_LETTER.test(s)) {
    const lead = /^\s*/.exec(s)[0];
    const trail = /\s*$/.exec(s)[0];
    const core = s.trim();
    let body = translateCore(core);
    // অনূদিত অংশ বিরাম চিহ্ন দিয়ে শুরু হলে (যেমন ".") আগের ফাঁকা সরানো হয়
    const keepLead = /^[.,;:!?)]/.test(body) ? '' : lead;
    out = keepLead + body + trail;
  }
  return toLatin(out);
}

// কোড থেকে সরাসরি ব্যবহারের জন্য: বর্তমান ভাষা অনুযায়ী ফেরত দেয়
export function tr(str) {
  return isEn() ? translateEn(str) : String(str);
}

export function hasBengaliLetters(s) {
  return BN_LETTER.test(String(s));
}
