import './styles.css';
import { loadData, getState } from './store.js';
import { renderDashboard } from './ui/dashboard.js';
import { renderTransactions } from './ui/transactions.js';
import { renderDues } from './ui/dues.js';
import { renderWallets } from './ui/wallets.js';
import { renderSettings } from './ui/settings.js';
import { renderCharts } from './ui/charts.js';
import { icon } from './ui/icons.js';
import { applyTheme } from './theme.js';
import { initLanguage, onLangChange, tr } from './i18n/index.js';
import { App } from '@capacitor/app';
import { loadLock, getLock, lockEnabled } from './lockStore.js';
import { showLockScreen } from './ui/lockscreen.js';
import { relockSuspended } from './lockState.js';
import { shouldRelock } from './services/lockCore.js';
import { maybePromptDemoCleanup } from './ui/demoPrompt.js';

const routes = {
  dashboard: { title: 'ড্যাশবোর্ড', render: renderDashboard, greet: true },
  transactions: { title: 'লেনদেন', render: renderTransactions },
  dues: { title: 'দেনা-পাওনা', render: renderDues },
  wallets: { title: 'ওয়ালেট', render: renderWallets },
  settings: { title: 'সেটিংস', render: renderSettings },
  charts: { title: 'চার্ট ও বিশ্লেষণ', render: renderCharts }
};

const view = document.getElementById('view');
const titleEl = document.getElementById('page-title');
const subEl = document.getElementById('page-sub');
const lockBtn = document.getElementById('lock-now');
const navLinks = document.querySelectorAll('#nav a');

// ডেটা-আইকন বসানো (নেভিগেশন, টপ বার)
document.querySelectorAll('[data-icon]').forEach((el) => {
  el.innerHTML = icon(el.dataset.icon, { size: Number(el.dataset.size) || 23 });
});

function greeting() {
  const h = new Date().getHours();
  if (h >= 5 && h < 12) return 'শুভ সকাল';
  if (h >= 12 && h < 16) return 'শুভ দুপুর';
  if (h >= 16 && h < 18) return 'শুভ বিকেল';
  if (h >= 18 && h < 20) return 'শুভ সন্ধ্যা';
  return 'শুভ রাত্রি';
}

function currentRoute() {
  const name = location.hash.replace('#/', '');
  return routes[name] ? name : 'dashboard';
}

function navigate() {
  const name = currentRoute();
  const route = routes[name];
  titleEl.textContent = route.title;
  const myName = ((getState().settings.profile || {}).name || '').trim();
  subEl.textContent = route.greet ? tr(greeting()) + (myName ? ', ' + myName : '') : '';
  subEl.classList.toggle('hidden', !route.greet);
  lockBtn.classList.toggle('hidden', !lockEnabled()); // লক চালু থাকলে "এখনই লক" বাটন
  const navKey = name === 'charts' ? 'dashboard' : name; // চার্ট পেজে হোম ট্যাব জ্বলবে
  navLinks.forEach((a) => a.classList.toggle('active', a.dataset.route === navKey));

  view.classList.remove('enter');
  view.innerHTML = '';
  route.render(view);
  view.scrollTop = 0;
  void view.offsetWidth;
  view.classList.add('enter'); // পেজ বদলের সময় হালকা অ্যানিমেশন
}

// অ্যাপ ব্যাকগ্রাউন্ডে গিয়ে ফিরলে (সেটিং অনুযায়ী) আবার লক করা
function setupRelock() {
  let leftAt = null;
  App.addListener('appStateChange', async ({ isActive }) => {
    if (!isActive) {
      // ফাইল বাছাই/শেয়ার/ফিঙ্গারপ্রিন্টের সময় ছাড় দেওয়া হয়
      leftAt = relockSuspended() ? null : Date.now();
      return;
    }
    const t = leftAt;
    leftAt = null;
    if (shouldRelock(getLock(), t, Date.now())) await showLockScreen();
  });
}

async function init() {
  await loadData(); // স্টোরেজ ইনিশিয়ালাইজ
  initLanguage(getState().settings.language); // ভাষা বসানো ও স্বয়ংক্রিয় অনুবাদ চালু
  applyTheme(getState().settings.theme);
  await loadLock();
  window.addEventListener('hashchange', navigate);
  onLangChange(() => navigate()); // ভাষা বদলালে বর্তমান পেজ নতুন ভাষায় আবার আঁকা
  lockBtn.addEventListener('click', () => { if (lockEnabled()) showLockScreen(); });
  if (lockEnabled()) await showLockScreen(); // আনলক না হওয়া পর্যন্ত কোনো ডেটা দেখানো হয় না
  await maybePromptDemoCleanup(); // আগের ভার্সনের নমুনা ডেটা থাকলে একবার জিজ্ঞেস করা
  navigate();
  setupRelock();
}

init();
