import './styles.css';
import { loadData } from './store.js';
import { renderDashboard } from './ui/dashboard.js';
import { renderTransactions } from './ui/transactions.js';
import { renderDues } from './ui/dues.js';
import { renderWallets } from './ui/wallets.js';
import { renderSettings } from './ui/settings.js';
import { renderCharts } from './ui/charts.js';
import { App } from '@capacitor/app';
import { loadLock, getLock, lockEnabled } from './lockStore.js';
import { showLockScreen } from './ui/lockscreen.js';
import { relockSuspended } from './lockState.js';
import { shouldRelock } from './services/lockCore.js';

const routes = {
  dashboard: { title: 'ড্যাশবোর্ড', render: renderDashboard },
  transactions: { title: 'লেনদেন', render: renderTransactions },
  dues: { title: 'দেনা-পাওনা', render: renderDues },
  wallets: { title: 'ওয়ালেট', render: renderWallets },
  settings: { title: 'সেটিংস', render: renderSettings },
  charts: { title: 'চার্ট ও বিশ্লেষণ', render: renderCharts }
};

const view = document.getElementById('view');
const titleEl = document.getElementById('page-title');
const navLinks = document.querySelectorAll('#nav a');

function currentRoute() {
  const name = location.hash.replace('#/', '');
  return routes[name] ? name : 'dashboard';
}

function navigate() {
  const name = currentRoute();
  const route = routes[name];
  titleEl.textContent = route.title;
  const navKey = name === 'charts' ? 'dashboard' : name; // চার্ট পেজে হোম ট্যাব জ্বলবে
  navLinks.forEach((a) => a.classList.toggle('active', a.dataset.route === navKey));
  view.innerHTML = '';
  route.render(view);
  view.scrollTop = 0;
}

// অ্যাপ ব্যাকগ্রাউন্ডে গিয়ে ফিরলে (সেটিং অনুযায়ী) আবার লক করা
function setupRelock() {
  let leftAt = null;
  App.addListener('appStateChange', async ({ isActive }) => {
    if (!isActive) {
      // ফাইল বাছাই/শেয়ার/ফিঙ্গারপ্রিন্টের সময় ছাড় দেওয়া হয়
      leftAt = relockSuspended() ? null : Date.now();
      return;
    }
    const t = leftAt;
    leftAt = null;
    if (shouldRelock(getLock(), t, Date.now())) await showLockScreen();
  });
}

async function init() {
  await loadData(); // স্টোরেজ ইনিশিয়ালাইজ
  await loadLock();
  window.addEventListener('hashchange', navigate);
  if (lockEnabled()) await showLockScreen(); // আনলক না হওয়া পর্যন্ত কোনো ডেটা দেখানো হয় না
  navigate();
  setupRelock();
}

init();
