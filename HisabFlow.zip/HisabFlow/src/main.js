import './styles.css';
import { loadData } from './store.js';
import { renderDashboard } from './ui/dashboard.js';
import { renderTransactions } from './ui/transactions.js';
import { renderDues } from './ui/dues.js';
import { renderWallets } from './ui/wallets.js';
import { renderSettings } from './ui/settings.js';
import { renderCharts } from './ui/charts.js';

const routes = {
  dashboard: { title: 'ড্যাশবোর্ড', render: renderDashboard },
  transactions: { title: 'লেনদেন', render: renderTransactions },
  dues: { title: 'দেনা-পাওনা', render: renderDues },
  wallets: { title: 'ওয়ালেট', render: renderWallets },
  settings: { title: 'সেটিংস', render: renderSettings },
  charts: { title: 'চার্ট ও বিশ্লেষণ', render: renderCharts }
};

const view = document.getElementById('view');
const titleEl = document.getElementById('page-title');
const navLinks = document.querySelectorAll('#nav a');

function currentRoute() {
  const name = location.hash.replace('#/', '');
  return routes[name] ? name : 'dashboard';
}

function navigate() {
  const name = currentRoute();
  const route = routes[name];
  titleEl.textContent = route.title;
  const navKey = name === 'charts' ? 'dashboard' : name; // চার্ট পেজে হোম ট্যাব জ্বলবে
  navLinks.forEach((a) => a.classList.toggle('active', a.dataset.route === navKey));
  view.innerHTML = '';
  route.render(view);
  view.scrollTop = 0;
}

async function init() {
  await loadData(); // স্টোরেজ ইনিশিয়ালাইজ
  window.addEventListener('hashchange', navigate);
  navigate();
}

init();
