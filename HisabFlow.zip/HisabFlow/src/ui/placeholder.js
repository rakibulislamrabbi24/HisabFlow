// পরের ধাপগুলোর জন্য সাময়িক খালি পেজ
export function placeholder(container, icon, title, stepText) {
  container.innerHTML = `
    <div class="card empty">
      <div class="empty-ico">${icon}</div>
      <h2>${title}</h2>
      <p class="muted">${stepText}</p>
    </div>`;
}
