import { placeholder } from './placeholder.js';
export function renderTransactions(c) {
  placeholder(c, '🧾', 'আয়-ব্যয়', 'লেনদেন এন্ট্রি ও লিস্ট ধাপ ৩-এ যোগ হবে');
}
