import { getState, update } from '../store.js';
import { todayISO } from '../models.js';
import {
  addTx, updateTx, deleteTx, filterTx, totals, validateTx, allCategories
} from '../services/transactions.js';
import { openSheet, toast } from './modal.js';
import {
  fmtMoney, fmtNum, fmtDateLong, esc, currentMonthKey, shiftMonth, monthLabel
} from '../utils/format.js';

// ফিল্টারের অবস্থা (অন্য পেজে গিয়ে ফিরলেও থাকে)
const filters = { month: currentMonthKey(), type: 'all', category: 'all', walletId: 'all', q: '' };

export function renderTransactions(c) {
  const state = getState();
  const cats = allCategories(state);
  if (filters.category !== 'all' && !cats.includes(filters.category)) filters.category = 'all';
  if (filters.walletId !== 'all' && !state.wallets.some((w) => w.id === filters.walletId)) filters.walletId = 'all';

  c.innerHTML = `
    <section class="card filters">
      <div class="month-bar">
        <button class="icon-btn" id="f-prev" aria-label="আগের মাস">‹</button>
        <strong id="f-month"></strong>
        <button class="icon-btn" id="f-next" aria-label="পরের মাস">›</button>
      </div>
      <div class="chips" id="f-chips">
        <button class="chip" data-month="all">সব সময়</button>
        <button class="chip" data-type="all">সব</button>
        <button class="chip" data-type="income">আয়</button>
        <button class="chip" data-type="expense">ব্যয়</button>
      </div>
      <div class="grid2 filter-selects">
        <select id="f-cat" class="input">
          <option value="all">সব ক্যাটাগরি</option>
          ${cats.map((x) => `<option value="${esc(x)}">${esc(x)}</option>`).join('')}
        </select>
        <select id="f-wallet" class="input">
          <option value="all">সব ওয়ালেট</option>
          ${state.wallets.map((w) => `<option value="${esc(w.id)}">${esc(w.name)}</option>`).join('')}
        </select>
      </div>
      <input id="f-search" class="input" type="search" placeholder="নোট বা ক্যাটাগরি খুঁজুন…" />
    </section>
    <div id="tx-summary"></div>
    <div id="tx-list"></div>
    <button class="fab" id="tx-add" aria-label="নতুন লেনদেন">＋</button>
  `;

  const $ = (sel) => c.querySelector(sel);
  $('#f-cat').value = filters.category;
  $('#f-wallet').value = filters.walletId;
  $('#f-search').value = filters.q;

  function paint() {
    const st = getState();
    const cur = st.settings.currency;
    const m = (n) => fmtMoney(n, cur);
    const wname = Object.fromEntries(st.wallets.map((w) => [w.id, w.name]));

    // ফিল্টার বার
    const all = filters.month === 'all';
    $('#f-month').textContent = all ? 'সব সময়' : monthLabel(filters.month);
    $('#f-prev').disabled = all;
    $('#f-next').disabled = all || filters.month === currentMonthKey();
    c.querySelectorAll('#f-chips .chip').forEach((b) => {
      if (b.dataset.month) b.classList.toggle('active', all);
      if (b.dataset.type) b.classList.toggle('active', b.dataset.type === filters.type);
    });

    const list = filterTx(st, filters);
    const t = totals(list);

    $('#tx-summary').innerHTML = `
      <div class="summary-strip">
        <div><span>আয়</span><strong class="pos-text">${m(t.income)}</strong></div>
        <div><span>ব্যয়</span><strong class="neg-text">${m(t.expense)}</strong></div>
        <div><span>${fmtNum(list.length)}টি</span><strong class="${t.net < 0 ? 'neg-text' : ''}">${m(t.net)}</strong></div>
      </div>`;

    if (list.length === 0) {
      const none = st.transactions.length === 0;
      $('#tx-list').innerHTML = `
        <div class="card empty">
          <div class="empty-ico">🧾</div>
          <p class="muted">${none ? 'এখনও কোনো লেনদেন নেই। নিচের ＋ বাটনে চাপ দিয়ে প্রথম এন্ট্রি দিন।' : 'এই ফিল্টারে কোনো লেনদেন পাওয়া যায়নি।'}</p>
        </div>`;
      return;
    }

    // তারিখ অনুযায়ী গ্রুপ
    let html = '';
    let lastDate = '';
    for (const tx of list) {
      if (tx.date !== lastDate) {
        if (lastDate) html += '</ul></div>';
        html += `<div class="day-group"><div class="day-head">${fmtDateLong(tx.date)}</div><ul class="list card tx-list">`;
        lastDate = tx.date;
      }
      html += `
        <li class="tx-item" data-id="${esc(tx.id)}">
          <div class="tx-dot ${tx.type}">${tx.type === 'income' ? '↓' : '↑'}</div>
          <div class="tx-main">
            <div>${esc(tx.category)}</div>
            <div class="muted small">${esc(wname[tx.walletId] || '—')}${tx.note ? ' · ' + esc(tx.note) : ''}</div>
          </div>
          <strong class="${tx.type === 'income' ? 'pos-text' : 'neg-text'}">
            ${tx.type === 'income' ? '+' : '-'}${m(tx.amount)}
          </strong>
        </li>`;
    }
    html += '</ul></div>';
    $('#tx-list').innerHTML = html;
  }

  // ---- ফিল্টার ইভেন্ট ----
  $('#f-prev').addEventListener('click', () => {
    if (filters.month !== 'all') filters.month = shiftMonth(filters.month, -1);
    paint();
  });
  $('#f-next').addEventListener('click', () => {
    if (filters.month !== 'all' && filters.month !== currentMonthKey()) filters.month = shiftMonth(filters.month, 1);
    paint();
  });
  $('#f-chips').addEventListener('click', (e) => {
    const b = e.target.closest('.chip');
    if (!b) return;
    if (b.dataset.month) filters.month = filters.month === 'all' ? currentMonthKey() : 'all';
    if (b.dataset.type) filters.type = b.dataset.type;
    paint();
  });
  $('#f-cat').addEventListener('change', (e) => { filters.category = e.target.value; paint(); });
  $('#f-wallet').addEventListener('change', (e) => { filters.walletId = e.target.value; paint(); });
  $('#f-search').addEventListener('input', (e) => { filters.q = e.target.value; paint(); });

  $('#tx-list').addEventListener('click', (e) => {
    const li = e.target.closest('.tx-item');
    if (!li) return;
    const tx = getState().transactions.find((x) => x.id === li.dataset.id);
    if (tx) openForm(tx, paint);
  });
  $('#tx-add').addEventListener('click', () => openForm(null, paint));

  paint();
}

// ---- এন্ট্রি/এডিট ফর্ম (বটম শিট) ----
function openForm(tx, afterSave) {
  const state = getState();
  const isEdit = !!tx;
  let type = tx ? tx.type : 'expense';

  const sheet = openSheet(`
    <div class="sheet-head">
      <h2>${isEdit ? 'লেনদেন এডিট' : 'নতুন লেনদেন'}</h2>
      <button class="icon-btn" data-close aria-label="বন্ধ">✕</button>
    </div>
    <div class="seg" id="f-type">
      <button data-type="expense">ব্যয়</button>
      <button data-type="income">আয়</button>
    </div>
    <label class="field"><span>পরিমাণ</span>
      <input id="f-amount" class="input big" type="number" inputmode="decimal" step="any" min="0" placeholder="0" />
    </label>
    <label class="field"><span>ক্যাটাগরি</span><select id="f-category" class="input"></select></label>
    <label class="field hidden" id="f-newcat-wrap"><span>নতুন ক্যাটাগরির নাম</span>
      <input id="f-newcat" class="input" type="text" maxlength="30" />
    </label>
    <label class="field"><span>ওয়ালেট</span>
      <select id="f-walletsel" class="input">
        ${state.wallets.map((w) => `<option value="${esc(w.id)}">${esc(w.name)}</option>`).join('')}
      </select>
    </label>
    <label class="field"><span>তারিখ</span><input id="f-date" class="input" type="date" /></label>
    <label class="field"><span>নোট (ঐচ্ছিক)</span><input id="f-note" class="input" type="text" maxlength="120" /></label>
    <div class="error" id="f-error"></div>
    <div class="btn-row">
      <button class="btn" id="f-save">${isEdit ? 'আপডেট করুন' : 'সেভ করুন'}</button>
      ${isEdit ? '<button class="btn btn-danger" id="f-del">মুছুন</button>' : ''}
    </div>
  `);

  const q = (s) => sheet.el.querySelector(s);
  const amountEl = q('#f-amount');
  const catEl = q('#f-category');
  const newCatWrap = q('#f-newcat-wrap');
  const newCatEl = q('#f-newcat');
  const walletEl = q('#f-walletsel');
  const dateEl = q('#f-date');
  const noteEl = q('#f-note');
  const errEl = q('#f-error');

  function fillCategories(selected) {
    const list = [...(state.categories[type] || [])];
    if (selected && !list.includes(selected)) list.push(selected);
    catEl.innerHTML = list.map((x) => `<option value="${esc(x)}">${esc(x)}</option>`).join('')
      + '<option value="__new__">＋ নতুন ক্যাটাগরি…</option>';
    catEl.value = selected && list.includes(selected) ? selected : (list[0] || '__new__');
    toggleNewCat();
  }
  function toggleNewCat() {
    newCatWrap.classList.toggle('hidden', catEl.value !== '__new__');
  }
  function paintType() {
    sheet.el.querySelectorAll('#f-type button').forEach((b) => {
      b.classList.toggle('active', b.dataset.type === type);
      b.classList.toggle('income', b.dataset.type === 'income');
      b.classList.toggle('expense', b.dataset.type === 'expense');
    });
  }

  // শুরুর মান
  amountEl.value = tx ? tx.amount : '';
  walletEl.value = tx ? tx.walletId : (state.wallets[0] && state.wallets[0].id);
  dateEl.value = tx ? tx.date : todayISO();
  noteEl.value = tx ? (tx.note || '') : '';
  paintType();
  fillCategories(tx ? tx.category : null);

  q('#f-type').addEventListener('click', (e) => {
    const b = e.target.closest('button');
    if (!b || b.dataset.type === type) return;
    type = b.dataset.type;
    paintType();
    fillCategories(null);
  });
  catEl.addEventListener('change', toggleNewCat);

  q('#f-save').addEventListener('click', async () => {
    const category = catEl.value === '__new__' ? newCatEl.value.trim() : catEl.value;
    const input = {
      type,
      amount: amountEl.value === '' ? '' : Number(amountEl.value),
      category,
      walletId: walletEl.value,
      date: dateEl.value,
      note: noteEl.value
    };
    const err = validateTx(input, getState());
    if (err) { errEl.textContent = err; return; }
    await update((s) => { if (isEdit) updateTx(s, tx.id, input); else addTx(s, input); });
    sheet.close();
    toast(isEdit ? 'আপডেট হয়েছে' : 'সেভ হয়েছে');
    afterSave();
  });

  const delBtn = q('#f-del');
  if (delBtn) {
    let armed = false;
    delBtn.addEventListener('click', async () => {
      if (!armed) {
        armed = true;
        delBtn.textContent = 'নিশ্চিত? আবার চাপুন';
        setTimeout(() => { armed = false; delBtn.textContent = 'মুছুন'; }, 3000);
        return;
      }
      await update((s) => deleteTx(s, tx.id));
      sheet.close();
      toast('মুছে ফেলা হয়েছে');
      afterSave();
    });
  }
}
