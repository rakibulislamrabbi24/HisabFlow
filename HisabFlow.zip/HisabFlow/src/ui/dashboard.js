import { getState } from '../store.js';
import { todayISO } from '../models.js';
import {
  netBalance, monthSummary, duesSummary, walletBalances, recentTransactions
} from '../services/summary.js';
import {
  fmtMoney, fmtNum, fmtDate, esc, currentMonthKey, shiftMonth, monthLabel
} from '../utils/format.js';

let selectedMonth = currentMonthKey();

export function renderDashboard(container) {
  const state = getState();
  const cur = state.settings.currency;
  const m = (n) => fmtMoney(n, cur);

  const net = netBalance(state);
  const ms = monthSummary(state, selectedMonth);
  const ds = duesSummary(state, todayISO());
  const wallets = walletBalances(state);
  const recent = recentTransactions(state, 5);

  const total = ds.receivable + ds.payable;
  const recvPct = total > 0 ? Math.round((ds.receivable / total) * 100) : 50;
  const isCurrent = selectedMonth === currentMonthKey();

  container.innerHTML = `
    <section class="hero">
      <div class="hero-label">নেট ব্যালেন্স</div>
      <div class="hero-amount ${net < 0 ? 'neg' : ''}">${m(net)}</div>
      <div class="hero-sub">সব ওয়ালেট মিলিয়ে</div>
    </section>

    <section class="card">
      <div class="month-bar">
        <button class="icon-btn" id="m-prev" aria-label="আগের মাস">‹</button>
        <strong>${monthLabel(selectedMonth)}</strong>
        <button class="icon-btn" id="m-next" aria-label="পরের মাস" ${isCurrent ? 'disabled' : ''}>›</button>
      </div>
      <div class="grid2">
        <div class="stat income">
          <span class="stat-label">আয়</span>
          <span class="stat-value">${m(ms.income)}</span>
        </div>
        <div class="stat expense">
          <span class="stat-label">ব্যয়</span>
          <span class="stat-value">${m(ms.expense)}</span>
        </div>
      </div>
      <div class="saving ${ms.saving < 0 ? 'neg' : 'pos'}">
        ${ms.saving >= 0 ? 'মাসের সঞ্চয়' : 'মাসের ঘাটতি'}: <strong>${m(Math.abs(ms.saving))}</strong>
      </div>
    </section>

    <a class="link-card" href="#/charts"><span>📊 চার্ট ও বিশ্লেষণ দেখুন</span><span>›</span></a>

    <section class="card">
      <h2>পাওনা বনাম দেনা</h2>
      <div class="grid2">
        <div class="stat income">
          <span class="stat-label">পাওনা (পাবো)</span>
          <span class="stat-value">${m(ds.receivable)}</span>
        </div>
        <div class="stat expense">
          <span class="stat-label">দেনা (দেবো)</span>
          <span class="stat-value">${m(ds.payable)}</span>
        </div>
      </div>
      <div class="bar" title="পাওনা ${recvPct}% / দেনা ${100 - recvPct}%">
        <div class="bar-recv" style="width:${recvPct}%"></div>
      </div>
      <div class="bar-legend">
        <span>পাওনা ${fmtNum(recvPct)}%</span>
        <span>দেনা ${fmtNum(100 - recvPct)}%</span>
      </div>
      <div class="muted small dues-note">
        খোলা হিসাব ${fmtNum(ds.openCount)}টি${ds.overdue ? ` · <span class="warn">মেয়াদোত্তীর্ণ ${fmtNum(ds.overdue)}টি</span>` : ''}
        · নিট ${m(ds.net)}
      </div>
    </section>

    <section class="card">
      <h2>ওয়ালেট</h2>
      <ul class="list">
        ${wallets.map((x) => `
          <li><span>${esc(x.wallet.name)}</span>
          <strong class="${x.balance < 0 ? 'neg-text' : ''}">${m(x.balance)}</strong></li>`).join('')}
      </ul>
    </section>

    <section class="card">
      <h2>সাম্প্রতিক লেনদেন</h2>
      ${recent.length === 0
        ? '<p class="muted small">এখনও কোনো লেনদেন নেই। লেনদেন এন্ট্রি ধাপ ৩-এ আসবে। এখন চাইলে সেটিংস থেকে ডেমো ডেটা যোগ করে দেখতে পারেন।</p>'
        : `<ul class="list">${recent.map((t) => `
          <li>
            <div>
              <div>${esc(t.category || (t.type === 'income' ? 'আয়' : 'ব্যয়'))}</div>
              <div class="muted small">${fmtDate(t.date)}${t.note ? ' · ' + esc(t.note) : ''}</div>
            </div>
            <strong class="${t.type === 'income' ? 'pos-text' : 'neg-text'}">
              ${t.type === 'income' ? '+' : '-'}${m(t.amount)}
            </strong>
          </li>`).join('')}</ul>`}
    </section>
  `;

  container.querySelector('#m-prev').addEventListener('click', () => {
    selectedMonth = shiftMonth(selectedMonth, -1);
    renderDashboard(container);
  });
  const next = container.querySelector('#m-next');
  next.addEventListener('click', () => {
    if (selectedMonth === currentMonthKey()) return;
    selectedMonth = shiftMonth(selectedMonth, 1);
    renderDashboard(container);
  });
}
