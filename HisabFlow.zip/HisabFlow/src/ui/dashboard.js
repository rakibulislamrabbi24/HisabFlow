import { placeholder } from './placeholder.js';
export function renderDashboard(c) {
  placeholder(c, '🏠', 'ড্যাশবোর্ড', 'সামারি কার্ড ধাপ ২-এ যোগ হবে');
}
