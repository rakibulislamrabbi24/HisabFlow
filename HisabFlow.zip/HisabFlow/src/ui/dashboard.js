import { getState } from '../store.js';
import { todayISO } from '../models.js';
import {
  netBalance, monthSummary, duesSummary, walletBalances, recentTransactions
} from '../services/summary.js';
import { WALLET_TYPES } from '../services/wallets.js';
import { requestQuickAdd } from './transactions.js';
import { requestTransfer } from './wallets.js';
import { icon } from './icons.js';
import {
  fmtMoney, fmtNum, fmtDate, esc, currentMonthKey, shiftMonth, monthLabel
} from '../utils/format.js';

let selectedMonth = currentMonthKey();

export function renderDashboard(container) {
  const state = getState();
  const cur = state.settings.currency;
  const m = (n) => fmtMoney(n, cur);

  const net = netBalance(state);
  const ms = monthSummary(state, selectedMonth);
  const ds = duesSummary(state, todayISO());
  const wallets = walletBalances(state);
  const recent = recentTransactions(state, 5);
  const wname = Object.fromEntries(state.wallets.map((w) => [w.id, w.name]));

  const total = ds.receivable + ds.payable;
  const recvPct = total > 0 ? Math.round((ds.receivable / total) * 100) : 50;
  const isCurrent = selectedMonth === currentMonthKey();

  // আয়ের তুলনায় ব্যয়ের অনুপাত
  const hasFlow = ms.income > 0 || ms.expense > 0;
  const spendPct = ms.income > 0 ? Math.min(100, Math.round((ms.expense / ms.income) * 100)) : 100;
  const ratioNote = ms.income > 0
    ? `আয়ের ${fmtNum(Math.round((ms.expense / ms.income) * 100))}% ব্যয় হয়েছে`
    : 'এই মাসে কোনো আয় নেই, শুধু ব্যয় হয়েছে';

  container.innerHTML = `
    <section class="hero">
      <div class="hero-top">
        <span class="hero-label">নেট ব্যালেন্স</span>
        <span class="hero-chip">${fmtNum(wallets.length)}টি ওয়ালেট</span>
      </div>
      <div class="hero-amount ${net < 0 ? 'neg' : ''}">${m(net)}</div>
      <div class="hero-sub">সব ওয়ালেট মিলিয়ে</div>
    </section>

    <section class="quick">
      <button class="qa" data-qa="income" type="button"><span class="qa-ic income">${icon('arrow-down-left', { size: 24 })}</span>আয়</button>
      <button class="qa" data-qa="expense" type="button"><span class="qa-ic expense">${icon('arrow-up-right', { size: 24 })}</span>ব্যয়</button>
      <button class="qa" data-qa="transfer" type="button"><span class="qa-ic info">${icon('swap', { size: 22 })}</span>ট্রান্সফার</button>
      <button class="qa" data-qa="chart" type="button"><span class="qa-ic">${icon('chart', { size: 22 })}</span>চার্ট</button>
    </section>

    <section class="card">
      <div class="month-bar">
        <button class="icon-btn" id="m-prev" aria-label="আগের মাস">${icon('chevron-left', { size: 18 })}</button>
        <strong>${monthLabel(selectedMonth)}</strong>
        <button class="icon-btn" id="m-next" aria-label="পরের মাস" ${isCurrent ? 'disabled' : ''}>${icon('chevron-right', { size: 18 })}</button>
      </div>
      <div class="grid2">
        <div class="stat income">
          <span class="stat-ic">${icon('arrow-down-left', { size: 16 })}</span>
          <span class="stat-label">আয়</span>
          <span class="stat-value">${m(ms.income)}</span>
        </div>
        <div class="stat expense">
          <span class="stat-ic">${icon('arrow-up-right', { size: 16 })}</span>
          <span class="stat-label">ব্যয়</span>
          <span class="stat-value">${m(ms.expense)}</span>
        </div>
      </div>
      ${hasFlow ? `
        <div class="ratio"><div class="ratio-fill" style="width:${spendPct}%"></div></div>
        <div class="ratio-note">${ratioNote}</div>` : ''}
      <div class="saving ${ms.saving < 0 ? 'neg' : 'pos'}">
        ${ms.saving >= 0 ? 'মাসের সঞ্চয়' : 'মাসের ঘাটতি'}: <strong>${m(Math.abs(ms.saving))}</strong>
      </div>
    </section>

    <section class="card">
      <div class="section-head">
        <h2>${icon('users', { size: 20 })} পাওনা বনাম দেনা</h2>
        <a class="section-link" href="#/dues">বিস্তারিত ${icon('chevron-right', { size: 14 })}</a>
      </div>
      <div class="grid2">
        <div class="stat income">
          <span class="stat-ic">${icon('arrow-down-left', { size: 16 })}</span>
          <span class="stat-label">পাওনা (পাবো)</span>
          <span class="stat-value">${m(ds.receivable)}</span>
        </div>
        <div class="stat expense">
          <span class="stat-ic">${icon('arrow-up-right', { size: 16 })}</span>
          <span class="stat-label">দেনা (দেবো)</span>
          <span class="stat-value">${m(ds.payable)}</span>
        </div>
      </div>
      <div class="bar" title="পাওনা ${recvPct}% / দেনা ${100 - recvPct}%">
        <div class="bar-recv" style="width:${recvPct}%"></div>
      </div>
      <div class="bar-legend">
        <span>পাওনা ${fmtNum(recvPct)}%</span>
        <span>দেনা ${fmtNum(100 - recvPct)}%</span>
      </div>
      <div class="muted small dues-note">
        খোলা হিসাব ${fmtNum(ds.openCount)}টি${ds.overdue ? ` · <span class="warn">মেয়াদোত্তীর্ণ ${fmtNum(ds.overdue)}টি</span>` : ''}
        · নিট ${m(ds.net)}
      </div>
    </section>

    <section class="card">
      <div class="section-head">
        <h2>${icon('card', { size: 20 })} ওয়ালেট</h2>
        <a class="section-link" href="#/wallets">সব ${icon('chevron-right', { size: 14 })}</a>
      </div>
      <ul class="list">
        ${wallets.map((x) => {
          const t = WALLET_TYPES[x.wallet.type] || WALLET_TYPES.other;
          return `
          <li>
            <div class="wl-row">
              <span class="mini-ico" style="--wc-rgb:${t.rgb}">${icon(t.icon, { size: 18 })}</span>
              <span>${esc(x.wallet.name)}</span>
            </div>
            <strong class="${x.balance < 0 ? 'neg-text' : ''}">${m(x.balance)}</strong>
          </li>`;
        }).join('')}
      </ul>
    </section>

    <section class="card">
      <div class="section-head">
        <h2>${icon('receipt', { size: 20 })} সাম্প্রতিক লেনদেন</h2>
        <a class="section-link" href="#/transactions">সব ${icon('chevron-right', { size: 14 })}</a>
      </div>
      ${recent.length === 0 ? `
        <div class="empty">
          <div class="empty-ico">${icon('receipt', { size: 30 })}</div>
          <p class="muted">এখনও কোনো লেনদেন নেই।</p>
          <button class="btn" id="d-first" type="button">${icon('plus', { size: 18 })} প্রথম লেনদেন যোগ করুন</button>
        </div>`
        : `<ul class="list">${recent.map((t) => {
          const isFee = !!t.transferId;
          const kind = isFee ? 'fee' : t.type;
          const ic = isFee ? 'swap' : (t.type === 'income' ? 'arrow-down-left' : 'arrow-up-right');
          return `
          <li>
            <span class="tx-dot ${kind}">${icon(ic, { size: 18 })}</span>
            <div class="tx-main">
              <div>${esc(t.category || (t.type === 'income' ? 'আয়' : 'ব্যয়'))}</div>
              <div class="muted small">${esc(wname[t.walletId] || '—')} · ${fmtDate(t.date)}${t.note && !isFee ? ' · ' + esc(t.note) : ''}</div>
            </div>
            <strong class="${t.type === 'income' ? 'pos-text' : 'neg-text'}">
              ${t.type === 'income' ? '+' : '-'}${m(t.amount)}
            </strong>
          </li>`;
        }).join('')}</ul>`}
    </section>
  `;

  // মাস বদল
  container.querySelector('#m-prev').addEventListener('click', () => {
    selectedMonth = shiftMonth(selectedMonth, -1);
    renderDashboard(container);
  });
  container.querySelector('#m-next').addEventListener('click', () => {
    if (selectedMonth === currentMonthKey()) return;
    selectedMonth = shiftMonth(selectedMonth, 1);
    renderDashboard(container);
  });

  // দ্রুত অ্যাকশন
  container.querySelector('.quick').addEventListener('click', (e) => {
    const b = e.target.closest('.qa');
    if (!b) return;
    const a = b.dataset.qa;
    if (a === 'income' || a === 'expense') { requestQuickAdd(a); location.hash = '#/transactions'; }
    else if (a === 'transfer') { requestTransfer(); location.hash = '#/wallets'; }
    else if (a === 'chart') location.hash = '#/charts';
  });
  const first = container.querySelector('#d-first');
  if (first) first.addEventListener('click', () => { requestQuickAdd('expense'); location.hash = '#/transactions'; });
}
