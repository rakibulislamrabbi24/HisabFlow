import { createKeypad } from './keypad.js';
import { getLock, setLock, clearLock } from '../lockStore.js';
import {
  verifyPin, registerFail, registerSuccess, remainingLockMs, formatWait, FREE_ATTEMPTS
} from '../services/lockCore.js';
import { biometricPrompt } from '../utils/biometric.js';
import { resetEverything } from '../store.js';
import { fmtNum } from '../utils/format.js';
import { setStatusBarOverride } from '../theme.js';

let pending = null;

// লক স্ক্রিন দেখায়। আনলক হলে promise পূর্ণ হয়। আগে থেকে দেখানো থাকলে একই promise ফেরত দেয়।
export function showLockScreen() {
  if (pending) return pending;
  pending = new Promise((resolve) => {
    const overlay = document.createElement('div');
    overlay.className = 'lock-screen';
    overlay.innerHTML = `
      <div class="lock-inner" id="lk-main">
        <img src="./icon.png" class="lock-logo" alt="" />
        <h1>HisabFlow</h1>
        <p class="lock-sub">পিন দিয়ে আনলক করুন</p>
        <div id="lk-pad"></div>
        <button class="lock-link" id="lk-forgot" type="button">পিন ভুলে গেছেন?</button>
      </div>
      <div class="lock-inner hidden" id="lk-forgot-panel">
        <h2>পিন ভুলে গেলে</h2>
        <p class="lock-text">পিন উদ্ধার করার কোনো উপায় নেই, কারণ আপনার ডেটা শুধু এই ফোনেই থাকে।</p>
        <p class="lock-text">একমাত্র পথ হলো অ্যাপের <strong>সব ডেটা মুছে</strong> লক খুলে ফেলা। এরপর সেটিংস থেকে আপনার আগের <strong>ব্যাকআপ ফাইল রিস্টোর</strong> করতে পারবেন।</p>
        <p class="lock-text">ব্যাকআপ না থাকলে ডেটা ফিরবে না।</p>
        <button class="lock-btn danger" id="lk-reset" type="button">সব ডেটা মুছে লক খুলুন</button>
        <button class="lock-link" id="lk-back" type="button">‹ ফিরে যান</button>
      </div>`;
    document.body.appendChild(overlay);
    setStatusBarOverride('#b90f2b'); // স্ট্যাটাস বার লক স্ক্রিনের রঙে

    const $ = (s) => overlay.querySelector(s);
    let timer = null;
    let finished = false;

    function finish() {
      if (finished) return;
      finished = true;
      if (timer) clearInterval(timer);
      overlay.remove();
      setStatusBarOverride(null);
      pending = null;
      resolve();
    }

    const cfg0 = getLock();
    if (!cfg0 || !cfg0.enabled) { finish(); return; }

    const pad = createKeypad({
      length: cfg0.pinLength,
      onSubmit: attempt,
      onBiometric: cfg0.biometric ? tryBiometric : null
    });
    $('#lk-pad').appendChild(pad.el);

    function refresh(justFailed = false) {
      const cfg = getLock();
      const left = remainingLockMs(cfg, Date.now());
      if (left > 0) {
        pad.setDisabled(true);
        pad.message(`অনেকবার ভুল পিন। ${formatWait(left)} পরে আবার চেষ্টা করুন`, 'err');
        if (!timer) timer = setInterval(() => refresh(false), 1000);
        return;
      }
      if (timer) { clearInterval(timer); timer = null; }
      pad.setDisabled(false);
      if (!justFailed) { pad.message(''); return; }
      const triesLeft = FREE_ATTEMPTS - cfg.fails;
      pad.message(triesLeft > 0
        ? `ভুল পিন। আর ${fmtNum(triesLeft)} বার ভুল হলে কিছুক্ষণ অপেক্ষা করতে হবে`
        : 'ভুল পিন', 'err');
    }

    async function unlock() {
      const cfg = getLock();
      if (cfg && (cfg.fails || cfg.lockUntil)) await setLock(registerSuccess(cfg));
      finish();
    }

    async function attempt(pin) {
      let cfg = getLock();
      if (remainingLockMs(cfg, Date.now()) > 0) return;
      if (await verifyPin(cfg, pin)) { await unlock(); return; }
      cfg = registerFail(cfg, Date.now());
      await setLock(cfg);
      pad.shake();
      refresh(true);
    }

    async function tryBiometric() {
      if (remainingLockMs(getLock(), Date.now()) > 0) return;
      if (await biometricPrompt('HisabFlow আনলক করুন')) await unlock();
    }

    refresh(false);
    if (cfg0.biometric && remainingLockMs(cfg0, Date.now()) === 0) setTimeout(tryBiometric, 350);

    // ---- পিন ভুলে গেলে ----
    $('#lk-forgot').addEventListener('click', () => {
      $('#lk-main').classList.add('hidden');
      $('#lk-forgot-panel').classList.remove('hidden');
    });
    $('#lk-back').addEventListener('click', () => {
      $('#lk-forgot-panel').classList.add('hidden');
      $('#lk-main').classList.remove('hidden');
    });
    const resetBtn = $('#lk-reset');
    const resetLabel = resetBtn.textContent;
    let armed = false;
    resetBtn.addEventListener('click', async () => {
      if (!armed) {
        armed = true;
        resetBtn.textContent = 'নিশ্চিত? সব ডেটা মুছে যাবে। আবার চাপুন';
        setTimeout(() => { armed = false; resetBtn.textContent = resetLabel; }, 4000);
        return;
      }
      resetBtn.disabled = true;
      await resetEverything();
      await clearLock();
      window.location.reload();
    });
  });
  return pending;
}
