import { getLock, setLock, clearLock } from '../lockStore.js';
import {
  PIN_LENGTHS, TIMEOUTS, cryptoAvailable, makeLockConfig, verifyPin, registerFail, registerSuccess,
  remainingLockMs, formatWait, isWeakPin
} from '../services/lockCore.js';
import { createKeypad } from './keypad.js';
import { openSheet, toast } from './modal.js';
import { icon } from './icons.js';
import { biometricAvailable, biometricPrompt } from '../utils/biometric.js';
import { fmtNum } from '../utils/format.js';

// ---- নতুন পিন নেওয়া (দুইবার) ----
function askNewPin(length) {
  return new Promise((resolve) => {
    let first = null;
    let done = false;
    const sheet = openSheet(`
      <div class="sheet-head"><h2 id="pn-title">নতুন পিন দিন</h2><button class="icon-btn" data-close aria-label="বন্ধ">${icon('x', { size: 18 })}</button></div>
      <p class="muted small center" id="pn-sub">${fmtNum(length)} সংখ্যার পিন বেছে নিন</p>
      <div id="pn-pad"></div>`, { onClose: () => { if (!done) resolve(null); } });
    const title = sheet.el.querySelector('#pn-title');
    const sub = sheet.el.querySelector('#pn-sub');
    const pad = createKeypad({
      length,
      onSubmit: async (pin) => {
        if (first === null) {
          if (isWeakPin(pin)) { pad.shake(); pad.message('খুব সহজ পিন (যেমন ১২৩৪ বা ০০০০)। অন্য পিন দিন', 'err'); return; }
          first = pin;
          title.textContent = 'আবার একই পিন দিন';
          sub.textContent = 'নিশ্চিত করতে আরেকবার দিন';
          pad.message('');
          return;
        }
        if (pin === first) { done = true; sheet.close(); resolve(pin); return; }
        first = null;
        title.textContent = 'নতুন পিন দিন';
        sub.textContent = `${fmtNum(length)} সংখ্যার পিন বেছে নিন`;
        pad.shake();
        pad.message('দুইবার একই পিন হয়নি। আবার প্রথম থেকে দিন', 'err');
      }
    });
    sheet.el.querySelector('#pn-pad').appendChild(pad.el);
  });
}

// ---- বর্তমান পিন যাচাই (বদল/বন্ধ করার আগে) ----
function verifyCurrent(title) {
  return new Promise((resolve) => {
    let done = false;
    const cfg0 = getLock();
    const sheet = openSheet(`
      <div class="sheet-head"><h2>${title}</h2><button class="icon-btn" data-close aria-label="বন্ধ">${icon('x', { size: 18 })}</button></div>
      <p class="muted small center">বর্তমান পিন দিন</p>
      <div id="vc-pad"></div>`, { onClose: () => { if (!done) resolve(false); } });
    let timer = null;
    const pad = createKeypad({
      length: cfg0.pinLength,
      onSubmit: async (pin) => {
        let cfg = getLock();
        if (remainingLockMs(cfg) > 0) return;
        if (await verifyPin(cfg, pin)) {
          if (cfg.fails || cfg.lockUntil) await setLock(registerSuccess(cfg));
          done = true; sheet.close(); resolve(true); return;
        }
        cfg = registerFail(cfg);
        await setLock(cfg);
        pad.shake();
        tick(true);
      }
    });
    function tick(failed) {
      const left = remainingLockMs(getLock());
      if (left > 0) {
        pad.setDisabled(true);
        pad.message(`অনেকবার ভুল পিন। ${formatWait(left)} পরে আবার চেষ্টা করুন`, 'err');
        if (!timer) timer = setInterval(() => tick(false), 1000);
      } else {
        if (timer) { clearInterval(timer); timer = null; }
        pad.setDisabled(false);
        pad.message(failed ? 'ভুল পিন' : '', failed ? 'err' : '');
      }
    }
    sheet.el.querySelector('#vc-pad').appendChild(pad.el);
    tick(false);
  });
}

// সেটিংস পেজের ভেতরে "অ্যাপ লক" কার্ড বসায়
export async function renderAppLockSection(el, rerender) {
  const cfg = getLock();
  const enabled = !!(cfg && cfg.enabled);
  const bioOk = enabled ? await biometricAvailable() : false;

  if (!enabled) {
    el.innerHTML = `
      <div class="card">
        <h2>${icon('lock', { size: 20 })} অ্যাপ লক</h2>
        <p class="muted small">অ্যাপ খুলতে পিন (বা ফিঙ্গারপ্রিন্ট) চাইবে, যাতে অন্য কেউ আপনার হিসাব দেখতে না পারে।</p>
        <div class="btn-row"><button class="btn" id="al-enable">অ্যাপ লক চালু করুন</button></div>
        ${cryptoAvailable() ? '' : '<p class="warn small">এই ডিভাইসে নিরাপদ হ্যাশ সাপোর্ট নেই, তাই লক চালু করা যাবে না।</p>'}
      </div>`;
    const btn = el.querySelector('#al-enable');
    if (!cryptoAvailable()) btn.disabled = true;
    btn.addEventListener('click', () => chooseLengthThenSetup(rerender));
    return;
  }

  el.innerHTML = `
    <div class="card">
      <h2>${icon('lock', { size: 20 })} অ্যাপ লক <span class="badge settled">চালু</span></h2>
      <ul class="list">
        <li><span>পিন</span><span>${fmtNum(cfg.pinLength)} সংখ্যার</span></li>
        <li><span>আবার লক হবে</span>
          <select id="al-timeout" class="input inline-select">
            ${TIMEOUTS.map((t) => `<option value="${t.sec}" ${t.sec === cfg.timeoutSec ? 'selected' : ''}>${t.label}</option>`).join('')}
          </select>
        </li>
        ${bioOk ? `<li><span>ফিঙ্গারপ্রিন্ট আনলক</span>
          <button class="chip ${cfg.biometric ? 'active' : ''}" id="al-bio" type="button">${cfg.biometric ? 'চালু' : 'বন্ধ'}</button></li>` : ''}
      </ul>
      <div class="btn-row">
        <button class="btn btn-ghost" id="al-change">পিন বদলান</button>
        <button class="btn btn-ghost btn-danger-ghost" id="al-disable">লক বন্ধ করুন</button>
      </div>
      <p class="muted small">এটি গোপনীয়তার জন্য একটি পর্দা। ফোনে সেভ হওয়া ডেটা ফাইল আলাদা করে এনক্রিপ্ট করা নয়।</p>
    </div>`;

  const $ = (s) => el.querySelector(s);

  $('#al-timeout').addEventListener('change', async (e) => {
    await setLock({ ...getLock(), timeoutSec: Number(e.target.value) });
    toast('সেভ হয়েছে');
  });

  const bio = $('#al-bio');
  if (bio) bio.addEventListener('click', async () => {
    const cur = getLock();
    if (cur.biometric) {
      await setLock({ ...cur, biometric: false });
      toast('ফিঙ্গারপ্রিন্ট আনলক বন্ধ');
    } else if (await biometricPrompt('ফিঙ্গারপ্রিন্ট যাচাই করুন')) {
      await setLock({ ...cur, biometric: true });
      toast('ফিঙ্গারপ্রিন্ট আনলক চালু হয়েছে');
    } else {
      toast('ফিঙ্গারপ্রিন্ট যাচাই হয়নি');
      return;
    }
    rerender();
  });

  $('#al-change').addEventListener('click', async () => {
    if (!(await verifyCurrent('পিন বদলান'))) return;
    const cur = getLock();
    const pin = await askNewPin(cur.pinLength);
    if (!pin) return;
    await setLock(await makeLockConfig(pin, cur.pinLength, cur));
    toast('পিন বদলানো হয়েছে');
    rerender();
  });

  $('#al-disable').addEventListener('click', async () => {
    if (!(await verifyCurrent('লক বন্ধ করুন'))) return;
    await clearLock();
    toast('অ্যাপ লক বন্ধ করা হয়েছে');
    rerender();
  });
}

// পিনের দৈর্ঘ্য (৪/৬) বেছে নতুন পিন সেট করা
function chooseLengthThenSetup(rerender) {
  let length = PIN_LENGTHS[0];
  const sheet = openSheet(`
    <div class="sheet-head"><h2>অ্যাপ লক চালু করুন</h2><button class="icon-btn" data-close aria-label="বন্ধ">${icon('x', { size: 18 })}</button></div>
    <p class="muted small">কত সংখ্যার পিন চান?</p>
    <div class="seg" id="al-len">
      ${PIN_LENGTHS.map((n) => `<button data-len="${n}" class="${n === length ? 'active income' : ''}">${fmtNum(n)} সংখ্যা</button>`).join('')}
    </div>
    <p class="muted small">পিন মনে রাখুন। ভুলে গেলে উদ্ধারের উপায় নেই, শুধু সব ডেটা মুছে ব্যাকআপ থেকে রিস্টোর করতে হবে। তাই আগে একটি ব্যাকআপ নিয়ে রাখুন।</p>
    <div class="btn-row"><button class="btn" id="al-next">পরের ধাপ</button></div>`);
  const q = (s) => sheet.el.querySelector(s);
  q('#al-len').addEventListener('click', (e) => {
    const b = e.target.closest('button');
    if (!b) return;
    length = Number(b.dataset.len);
    q('#al-len').querySelectorAll('button').forEach((x) => x.classList.toggle('active', x === b));
    q('#al-len').querySelectorAll('button').forEach((x) => x.classList.toggle('income', x === b));
  });
  q('#al-next').addEventListener('click', async () => {
    sheet.close();
    const pin = await askNewPin(length);
    if (!pin) return;
    await setLock(await makeLockConfig(pin, length));
    toast('অ্যাপ লক চালু হয়েছে');
    rerender();
  });
}

export const __forms = { askNewPin, verifyCurrent, chooseLengthThenSetup };
