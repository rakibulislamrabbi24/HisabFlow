import { getState, update, replaceAll, savePrevSnapshot, getPrevSnapshot, restorePrevSnapshot } from '../store.js';
import { defaultData } from '../models.js';
import { buildBackup, backupFilename, serialize, parseBackup, mergeData, countsOf } from '../services/backup.js';
import { saveAndShare, pickTextFile } from '../utils/files.js';
import { withoutRelock } from '../lockState.js';
import { openSheet, toast } from './modal.js';
import { icon } from './icons.js';
import { fmtNum, fmtDateTime, esc } from '../utils/format.js';

const LABELS = {
  wallets: 'ওয়ালেট', transactions: 'লেনদেন', dues: 'দেনা-পাওনা', settlements: 'শোধ/আদায়', transfers: 'ট্রান্সফার'
};
const STALE_DAYS = 30;

function daysSince(iso) {
  const t = new Date(iso).getTime();
  return isNaN(t) ? null : Math.floor((Date.now() - t) / 86400000);
}

// সেটিংস পেজের ভেতরে ব্যাকআপ কার্ড বসায়। rerender = সেটিংস পেজ আবার আঁকার ফাংশন।
export async function renderBackupSection(el, rerender) {
  const st = getState();
  const prev = await getPrevSnapshot();
  const hasData = st.transactions.length + st.dues.length + st.transfers.length > 0;
  const last = st.settings.lastBackupAt;
  const age = last ? daysSince(last) : null;

  let status;
  if (!last) {
    status = hasData
      ? `<p class="warn small">${icon('alert', { size: 15, cls: 'inl' })} আপনি এখনও ব্যাকআপ নেননি। ফোন হারালে বা অ্যাপ মুছলে সব হিসাব চলে যাবে।</p>`
      : '<p class="muted small">এখনও ব্যাকআপ নেওয়া হয়নি।</p>';
  } else if (age !== null && age >= STALE_DAYS && hasData) {
    status = `<p class="warn small">${icon('alert', { size: 15, cls: 'inl' })} শেষ ব্যাকআপ ${fmtNum(age)} দিন আগে (${fmtDateTime(last)})। নতুন ব্যাকআপ নিন।</p>`;
  } else {
    status = `<p class="muted small">শেষ ব্যাকআপ: ${fmtDateTime(last)}</p>`;
  }

  el.innerHTML = `
    <div class="card">
      <h2>${icon('database', { size: 20 })} ব্যাকআপ ও রিস্টোর</h2>
      ${status}
      <div class="btn-row">
        <button class="btn" id="bk-export">${icon('upload', { size: 18 })} ব্যাকআপ নিন</button>
        <button class="btn btn-ghost" id="bk-import">${icon('download', { size: 18 })} রিস্টোর করুন</button>
      </div>
      <p class="muted small">ব্যাকআপ ফাইলে আপনার সব হিসাব থাকে। ফাইলটি Google Drive, ইমেইল বা অন্য নিরাপদ জায়গায় রাখুন এবং অন্য কাউকে দেবেন না।</p>
      ${prev ? `
        <div class="undo-box">
          <div class="small muted">শেষ রিস্টোর/রিসেটের আগের ডেটা সেভ আছে (${fmtDateTime(prev.savedAt)})</div>
          <button class="btn btn-ghost" id="bk-undo">আগের অবস্থায় ফিরুন</button>
        </div>` : ''}
      <div class="danger-zone">
        <button class="btn btn-ghost btn-danger-ghost" id="bk-reset">সব ডেটা মুছে ফেলুন</button>
      </div>
    </div>`;

  const $ = (s) => el.querySelector(s);

  // ---- ব্যাকআপ নেওয়া ----
  $('#bk-export').addEventListener('click', async (e) => {
    const btn = e.currentTarget;
    btn.disabled = true;
    try {
      const now = new Date();
      const text = serialize(buildBackup(getState(), now));
      const result = await withoutRelock(() => saveAndShare(backupFilename(now), text));
      if (result === 'cancelled') { toast('ব্যাকআপ বাতিল হয়েছে'); return; }
      await update((s) => { s.settings.lastBackupAt = now.toISOString(); });
      toast(result === 'downloaded' ? 'ফাইল ডাউনলোড হয়েছে' : 'ব্যাকআপ শেয়ার করা হয়েছে');
      rerender();
    } catch (err) {
      console.error(err);
      toast('ব্যাকআপ নেওয়া যায়নি');
    } finally {
      btn.disabled = false;
    }
  });

  // ---- রিস্টোর ----
  $('#bk-import').addEventListener('click', async () => {
    let file;
    try {
      file = await withoutRelock(() => pickTextFile());
    } catch (err) {
      console.error(err);
      toast('ফাইল পড়া যায়নি');
      return;
    }
    if (!file) return;
    const parsed = parseBackup(file.text);
    if (!parsed.ok) { showImportErrors(file.name, parsed.errors); return; }
    showRestorePreview(file.name, parsed, rerender);
  });

  // ---- আগের অবস্থায় ফেরা (দুইবার চাপতে হয়) ----
  const undo = $('#bk-undo');
  if (undo) twoTap(undo, 'নিশ্চিত? আবার চাপুন', async () => {
    const ok = await restorePrevSnapshot();
    toast(ok ? 'আগের অবস্থায় ফেরা হয়েছে' : 'আগের ডেটা পাওয়া যায়নি');
    rerender();
  });

  // ---- সব মুছে ফেলা (আগে স্ন্যাপশট নেওয়া হয়, তাই ফেরানো যায়) ----
  twoTap($('#bk-reset'), 'নিশ্চিত? সব ডেটা মুছবে', async () => {
    await savePrevSnapshot();
    await replaceAll(defaultData());
    toast('সব ডেটা মুছে ফেলা হয়েছে');
    rerender();
  });
}

function twoTap(btn, armedText, action) {
  const original = btn.textContent;
  let armed = false;
  btn.addEventListener('click', async () => {
    if (!armed) {
      armed = true;
      btn.textContent = armedText;
      setTimeout(() => { armed = false; btn.textContent = original; }, 3000);
      return;
    }
    armed = false;
    await action();
  });
}

function showImportErrors(name, errors) {
  const sheet = openSheet(`
    <div class="sheet-head"><h2>রিস্টোর করা যাচ্ছে না</h2><button class="icon-btn" data-close aria-label="বন্ধ">${icon('x', { size: 18 })}</button></div>
    <p class="muted small">ফাইল: ${esc(name)}</p>
    <ul class="list err-list">${errors.map((e) => `<li><span class="neg-text">${esc(e)}</span></li>`).join('')}</ul>
    <p class="muted small">আপনার বর্তমান ডেটায় কোনো পরিবর্তন করা হয়নি।</p>
    <div class="btn-row"><button class="btn" data-close>ঠিক আছে</button></div>`);
  return sheet;
}

function showRestorePreview(name, parsed, rerender) {
  const cur = getState();
  const curCounts = countsOf(cur);
  const merge = mergeData(cur, parsed.data);
  let mode = 'replace';

  const sheet = openSheet(`
    <div class="sheet-head"><h2>রিস্টোর</h2><button class="icon-btn" data-close aria-label="বন্ধ">${icon('x', { size: 18 })}</button></div>
    <p class="muted small">ফাইল: ${esc(name)}${parsed.exportedAt ? '<br>ব্যাকআপের সময়: ' + fmtDateTime(parsed.exportedAt) : ''}</p>
    <table class="cmp">
      <thead><tr><th></th><th>এখন</th><th>ব্যাকআপে</th></tr></thead>
      <tbody>
        ${Object.keys(LABELS).map((k) => `<tr><td>${LABELS[k]}</td><td>${fmtNum(curCounts[k])}</td><td>${fmtNum(parsed.counts[k])}</td></tr>`).join('')}
      </tbody>
    </table>
    <div class="mode-list" id="rs-mode">
      <label class="mode"><input type="radio" name="mode" value="replace" checked />
        <span><strong>প্রতিস্থাপন করুন</strong><br><small class="muted">এখনকার সব ডেটা বাদ দিয়ে ব্যাকআপের ডেটা বসবে।</small></span></label>
      <label class="mode"><input type="radio" name="mode" value="merge" ${merge.errors.length ? 'disabled' : ''} />
        <span><strong>মার্জ করুন</strong><br><small class="muted" id="rs-merge-note">${merge.errors.length
          ? 'এই ব্যাকআপ বর্তমান ডেটার সাথে মেলানো যাচ্ছে না।'
          : `এখনকার ডেটা থাকবে, শুধু নতুন রেকর্ড যোগ হবে (${fmtNum(merge.added.transactions)}টি লেনদেন, ${fmtNum(merge.added.dues)}টি দেনা-পাওনা, ${fmtNum(merge.added.transfers)}টি ট্রান্সফার)।`}</small></span></label>
    </div>
    <p class="muted small">রিস্টোরের আগে এখনকার ডেটা নিরাপত্তার জন্য সেভ হয়ে থাকবে। ভুল হলে সেটিংস থেকে "আগের অবস্থায় ফিরুন" দিয়ে ফেরা যাবে।</p>
    <div class="btn-row">
      <button class="btn" id="rs-go">রিস্টোর করুন</button>
      <button class="btn btn-ghost" data-close>বাতিল</button>
    </div>`);

  const q = (s) => sheet.el.querySelector(s);
  const go = q('#rs-go');
  let armed = false;
  const label = go.textContent;
  q('#rs-mode').addEventListener('change', (e) => {
    mode = e.target.value;
    armed = false;
    go.textContent = label;
  });
  go.addEventListener('click', async () => {
    if (mode === 'replace' && !armed && (cur.transactions.length + cur.dues.length + cur.transfers.length) > 0) {
      armed = true;
      go.textContent = 'এখনকার ডেটা বদলে যাবে। নিশ্চিত?';
      return;
    }
    go.disabled = true;
    try {
      await savePrevSnapshot();
      // ভাষা ও থিম ডিভাইসের পছন্দ: রিস্টোরে বদলায় না
      const next = structuredClone(mode === 'merge' ? merge.merged : parsed.data);
      next.settings.language = cur.settings.language;
      next.settings.theme = cur.settings.theme;
      await replaceAll(next);
      sheet.close();
      toast(mode === 'merge' ? 'মার্জ সম্পন্ন হয়েছে' : 'রিস্টোর সম্পন্ন হয়েছে');
      rerender();
    } catch (err) {
      console.error(err);
      go.disabled = false;
      toast('রিস্টোর করা যায়নি');
    }
  });
}

export const __forms = { showImportErrors, showRestorePreview };
