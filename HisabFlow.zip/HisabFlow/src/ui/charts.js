import { getState } from '../store.js';
import { todayISO } from '../models.js';
import { categoryBreakdown, monthlySeries, dailyExpense } from '../services/analytics.js';
import { donut, groupedBars, dailyBars, PALETTE } from '../utils/svg.js';
import {
  fmtMoney, fmtNum, esc, currentMonthKey, shiftMonth, monthLabel, monthShort
} from '../utils/format.js';

const view = { month: currentMonthKey(), type: 'expense', selected: -1 };

export function renderCharts(c) {
  function paint() {
    const st = getState();
    const m = (n) => fmtMoney(n, st.settings.currency);
    const isCurrent = view.month === currentMonthKey();
    const isExpense = view.type === 'expense';

    // ১) ক্যাটাগরি ডোনাট
    const bd = categoryBreakdown(st, view.month, view.type);
    const items = bd.items.map((x, i) => ({ ...x, color: PALETTE[i % PALETTE.length] }));
    if (view.selected >= items.length) view.selected = -1;
    const sel = view.selected >= 0 ? items[view.selected] : null;

    // ২) ৬ মাসের আয়-ব্যয়
    const series = monthlySeries(st, view.month, 6);
    const hasSeries = series.some((r) => r.income > 0 || r.expense > 0);

    // ৩) দৈনিক ব্যয়
    const daily = dailyExpense(st, view.month, todayISO());

    c.innerHTML = `
      <a class="back-link" href="#/dashboard">‹ হোমে ফিরুন</a>

      <section class="card">
        <div class="month-bar">
          <button class="icon-btn" id="c-prev" aria-label="আগের মাস">‹</button>
          <strong>${monthLabel(view.month)}</strong>
          <button class="icon-btn" id="c-next" aria-label="পরের মাস" ${isCurrent ? 'disabled' : ''}>›</button>
        </div>
        <div class="seg seg-small" id="c-type">
          <button data-type="expense" class="${isExpense ? 'active expense' : ''}">ব্যয়</button>
          <button data-type="income" class="${!isExpense ? 'active income' : ''}">আয়</button>
        </div>
      </section>

      <section class="card">
        <h2>ক্যাটাগরি অনুযায়ী ${isExpense ? 'ব্যয়' : 'আয়'}</h2>
        ${items.length === 0
          ? `<p class="muted small center">এই মাসে কোনো ${isExpense ? 'ব্যয়' : 'আয়'} নেই।</p>`
          : `
          <div class="donut-wrap" id="c-donut">
            ${donut(items, {
              selected: view.selected,
              centerLabel: sel ? sel.label : 'মোট',
              centerValue: m(sel ? sel.value : bd.total),
              ariaLabel: `ক্যাটাগরি অনুযায়ী ${isExpense ? 'ব্যয়' : 'আয়'}`
            })}
          </div>
          <div class="legend" id="c-legend">
            ${items.map((x, i) => `
              <button class="legend-row ${view.selected === i ? 'active' : ''}" data-idx="${i}">
                <span class="dot" style="background:${x.color}"></span>
                <span class="legend-name">${esc(x.label)}</span>
                <span class="muted small">${fmtNum(Math.round(x.pct * 10) / 10)}%</span>
                <strong>${m(x.value)}</strong>
              </button>`).join('')}
          </div>
          <p class="muted small center">কোনো ক্যাটাগরিতে ট্যাপ করলে হাইলাইট হবে</p>`}
      </section>

      <section class="card">
        <h2>শেষ ৬ মাসের আয় ও ব্যয়</h2>
        ${hasSeries ? `
          ${groupedBars(series.map((r) => ({ label: monthShort(r.key), values: [r.income, r.expense] })), { ariaLabel: 'শেষ ৬ মাসের আয় ও ব্যয়' })}
          <div class="chart-legend">
            <span><span class="dot" style="background:#1b8a3a"></span> আয়</span>
            <span><span class="dot" style="background:#c4222f"></span> ব্যয়</span>
          </div>
          <ul class="list month-table">
            ${[...series].reverse().map((r) => `
              <li>
                <span>${monthLabel(r.key)}</span>
                <span class="mt-nums">
                  <span class="pos-text">${m(r.income)}</span>
                  <span class="neg-text">${m(r.expense)}</span>
                  <strong class="${r.net < 0 ? 'neg-text' : ''}">${m(r.net)}</strong>
                </span>
              </li>`).join('')}
          </ul>
          <p class="muted small center">আয় · ব্যয় · নিট</p>`
          : '<p class="muted small center">এই সময়ে কোনো লেনদেন নেই।</p>'}
      </section>

      <section class="card">
        <h2>দৈনিক ব্যয় (${monthLabel(view.month)})</h2>
        ${daily.total > 0 ? `
          ${dailyBars(daily.days, daily.avg)}
          <div class="grid3 daily-stats">
            <div class="stat"><span class="stat-label">মোট ব্যয়</span><span class="stat-value">${m(daily.total)}</span></div>
            <div class="stat"><span class="stat-label">গড় দৈনিক</span><span class="stat-value">${m(daily.avg)}</span></div>
            <div class="stat"><span class="stat-label">সর্বোচ্চ (${fmtNum(daily.max.day)} তারিখ)</span><span class="stat-value">${m(daily.max.value)}</span></div>
          </div>`
          : '<p class="muted small center">এই মাসে কোনো ব্যয় নেই।</p>'}
      </section>
    `;

    const $ = (s) => c.querySelector(s);
    $('#c-prev').addEventListener('click', () => { view.month = shiftMonth(view.month, -1); view.selected = -1; paint(); });
    $('#c-next').addEventListener('click', () => {
      if (view.month !== currentMonthKey()) { view.month = shiftMonth(view.month, 1); view.selected = -1; paint(); }
    });
    $('#c-type').addEventListener('click', (e) => {
      const b = e.target.closest('button');
      if (!b || b.dataset.type === view.type) return;
      view.type = b.dataset.type;
      view.selected = -1;
      paint();
    });
    const toggle = (idx) => { view.selected = view.selected === idx ? -1 : idx; paint(); };
    const legend = $('#c-legend');
    if (legend) legend.addEventListener('click', (e) => {
      const row = e.target.closest('.legend-row');
      if (row) toggle(Number(row.dataset.idx));
    });
    const dn = $('#c-donut');
    if (dn) dn.addEventListener('click', (e) => {
      const seg = e.target.closest('.seg');
      if (seg) toggle(Number(seg.dataset.idx));
    });
  }
  paint();
}
