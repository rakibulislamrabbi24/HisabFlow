import { placeholder } from './placeholder.js';
export function renderDues(c) {
  placeholder(c, '🤝', 'দেনা-পাওনা', 'Due/Loan ম্যানেজমেন্ট ধাপ ৪-এ যোগ হবে');
}
