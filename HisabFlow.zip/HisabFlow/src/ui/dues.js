import { getState, update } from '../store.js';
import { todayISO } from '../models.js';
import {
  dueInfo, validateDue, addDue, updateDue, deleteDue, validateSettlement, addSettlement,
  deleteSettlement, settlementsOf, filterDues, groupByPerson, kindTotals, knownPeople, remainingOf
} from '../services/dues.js';
import { openSheet, toast } from './modal.js';
import { fmtMoney, fmtNum, fmtDate, esc } from '../utils/format.js';

// অন্য পেজে গিয়ে ফিরলেও ফিল্টার থাকে
const view = { kind: 'receivable', status: 'open', q: '' };

const KIND = {
  receivable: { label: 'পাওনা', short: 'আমি পাবো', action: 'আদায়', done: 'আদায় হয়েছে', cls: 'income' },
  payable: { label: 'দেনা', short: 'আমি দেবো', action: 'শোধ', done: 'শোধ হয়েছে', cls: 'expense' }
};
const STATUS = { open: 'বাকি', partial: 'আংশিক', settled: 'পরিশোধিত' };

export function renderDues(c) {
  c.innerHTML = `
    <div class="seg" id="d-kind">
      <button data-kind="receivable">পাওনা</button>
      <button data-kind="payable">দেনা</button>
    </div>
    <div id="d-summary"></div>
    <section class="card filters">
      <div class="chips" id="d-chips">
        <button class="chip" data-status="open">খোলা</button>
        <button class="chip" data-status="settled">পরিশোধিত</button>
        <button class="chip" data-status="all">সব</button>
      </div>
      <input id="d-search" class="input" type="search" placeholder="নাম বা নোট খুঁজুন…" />
    </section>
    <div id="d-list"></div>
    <button class="fab" id="d-add" aria-label="নতুন হিসাব">＋</button>
  `;
  const $ = (s) => c.querySelector(s);
  $('#d-search').value = view.q;

  function paint() {
    const st = getState();
    const today = todayISO();
    const cur = st.settings.currency;
    const m = (n) => fmtMoney(n, cur);
    const K = KIND[view.kind];

    c.querySelectorAll('#d-kind button').forEach((b) => {
      const on = b.dataset.kind === view.kind;
      b.classList.toggle('active', on);
      b.classList.toggle('income', b.dataset.kind === 'receivable');
      b.classList.toggle('expense', b.dataset.kind === 'payable');
    });
    c.querySelectorAll('#d-chips .chip').forEach((b) => b.classList.toggle('active', b.dataset.status === view.status));

    const t = kindTotals(st, view.kind, today);
    $('#d-summary').innerHTML = `
      <div class="card due-summary ${K.cls}">
        <div class="muted small">মোট বাকি ${K.label} (${K.short})</div>
        <div class="due-total">${m(t.remaining)}</div>
        <div class="muted small">খোলা হিসাব ${fmtNum(t.openCount)}টি${t.overdue ? ` · <span class="warn">মেয়াদোত্তীর্ণ ${fmtNum(t.overdue)}টি</span>` : ''}</div>
      </div>`;

    const list = filterDues(st, view, today);
    if (list.length === 0) {
      const none = st.dues.filter((d) => d.kind === view.kind).length === 0;
      $('#d-list').innerHTML = `
        <div class="card empty">
          <div class="empty-ico">🤝</div>
          <p class="muted">${none ? `এখনও কোনো ${K.label} নেই। ＋ বাটনে চাপ দিয়ে যোগ করুন।` : 'এই ফিল্টারে কিছু পাওয়া যায়নি।'}</p>
        </div>`;
      return;
    }

    let html = '';
    for (const g of groupByPerson(st, list, today)) {
      html += `<div class="person-head"><span>👤 ${esc(g.person)}</span><strong>${m(g.remaining)}</strong></div>
        <ul class="list card">`;
      for (const d of g.dues) {
        const i = dueInfo(st, d, today);
        html += `
          <li class="due-item" data-id="${esc(d.id)}">
            <div class="due-row">
              <span class="muted small">${fmtDate(d.date)}${d.note ? ' · ' + esc(d.note) : ''}</span>
              <span class="badge ${i.status}">${STATUS[i.status]}</span>
            </div>
            <div class="due-row">
              <span class="muted small">মোট ${m(d.amount)} · ${K.done.split(' ')[0]} ${m(i.paid)}</span>
              <strong>${m(i.remaining)}</strong>
            </div>
            <div class="progress"><div class="progress-fill ${K.cls}" style="width:${i.pct}%"></div></div>
            ${d.dueDate ? `<div class="small ${i.overdue ? 'warn' : 'muted'}">মেয়াদ: ${fmtDate(d.dueDate)}${i.overdue ? ' (পার হয়ে গেছে)' : ''}</div>` : ''}
          </li>`;
      }
      html += '</ul>';
    }
    $('#d-list').innerHTML = html;
  }

  $('#d-kind').addEventListener('click', (e) => {
    const b = e.target.closest('button');
    if (!b) return;
    view.kind = b.dataset.kind;
    paint();
  });
  $('#d-chips').addEventListener('click', (e) => {
    const b = e.target.closest('.chip');
    if (!b) return;
    view.status = b.dataset.status;
    paint();
  });
  $('#d-search').addEventListener('input', (e) => { view.q = e.target.value; paint(); });
  $('#d-list').addEventListener('click', (e) => {
    const li = e.target.closest('.due-item');
    if (li) openDetail(li.dataset.id, paint);
  });
  $('#d-add').addEventListener('click', () => openDueForm(null, paint));

  paint();
}

// ---------- নতুন/এডিট ফর্ম ----------
function openDueForm(due, afterSave) {
  const state = getState();
  const isEdit = !!due;
  const hasSettlements = isEdit && state.settlements.some((s) => s.dueId === due.id);
  let kind = due ? due.kind : view.kind;

  const sheet = openSheet(`
    <div class="sheet-head">
      <h2>${isEdit ? 'হিসাব এডিট' : 'নতুন দেনা-পাওনা'}</h2>
      <button class="icon-btn" data-close aria-label="বন্ধ">✕</button>
    </div>
    <div class="seg" id="df-kind">
      <button data-kind="receivable">পাওনা (পাবো)</button>
      <button data-kind="payable">দেনা (দেবো)</button>
    </div>
    ${hasSettlements ? '<p class="muted small">শোধ/আদায় শুরু হয়ে গেছে, তাই ধরন বদলানো যাবে না।</p>' : ''}
    <label class="field"><span>ব্যক্তির নাম</span>
      <input id="df-person" class="input" type="text" maxlength="40" list="df-people" />
      <datalist id="df-people">${knownPeople(state).map((p) => `<option value="${esc(p)}"></option>`).join('')}</datalist>
    </label>
    <label class="field"><span>মোট পরিমাণ</span>
      <input id="df-amount" class="input big" type="number" inputmode="decimal" step="any" min="0" placeholder="0" />
    </label>
    <label class="field"><span>ওয়ালেট</span>
      <select id="df-wallet" class="input">
        <option value="">ওয়ালেটে প্রভাব নেই (বাকিতে/টাকা নয়)</option>
        ${state.wallets.map((w) => `<option value="${esc(w.id)}">${esc(w.name)}</option>`).join('')}
      </select>
      <small class="muted" id="df-hint"></small>
    </label>
    <div class="grid2">
      <label class="field"><span>তারিখ</span><input id="df-date" class="input" type="date" /></label>
      <label class="field"><span>মেয়াদ (ঐচ্ছিক)</span><input id="df-due" class="input" type="date" /></label>
    </div>
    <label class="field"><span>নোট (ঐচ্ছিক)</span><input id="df-note" class="input" type="text" maxlength="120" /></label>
    <div class="error" id="df-error"></div>
    <div class="btn-row"><button class="btn" id="df-save">${isEdit ? 'আপডেট করুন' : 'সেভ করুন'}</button></div>
  `);
  const q = (s) => sheet.el.querySelector(s);
  const personEl = q('#df-person');
  const amountEl = q('#df-amount');
  const walletEl = q('#df-wallet');
  const dateEl = q('#df-date');
  const dueEl = q('#df-due');
  const noteEl = q('#df-note');
  const errEl = q('#df-error');

  function paintKind() {
    q('#df-kind').querySelectorAll('button').forEach((b) => {
      b.classList.toggle('active', b.dataset.kind === kind);
      b.classList.toggle('income', b.dataset.kind === 'receivable');
      b.classList.toggle('expense', b.dataset.kind === 'payable');
      b.disabled = hasSettlements && b.dataset.kind !== kind;
    });
    q('#df-hint').textContent = kind === 'receivable'
      ? 'টাকা ধার দিলে এই ওয়ালেট থেকে কমে যাবে।'
      : 'টাকা ধার নিলে এই ওয়ালেটে বেড়ে যাবে।';
  }

  personEl.value = due ? due.person : '';
  amountEl.value = due ? due.amount : '';
  walletEl.value = due ? (due.walletId || '') : (state.wallets[0] ? state.wallets[0].id : '');
  dateEl.value = due ? due.date : todayISO();
  dueEl.value = due ? (due.dueDate || '') : '';
  noteEl.value = due ? (due.note || '') : '';
  paintKind();

  q('#df-kind').addEventListener('click', (e) => {
    const b = e.target.closest('button');
    if (!b || b.disabled) return;
    kind = b.dataset.kind;
    paintKind();
  });

  q('#df-save').addEventListener('click', async () => {
    const input = {
      kind,
      person: personEl.value,
      amount: amountEl.value === '' ? '' : Number(amountEl.value),
      walletId: walletEl.value,
      date: dateEl.value,
      dueDate: dueEl.value,
      note: noteEl.value
    };
    const err = validateDue(input, getState(), isEdit ? due.id : null);
    if (err) { errEl.textContent = err; return; }
    await update((s) => { if (isEdit) updateDue(s, due.id, input); else addDue(s, input); });
    if (!isEdit) view.kind = kind; // নতুন হিসাব যে ট্যাবে, সেটাই দেখাও
    sheet.close();
    toast(isEdit ? 'আপডেট হয়েছে' : 'সেভ হয়েছে');
    afterSave();
  });
}

// ---------- বিস্তারিত + আংশিক শোধ/আদায় ----------
function openDetail(dueId, afterChange) {
  const sheet = openSheet('');
  let showForm = false;

  function render() {
    const st = getState();
    const due = st.dues.find((d) => d.id === dueId);
    if (!due) { sheet.close(); return; }
    const cur = st.settings.currency;
    const m = (n) => fmtMoney(n, cur);
    const K = KIND[due.kind];
    const i = dueInfo(st, due, todayISO());
    const wname = Object.fromEntries(st.wallets.map((w) => [w.id, w.name]));
    const history = settlementsOf(st, due.id);

    sheet.el.innerHTML = `
      <div class="sheet-head">
        <h2>👤 ${esc(due.person)} <span class="badge ${i.status}">${STATUS[i.status]}</span></h2>
        <button class="icon-btn" data-close aria-label="বন্ধ">✕</button>
      </div>
      <div class="muted small kind-line">${K.label} · ${K.short}</div>
      <div class="grid3">
        <div class="stat"><span class="stat-label">মোট</span><span class="stat-value">${m(due.amount)}</span></div>
        <div class="stat ${K.cls}"><span class="stat-label">${K.action} হয়েছে</span><span class="stat-value">${m(i.paid)}</span></div>
        <div class="stat"><span class="stat-label">বাকি</span><span class="stat-value">${m(i.remaining)}</span></div>
      </div>
      <div class="progress big-progress"><div class="progress-fill ${K.cls}" style="width:${i.pct}%"></div></div>
      <ul class="list info-list">
        <li><span class="muted">তারিখ</span><span>${fmtDate(due.date)}</span></li>
        ${due.dueDate ? `<li><span class="muted">মেয়াদ</span><span class="${i.overdue ? 'warn' : ''}">${fmtDate(due.dueDate)}${i.overdue ? ' (পার হয়ে গেছে)' : ''}</span></li>` : ''}
        <li><span class="muted">ওয়ালেট</span><span>${due.walletId ? esc(wname[due.walletId] || '—') : 'প্রভাব নেই'}</span></li>
        ${due.note ? `<li><span class="muted">নোট</span><span>${esc(due.note)}</span></li>` : ''}
      </ul>

      ${i.remaining > 0 && !showForm ? `<button class="btn ${due.kind === 'payable' ? 'btn-danger' : ''}" id="dt-open">টাকা ${K.action} করুন</button>` : ''}

      ${showForm ? `
        <div class="inline-form">
          <h3>আংশিক বা পুরো ${K.action}</h3>
          <label class="field"><span>পরিমাণ (বাকি ${m(i.remaining)})</span>
            <div class="amount-row">
              <input id="s-amount" class="input big" type="number" inputmode="decimal" step="any" min="0" placeholder="0" />
              <button class="chip" id="s-full" type="button">পুরোটা</button>
            </div>
          </label>
          <label class="field"><span>${due.kind === 'receivable' ? 'কোন ওয়ালেটে টাকা এলো' : 'কোন ওয়ালেট থেকে দিলেন'}</span>
            <select id="s-wallet" class="input">
              ${st.wallets.map((w) => `<option value="${esc(w.id)}">${esc(w.name)}</option>`).join('')}
            </select>
          </label>
          <div class="grid2">
            <label class="field"><span>তারিখ</span><input id="s-date" class="input" type="date" /></label>
            <label class="field"><span>নোট</span><input id="s-note" class="input" type="text" maxlength="120" /></label>
          </div>
          <div class="error" id="s-error"></div>
          <div class="btn-row">
            <button class="btn" id="s-save">সেভ করুন</button>
            <button class="btn btn-ghost" id="s-cancel">বাতিল</button>
          </div>
        </div>` : ''}

      <h3 class="hist-title">${K.action}ের ইতিহাস</h3>
      ${history.length === 0 ? '<p class="muted small">এখনও কিছু ' + K.action + ' হয়নি।</p>' : `
        <ul class="list">
          ${history.map((s) => `
            <li>
              <div>
                <div>${m(s.amount)}</div>
                <div class="muted small">${fmtDate(s.date)} · ${esc(wname[s.walletId] || '—')}${s.note ? ' · ' + esc(s.note) : ''}</div>
              </div>
              <button class="link-btn" data-del-s="${esc(s.id)}">মুছুন</button>
            </li>`).join('')}
        </ul>`}

      <div class="btn-row sheet-actions">
        <button class="btn btn-ghost" id="dt-edit">এডিট</button>
        <button class="btn btn-danger" id="dt-del">হিসাব মুছুন</button>
      </div>
    `;

    const q = (s) => sheet.el.querySelector(s);
    sheet.el.querySelectorAll('[data-close]').forEach((b) => b.addEventListener('click', sheet.close));

    const openBtn = q('#dt-open');
    if (openBtn) openBtn.addEventListener('click', () => { showForm = true; render(); });

    if (showForm) {
      const amountEl = q('#s-amount');
      const walletEl = q('#s-wallet');
      const dateEl = q('#s-date');
      const noteEl = q('#s-note');
      const errEl = q('#s-error');
      walletEl.value = due.walletId || (st.wallets[0] && st.wallets[0].id);
      dateEl.value = todayISO();
      q('#s-full').addEventListener('click', () => { amountEl.value = i.remaining; });
      q('#s-cancel').addEventListener('click', () => { showForm = false; render(); });
      q('#s-save').addEventListener('click', async () => {
        const input = {
          amount: amountEl.value === '' ? '' : Number(amountEl.value),
          walletId: walletEl.value,
          date: dateEl.value,
          note: noteEl.value
        };
        const err = validateSettlement(input, getState(), due);
        if (err) { errEl.textContent = err; return; }
        await update((s) => addSettlement(s, due.id, input));
        showForm = false;
        toast(`${K.done}`);
        afterChange();
        render();
      });
    }

    // ইতিহাসের এন্ট্রি মোছা (দুইবার চাপতে হয়)
    sheet.el.querySelectorAll('[data-del-s]').forEach((btn) => {
      let armed = false;
      btn.addEventListener('click', async () => {
        if (!armed) {
          armed = true;
          btn.textContent = 'নিশ্চিত?';
          setTimeout(() => { armed = false; btn.textContent = 'মুছুন'; }, 3000);
          return;
        }
        await update((s) => deleteSettlement(s, btn.dataset.delS));
        toast('মুছে ফেলা হয়েছে');
        afterChange();
        render();
      });
    });

    q('#dt-edit').addEventListener('click', () => {
      sheet.close();
      openDueForm(due, afterChange);
    });

    const delBtn = q('#dt-del');
    let armed = false;
    delBtn.addEventListener('click', async () => {
      if (!armed) {
        armed = true;
        delBtn.textContent = 'নিশ্চিত? সব ইতিহাস মুছবে';
        setTimeout(() => { armed = false; delBtn.textContent = 'হিসাব মুছুন'; }, 3000);
        return;
      }
      await update((s) => deleteDue(s, due.id));
      sheet.close();
      toast('হিসাব মুছে ফেলা হয়েছে');
      afterChange();
    });
  }

  render();
}
