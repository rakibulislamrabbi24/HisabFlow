import { getState } from '../store.js';

// ধাপ ১: শুধু ওয়ালেটের তালিকা দেখায় (ব্যালেন্স হিসাব ধাপ ৬-এ)
export function renderWallets(c) {
  const { wallets } = getState();
  c.innerHTML = `
    <div class="card">
      <h2>আপনার ওয়ালেট</h2>
      <ul class="list">
        ${wallets.map((w) => `<li><span>${w.name}</span><span class="muted">${w.type}</span></li>`).join('')}
      </ul>
      <p class="muted small">ব্যালেন্স ও ট্রান্সফার ধাপ ৬-এ যোগ হবে</p>
    </div>`;
}
