import { getState, update } from '../store.js';
import { todayISO } from '../models.js';
import { walletBalances, netBalance } from '../services/summary.js';
import {
  WALLET_TYPES, validateWallet, addWallet, updateWallet, deleteBlockReason, deleteWallet,
  walletBreakdown, walletActivity, validateTransfer, addTransfer, updateTransfer, deleteTransfer,
  recentTransfers
} from '../services/wallets.js';
import { openSheet, toast } from './modal.js';
import { icon } from './icons.js';
import { fmtMoney, fmtNum, fmtDate, esc } from '../utils/format.js';

// ড্যাশবোর্ডের দ্রুত অ্যাকশন থেকে সরাসরি ট্রান্সফার ফর্ম খোলার অনুরোধ
let pendingTransfer = false;
export function requestTransfer() { pendingTransfer = true; }

export function renderWallets(c) {
  function paint() {
    const st = getState();
    const m = (n) => fmtMoney(n, st.settings.currency);
    const rows = walletBalances(st);
    const wname = Object.fromEntries(st.wallets.map((w) => [w.id, w.name]));
    const trs = recentTransfers(st, 10);

    c.innerHTML = `
      <section class="hero">
        <div class="hero-label">সব ওয়ালেটের মোট</div>
        <div class="hero-amount ${netBalance(st) < 0 ? 'neg' : ''}">${m(netBalance(st))}</div>
        <div class="hero-sub">${fmtNum(st.wallets.length)}টি ওয়ালেট</div>
      </section>

      <div class="btn-row wallet-actions">
        <button class="btn" id="w-transfer">${icon('swap', { size: 18 })} ট্রান্সফার</button>
        <button class="btn btn-ghost" id="w-add">${icon('plus', { size: 18 })} নতুন ওয়ালেট</button>
      </div>

      <div class="wallet-grid">
        ${rows.map((x) => `
          <button class="wallet-card" data-id="${esc(x.wallet.id)}" style="--wc-rgb:${(WALLET_TYPES[x.wallet.type] || WALLET_TYPES.other).rgb}">
            <span class="wallet-ico">${icon((WALLET_TYPES[x.wallet.type] || WALLET_TYPES.other).icon, { size: 22 })}</span>
            <span class="wallet-name">${esc(x.wallet.name)}</span>
            <span class="muted small">${(WALLET_TYPES[x.wallet.type] || WALLET_TYPES.other).label}</span>
            <strong class="wbal ${x.balance < 0 ? 'neg-text' : ''}">${m(x.balance)}</strong>
          </button>`).join('')}
      </div>

      <section class="card">
        <h2>সাম্প্রতিক ট্রান্সফার</h2>
        ${trs.length === 0 ? '<p class="muted small">এখনও কোনো ট্রান্সফার নেই।</p>' : `
          <ul class="list">
            ${trs.map((t) => `
              <li class="tr-item" data-id="${esc(t.id)}">
                <span class="tx-dot transfer">${icon('swap', { size: 18 })}</span>
                <div>
                  <div>${esc(wname[t.fromWalletId] || '—')} → ${esc(wname[t.toWalletId] || '—')}</div>
                  <div class="muted small">${fmtDate(t.date)}${t.fee > 0 ? ' · ফি ' + m(t.fee) : ''}${t.note ? ' · ' + esc(t.note) : ''}</div>
                </div>
                <strong>${m(t.amount)}</strong>
              </li>`).join('')}
          </ul>`}
      </section>`;

    c.querySelector('#w-transfer').addEventListener('click', () => openTransferForm(null, paint));
    c.querySelector('#w-add').addEventListener('click', () => openWalletForm(null, paint));
    c.querySelectorAll('.wallet-card').forEach((el) => el.addEventListener('click', () => openWalletDetail(el.dataset.id, paint)));
    c.querySelectorAll('.tr-item').forEach((el) => el.addEventListener('click', () => {
      const tr = getState().transfers.find((x) => x.id === el.dataset.id);
      if (tr) openTransferForm(tr, paint);
    }));
  }
  paint();
  if (pendingTransfer) {
    pendingTransfer = false;
    openTransferForm(null, paint);
  }
}

// ---------- ওয়ালেট ফর্ম ----------
function openWalletForm(wallet, afterSave) {
  const isEdit = !!wallet;
  const sheet = openSheet(`
    <div class="sheet-head">
      <h2>${isEdit ? 'ওয়ালেট এডিট' : 'নতুন ওয়ালেট'}</h2>
      <button class="icon-btn" data-close aria-label="বন্ধ">${icon('x', { size: 18 })}</button>
    </div>
    <label class="field"><span>নাম</span><input id="wf-name" class="input" type="text" maxlength="30" placeholder="যেমন: Rocket, DBBL" /></label>
    <label class="field"><span>ধরন</span>
      <select id="wf-type" class="input">
        ${Object.entries(WALLET_TYPES).map(([k, v]) => `<option value="${k}">${v.label}</option>`).join('')}
      </select>
    </label>
    <label class="field"><span>শুরুর ব্যালেন্স</span>
      <input id="wf-open" class="input" type="number" inputmode="decimal" step="any" placeholder="0" />
      <small class="muted">${isEdit ? 'এটি বদলালে বর্তমান ব্যালেন্সও একই পরিমাণ বদলে যাবে।' : 'ওয়ালেটে এখন যত টাকা আছে সেটি দিন।'}</small>
    </label>
    <div class="error" id="wf-error"></div>
    <div class="btn-row"><button class="btn" id="wf-save">${isEdit ? 'আপডেট করুন' : 'সেভ করুন'}</button></div>
  `);
  const q = (s) => sheet.el.querySelector(s);
  q('#wf-name').value = wallet ? wallet.name : '';
  q('#wf-type').value = wallet ? wallet.type : 'mobile';
  q('#wf-open').value = wallet ? wallet.openingBalance : '';

  q('#wf-save').addEventListener('click', async () => {
    const input = {
      name: q('#wf-name').value,
      type: q('#wf-type').value,
      openingBalance: q('#wf-open').value === '' ? '' : Number(q('#wf-open').value)
    };
    const err = validateWallet(input, getState(), isEdit ? wallet.id : null);
    if (err) { q('#wf-error').textContent = err; return; }
    await update((s) => { if (isEdit) updateWallet(s, wallet.id, input); else addWallet(s, input); });
    sheet.close();
    toast(isEdit ? 'আপডেট হয়েছে' : 'ওয়ালেট যোগ হয়েছে');
    afterSave();
  });
}

// ---------- ওয়ালেট বিস্তারিত ----------
function openWalletDetail(id, afterChange) {
  const st = getState();
  const wallet = st.wallets.find((w) => w.id === id);
  if (!wallet) return;
  const m = (n) => fmtMoney(n, st.settings.currency);
  const bd = walletBreakdown(st, id);
  const act = walletActivity(st, id, 15);
  const type = WALLET_TYPES[wallet.type] || WALLET_TYPES.other;
  const block = deleteBlockReason(st, id);
  const signed = (n) => (n >= 0 ? '+' : '-') + m(Math.abs(n));

  const sheet = openSheet(`
    <div class="sheet-head">
      <h2><span class="mini-ico" style="--wc-rgb:${type.rgb}">${icon(type.icon, { size: 18 })}</span> ${esc(wallet.name)}</h2>
      <button class="icon-btn" data-close aria-label="বন্ধ">${icon('x', { size: 18 })}</button>
    </div>
    <div class="wd-balance ${bd.balance < 0 ? 'neg-text' : ''}">${m(bd.balance)}</div>
    <div class="muted small center">${type.label}</div>

    <ul class="list breakdown">
      <li><span class="muted">শুরুর ব্যালেন্স</span><span>${m(bd.opening)}</span></li>
      <li><span class="muted">মোট আয়</span><span class="pos-text">${signed(bd.income)}</span></li>
      <li><span class="muted">মোট ব্যয়</span><span class="neg-text">${signed(-bd.expense)}</span></li>
      <li><span class="muted">দেনা-পাওনা</span><span class="${bd.dues < 0 ? 'neg-text' : 'pos-text'}">${signed(bd.dues)}</span></li>
      <li><span class="muted">ট্রান্সফার (নিট)</span><span class="${bd.transfers < 0 ? 'neg-text' : 'pos-text'}">${signed(bd.transfers)}</span></li>
    </ul>

    <h3 class="hist-title">সাম্প্রতিক নড়াচড়া</h3>
    ${act.length === 0 ? '<p class="muted small">এখনও কিছু নেই।</p>' : `
      <ul class="list">
        ${act.map((e) => `
          <li>
            <div>
              <div>${esc(e.label)}</div>
              <div class="muted small">${fmtDate(e.date)}</div>
            </div>
            <strong class="${e.amount >= 0 ? 'pos-text' : 'neg-text'}">${signed(e.amount)}</strong>
          </li>`).join('')}
      </ul>`}

    <div class="btn-row sheet-actions">
      <button class="btn" id="wd-transfer">${icon('swap', { size: 18 })} ট্রান্সফার</button>
      <button class="btn btn-ghost" id="wd-edit">এডিট</button>
      <button class="btn btn-danger" id="wd-del" ${block ? 'disabled' : ''}>মুছুন</button>
    </div>
    ${block ? `<p class="muted small">${esc(block)}</p>` : ''}
  `);
  const q = (s) => sheet.el.querySelector(s);
  q('#wd-transfer').addEventListener('click', () => { sheet.close(); openTransferForm(null, afterChange, id); });
  q('#wd-edit').addEventListener('click', () => { sheet.close(); openWalletForm(wallet, afterChange); });

  const del = q('#wd-del');
  let armed = false;
  del.addEventListener('click', async () => {
    if (del.disabled) return;
    if (!armed) {
      armed = true;
      del.textContent = 'নিশ্চিত? আবার চাপুন';
      setTimeout(() => { armed = false; del.textContent = 'মুছুন'; }, 3000);
      return;
    }
    await update((s) => deleteWallet(s, id));
    sheet.close();
    toast('ওয়ালেট মুছে ফেলা হয়েছে');
    afterChange();
  });
}

// ---------- ট্রান্সফার ফর্ম ----------
function openTransferForm(tr, afterSave, presetFrom = null) {
  const state = getState();
  const isEdit = !!tr;
  if (state.wallets.length < 2) { toast('ট্রান্সফারের জন্য অন্তত দুটি ওয়ালেট লাগবে'); return; }
  const m = (n) => fmtMoney(n, state.settings.currency);
  const opts = state.wallets.map((w) => `<option value="${esc(w.id)}">${esc(w.name)}</option>`).join('');

  const sheet = openSheet(`
    <div class="sheet-head">
      <h2>${isEdit ? 'ট্রান্সফার এডিট' : 'ওয়ালেট ট্রান্সফার'}</h2>
      <button class="icon-btn" data-close aria-label="বন্ধ">${icon('x', { size: 18 })}</button>
    </div>
    <label class="field"><span>কোথা থেকে</span><select id="tf-from" class="input">${opts}</select>
      <small class="muted" id="tf-bal"></small>
    </label>
    <div class="swap-row"><button class="chip" id="tf-swap" type="button">⇅ অদলবদল</button></div>
    <label class="field"><span>কোথায়</span><select id="tf-to" class="input">${opts}</select></label>
    <label class="field"><span>পরিমাণ</span>
      <input id="tf-amount" class="input big" type="number" inputmode="decimal" step="any" min="0" placeholder="0" />
    </label>
    <label class="field"><span>ফি/চার্জ (ঐচ্ছিক)</span>
      <input id="tf-fee" class="input" type="number" inputmode="decimal" step="any" min="0" placeholder="0" />
      <small class="muted">ফি আলাদা ব্যয় হিসেবে সোর্স ওয়ালেট থেকে কাটা হবে, গন্তব্যে পুরো পরিমাণ যাবে।</small>
    </label>
    <div class="grid2">
      <label class="field"><span>তারিখ</span><input id="tf-date" class="input" type="date" /></label>
      <label class="field"><span>নোট</span><input id="tf-note" class="input" type="text" maxlength="120" /></label>
    </div>
    <div class="error" id="tf-error"></div>
    <div class="btn-row">
      <button class="btn" id="tf-save">${isEdit ? 'আপডেট করুন' : 'ট্রান্সফার করুন'}</button>
      ${isEdit ? '<button class="btn btn-danger" id="tf-del">মুছুন</button>' : ''}
    </div>
  `);
  const q = (s) => sheet.el.querySelector(s);
  const fromEl = q('#tf-from');
  const toEl = q('#tf-to');
  const saveBtn = q('#tf-save');
  const errEl = q('#tf-error');
  const saveLabel = saveBtn.textContent;
  let armed = false;

  const first = presetFrom || (tr ? tr.fromWalletId : state.wallets[0].id);
  fromEl.value = first;
  toEl.value = tr ? tr.toWalletId : (state.wallets.find((w) => w.id !== first) || state.wallets[0]).id;
  q('#tf-amount').value = tr ? tr.amount : '';
  q('#tf-fee').value = tr && tr.fee > 0 ? tr.fee : '';
  q('#tf-date').value = tr ? tr.date : todayISO();
  q('#tf-note').value = tr ? (tr.note || '') : '';

  function showBalance() {
    const row = walletBalances(getState()).find((x) => x.wallet.id === fromEl.value);
    q('#tf-bal').textContent = row ? `বর্তমান ব্যালেন্স: ${m(row.balance)}` : '';
  }
  function disarm() {
    armed = false;
    saveBtn.textContent = saveLabel;
  }
  showBalance();
  fromEl.addEventListener('change', showBalance);
  sheet.el.addEventListener('input', () => { disarm(); errEl.textContent = ''; });
  sheet.el.addEventListener('change', () => { disarm(); });

  q('#tf-swap').addEventListener('click', () => {
    const a = fromEl.value;
    fromEl.value = toEl.value;
    toEl.value = a;
    showBalance();
    disarm();
  });

  saveBtn.addEventListener('click', async () => {
    const input = {
      fromWalletId: fromEl.value,
      toWalletId: toEl.value,
      amount: q('#tf-amount').value === '' ? '' : Number(q('#tf-amount').value),
      fee: q('#tf-fee').value === '' ? '' : Number(q('#tf-fee').value),
      date: q('#tf-date').value,
      note: q('#tf-note').value
    };
    const res = validateTransfer(input, getState(), isEdit ? tr.id : null);
    if (res.error) { errEl.textContent = res.error; return; }
    if (res.warning && !armed) {
      armed = true;
      errEl.textContent = res.warning;
      saveBtn.textContent = 'তবুও সেভ করুন';
      return;
    }
    await update((s) => { if (isEdit) updateTransfer(s, tr.id, input); else addTransfer(s, input); });
    sheet.close();
    toast(isEdit ? 'আপডেট হয়েছে' : 'ট্রান্সফার হয়েছে');
    afterSave();
  });

  const delBtn = q('#tf-del');
  if (delBtn) {
    let dArmed = false;
    delBtn.addEventListener('click', async () => {
      if (!dArmed) {
        dArmed = true;
        delBtn.textContent = 'নিশ্চিত? আবার চাপুন';
        setTimeout(() => { dArmed = false; delBtn.textContent = 'মুছুন'; }, 3000);
        return;
      }
      await update((s) => deleteTransfer(s, tr.id));
      sheet.close();
      toast('ট্রান্সফার মুছে ফেলা হয়েছে');
      afterSave();
    });
  }
}

export const __forms = { openWalletForm, openWalletDetail, openTransferForm };
