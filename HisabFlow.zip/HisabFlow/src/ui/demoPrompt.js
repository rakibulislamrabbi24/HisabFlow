// আগের ভার্সনে যোগ হওয়া নমুনা ডেটা থাকলে একবার জিজ্ঞেস করা: মুছবেন, নাকি আসল ধরবেন
import { getState, update, savePrevSnapshot } from '../store.js';
import { hasDemoData, demoCounts, removeDemoData, keepDemoAsReal } from '../services/maintenance.js';
import { openSheet, toast } from './modal.js';
import { icon } from './icons.js';
import { fmtNum } from '../utils/format.js';

export function maybePromptDemoCleanup() {
  return new Promise((resolve) => {
    const st = getState();
    if (!hasDemoData(st)) { resolve(); return; }
    const c = demoCounts(st);
    let done = false;
    const finish = () => { if (!done) { done = true; resolve(); } };

    const sheet = openSheet(`
      <div class="sheet-head">
        <h2>${icon('alert', { size: 20 })} নমুনা ডেটা পাওয়া গেছে</h2>
        <button class="icon-btn" data-close aria-label="বন্ধ">${icon('x', { size: 18 })}</button>
      </div>
      <p class="muted small">আগের ভার্সনে পরীক্ষার জন্য যোগ করা নমুনা ডেটা অ্যাপে আছে:</p>
      <ul class="list">
        <li><span>লেনদেন</span><strong>${fmtNum(c.transactions)}টি</strong></li>
        <li><span>দেনা-পাওনা</span><strong>${fmtNum(c.dues)}টি</strong></li>
        <li><span>শোধ/আদায়</span><strong>${fmtNum(c.settlements)}টি</strong></li>
        <li><span>ট্রান্সফার</span><strong>${fmtNum(c.transfers)}টি</strong></li>
      </ul>
      <p class="muted small">নমুনা ডেটা মুছলে আপনার নিজের যোগ করা এন্ট্রি থাকবে। মুছে ফেলার আগে বর্তমান ডেটা সেভ থাকবে, ভুল হলে সেটিংস থেকে "আগের অবস্থায় ফিরুন" দিয়ে ফেরা যাবে।</p>
      <div class="btn-row">
        <button class="btn btn-danger" id="dp-del" type="button">নমুনা ডেটা মুছুন</button>
        <button class="btn btn-ghost" id="dp-keep" type="button">রেখে দিন (আসল ধরুন)</button>
      </div>
      <button class="lock-link-dark" id="dp-later" type="button">এখন না, পরে জিজ্ঞেস করুন</button>
    `, { onClose: finish });

    const q = (s) => sheet.el.querySelector(s);
    q('#dp-del').addEventListener('click', async () => {
      await savePrevSnapshot();
      await update(removeDemoData);
      toast('নমুনা ডেটা মুছে ফেলা হয়েছে');
      sheet.close();
    });
    q('#dp-keep').addEventListener('click', async () => {
      await update(keepDemoAsReal);
      toast('ডেটা আসল হিসেবে রাখা হয়েছে');
      sheet.close();
    });
    q('#dp-later').addEventListener('click', () => sheet.close());
  });
}
