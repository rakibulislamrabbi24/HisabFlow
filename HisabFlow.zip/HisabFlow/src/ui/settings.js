import { getState, update } from '../store.js';
import { renderBackupSection } from './backup.js';
import { renderAppLockSection } from './applock.js';
import { applyTheme } from '../theme.js';
import { icon } from './icons.js';
import { openSheet, toast } from './modal.js';
import { fmtNum, fmtDateFull, esc } from '../utils/format.js';
import { APP_VERSION } from '../version.js';
import { LANGS, getLang, switchLanguage } from '../i18n/index.js';
import { validateProfile, initialOf, hueOf, showDigits } from '../services/contacts.js';

const THEMES = [
  { k: 'auto', l: 'স্বয়ংক্রিয়' },
  { k: 'light', l: 'লাইট' },
  { k: 'dark', l: 'ডার্ক' }
];

function openProfileForm(afterSave) {
  const profile = getState().settings.profile || { name: '', phone: '' };
  const sheet = openSheet(`
    <div class="sheet-head">
      <h2>${icon('user', { size: 20 })} আপনার তথ্য</h2>
      <button class="icon-btn" data-close aria-label="বন্ধ">${icon('x', { size: 18 })}</button>
    </div>
    <label class="field"><span>আপনার নাম</span>
      <input id="pf-name" class="input" type="text" maxlength="30" placeholder="যেমন: রাফি" />
    </label>
    <label class="field"><span>মোবাইল নম্বর (ঐচ্ছিক)</span>
      <input id="pf-phone" class="input" type="tel" inputmode="tel" maxlength="20" placeholder="০১৭১২৩৪৫৬৭৮" />
      <small class="muted">এই তথ্য শুধু আপনার ফোনে থাকে। হোমে শুভেচ্ছায় এবং দেনা-পাওনার মেসেজ ও কার্ডে আপনার পরিচয় হিসেবে বসবে।</small>
    </label>
    <div class="error" id="pf-error"></div>
    <div class="btn-row"><button class="btn" id="pf-save" type="button">সেভ করুন</button></div>
  `);
  const q = (s) => sheet.el.querySelector(s);
  q('#pf-name').value = profile.name || '';
  q('#pf-phone').value = profile.phone || '';
  q('#pf-save').addEventListener('click', async () => {
    const res = validateProfile({ name: q('#pf-name').value, phone: q('#pf-phone').value });
    if (res.error) { q('#pf-error').textContent = res.error; return; }
    await update((s) => { s.settings.profile = res.clean; });
    sheet.close();
    toast('সেভ হয়েছে');
    afterSave();
  });
}

export function renderSettings(c) {
  const s = getState();
  const theme = s.settings.theme || 'auto';
  const profile = s.settings.profile || { name: '', phone: '' };
  const initial = initialOf(profile.name);

  c.innerHTML = `
    <button class="profile-card" id="profile-open" type="button">
      <span class="avatar big" style="--hue:${initial ? hueOf(profile.name) : 350}">${initial ? esc(initial) : icon('user', { size: 26 })}</span>
      <span class="profile-text">
        <span class="profile-name">${profile.name ? esc(profile.name) : 'আপনার নাম যোগ করুন'}</span>
        <span class="muted small">${profile.phone ? showDigits(profile.phone) : 'মোবাইল নম্বর (ঐচ্ছিক)'}</span>
      </span>
      ${icon('edit', { size: 18 })}
    </button>

    <div class="card">
      <h2>${icon('globe', { size: 20 })} ভাষা / Language</h2>
      <div class="seg" id="lang-seg" style="margin-bottom:0">
        ${LANGS.map((l) => `<button data-lang="${l.k}" class="${l.k === getLang() ? 'active' : ''}" type="button">${l.label}</button>`).join('')}
      </div>
    </div>

    <div class="card">
      <h2>${icon('palette', { size: 20 })} থিম</h2>
      <div class="seg" id="theme-seg" style="margin-bottom:0">
        ${THEMES.map((t) => `<button data-theme="${t.k}" class="${t.k === theme ? 'active' : ''}" type="button">${t.l}</button>`).join('')}
      </div>
    </div>

    <div id="applock-section"></div>
    <div id="backup-section"></div>

    <div class="card">
      <h2>${icon('shield', { size: 20 })} অ্যাপ তথ্য</h2>
      <ul class="list">
        <li><span class="muted">অ্যাপ</span><span>HisabFlow v${APP_VERSION}</span></li>
        <li><span class="muted">ডেটা ভার্সন</span><span>${fmtNum(s.version)}</span></li>
        <li><span class="muted">ডেটা তৈরির তারিখ</span><span>${fmtDateFull(s.settings.createdAt)}</span></li>
        <li><span class="muted">স্টোরেজ</span><span class="ok">${icon('check', { size: 15, cls: 'inl' })} লোকাল ডিভাইস</span></li>
      </ul>
    </div>
    <p class="muted small center">HisabFlow — আপনার হিসাব, আপনার ফোনেই</p>`;

  renderAppLockSection(c.querySelector('#applock-section'), () => renderSettings(c));
  renderBackupSection(c.querySelector('#backup-section'), () => renderSettings(c));

  c.querySelector('#profile-open').addEventListener('click', () => openProfileForm(() => renderSettings(c)));

  c.querySelector('#lang-seg').addEventListener('click', async (e) => {
    const b = e.target.closest('button');
    if (!b || b.dataset.lang === getLang()) return;
    const k = b.dataset.lang;
    await update((st) => { st.settings.language = k; });
    switchLanguage(k); // পর্দা নতুন ভাষায় আবার আঁকা হয়
  });

  c.querySelector('#theme-seg').addEventListener('click', async (e) => {
    const b = e.target.closest('button');
    if (!b) return;
    const k = b.dataset.theme;
    c.querySelectorAll('#theme-seg button').forEach((x) => x.classList.toggle('active', x === b));
    applyTheme(k);
    await update((st) => { st.settings.theme = k; });
  });
}

export const __forms = { openProfileForm };
