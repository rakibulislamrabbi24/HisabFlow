import { getState, update } from '../store.js';
import { uid, todayISO } from '../models.js';
import { renderBackupSection } from './backup.js';
import { renderAppLockSection } from './applock.js';
import { applyTheme } from '../theme.js';
import { icon } from './icons.js';
import { fmtNum, fmtDateFull } from '../utils/format.js';

// ডেমো ডেটা: টেস্ট করার জন্য। demo:true চিহ্ন থাকায় আলাদা করে মুছে ফেলা যায়।
function addDemo(s) {
  const d = new Date();
  const ym = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
  const pm = new Date(d.getFullYear(), d.getMonth() - 1, 1);
  const prev = `${pm.getFullYear()}-${String(pm.getMonth() + 1).padStart(2, '0')}`;
  const T = (type, amount, category, walletId, date, note = '') =>
    s.transactions.push({ id: uid('t'), type, amount, category, walletId, date, note, demo: true });

  T('income', 30000, 'বেতন', 'w_bank', `${prev}-05`, 'গত মাসের বেতন');
  T('expense', 8000, 'বাসা ভাড়া', 'w_bank', `${prev}-07`);
  T('income', 35000, 'বেতন', 'w_bank', `${ym}-05`, 'এ মাসের বেতন');
  T('expense', 8000, 'বাসা ভাড়া', 'w_bank', `${ym}-07`);
  T('expense', 450, 'খাবার', 'w_cash', `${ym}-09`, 'দুপুরের খাবার');
  T('expense', 1200, 'বিল', 'w_bkash', `${ym}-10`, 'ইন্টারনেট বিল');
  T('income', 2500, 'ব্যবসা', 'w_nagad', `${ym}-12`);

  const due1 = uid('d');
  const due2 = uid('d');
  s.dues.push(
    { id: due1, kind: 'receivable', person: 'রহিম', amount: 5000, walletId: 'w_cash', date: `${ym}-03`, dueDate: `${prev}-28`, note: 'ধার', demo: true },
    { id: due2, kind: 'payable', person: 'করিম', amount: 3000, walletId: 'w_bkash', date: `${ym}-04`, dueDate: `${ym}-28`, note: '', demo: true }
  );
  s.settlements.push({ id: uid('s'), dueId: due1, amount: 2000, walletId: 'w_cash', date: `${ym}-11`, demo: true });

  // আগের ২-৫ মাসের নমুনা (চার্ট দেখার জন্য)
  const cats = ['খাবার', 'যাতায়াত', 'বিল', 'কেনাকাটা', 'চিকিৎসা'];
  for (let k = 2; k <= 5; k++) {
    const md = new Date(d.getFullYear(), d.getMonth() - k, 1);
    const key = `${md.getFullYear()}-${String(md.getMonth() + 1).padStart(2, '0')}`;
    T('income', 28000 + k * 1500, 'বেতন', 'w_bank', `${key}-05`);
    T('expense', 8000, 'বাসা ভাড়া', 'w_bank', `${key}-07`);
    cats.forEach((cat, i) => T('expense', 600 + ((k * 7 + i * 5) % 9) * 350, cat, i % 2 ? 'w_bkash' : 'w_cash', `${key}-${String(8 + i * 4).padStart(2, '0')}`));
  }
  // ট্রান্সফার (ফি সহ): Bank → bKash
  const trId = uid('tr');
  s.transfers.push({ id: trId, fromWalletId: 'w_bank', toWalletId: 'w_bkash', amount: 5000, fee: 0, date: `${ym}-06`, note: 'bKash-এ পাঠানো', demo: true });
  // bKash → Cash (ক্যাশআউট ফি সহ)
  const trId2 = uid('tr');
  s.transfers.push({ id: trId2, fromWalletId: 'w_bkash', toWalletId: 'w_cash', amount: 2000, fee: 36, date: `${ym}-09`, note: 'ক্যাশআউট', demo: true });
  s.transactions.push({ id: uid('t'), type: 'expense', amount: 36, category: 'ট্রান্সফার ফি', walletId: 'w_bkash', date: `${ym}-09`, note: 'ট্রান্সফার ফি', transferId: trId2, demo: true });
  // চলতি মাসে আরও কিছু ব্যয় (ডোনাট/দৈনিক চার্টের জন্য)
  T('expense', 900, 'যাতায়াত', 'w_cash', `${ym}-02`);
  T('expense', 2200, 'কেনাকাটা', 'w_bkash', `${ym}-08`);
  T('expense', 700, 'চিকিৎসা', 'w_cash', `${ym}-11`);
}

function removeDemo(s) {
  s.transactions = s.transactions.filter((x) => !x.demo);
  s.dues = s.dues.filter((x) => !x.demo);
  s.settlements = s.settlements.filter((x) => !x.demo);
  s.transfers = s.transfers.filter((x) => !x.demo);
}

const THEMES = [
  { k: 'auto', l: 'স্বয়ংক্রিয়' },
  { k: 'light', l: 'লাইট' },
  { k: 'dark', l: 'ডার্ক' }
];
let devOpen = false;

export function renderSettings(c) {
  const s = getState();
  const hasDemo = [...s.transactions, ...s.dues, ...s.settlements, ...s.transfers].some((x) => x.demo);
  const theme = s.settings.theme || 'auto';

  c.innerHTML = `
    <div class="settings-stats">
      <div class="tile"><strong>${fmtNum(s.wallets.length)}</strong><span>ওয়ালেট</span></div>
      <div class="tile"><strong>${fmtNum(s.transactions.length)}</strong><span>লেনদেন</span></div>
      <div class="tile"><strong>${fmtNum(s.dues.length)}</strong><span>দেনা-পাওনা</span></div>
    </div>

    <div class="card">
      <h2>${icon('palette', { size: 20 })} থিম</h2>
      <div class="seg" id="theme-seg" style="margin-bottom:0">
        ${THEMES.map((t) => `<button data-theme="${t.k}" class="${t.k === theme ? 'active' : ''}" type="button">${t.l}</button>`).join('')}
      </div>
    </div>

    <div id="applock-section"></div>
    <div id="backup-section"></div>

    <div class="card">
      <h2>${icon('shield', { size: 20 })} অ্যাপ তথ্য</h2>
      <ul class="list">
        <li><span class="muted">অ্যাপ</span><span>HisabFlow v0.9.0</span></li>
        <li><span class="muted">ডেটা ভার্সন</span><span>${fmtNum(s.version)}</span></li>
        <li><span class="muted">ডেটা তৈরির তারিখ</span><span>${fmtDateFull(s.settings.createdAt)}</span></li>
        <li><span class="muted">স্টোরেজ</span><span class="ok">${icon('check', { size: 15, cls: 'inl' })} লোকাল ডিভাইস</span></li>
      </ul>
    </div>

    <details class="card dev" id="dev" ${devOpen ? 'open' : ''}>
      <summary><span>টেস্ট ডেটা (শুধু পরীক্ষার জন্য)</span>${icon('chevron-right', { size: 18 })}</summary>
      <div class="dev-body">
        <p class="muted small">ড্যাশবোর্ড ও চার্ট কেমন দেখায় তা যাচাই করতে নমুনা ডেটা যোগ করুন। আপনার আসল এন্ট্রি মুছবে না, শুধু নমুনা ডেটা মুছবে।</p>
        <div class="btn-row">
          <button class="btn" id="demo-add" ${hasDemo ? 'disabled' : ''}>নমুনা ডেটা যোগ করুন</button>
          <button class="btn btn-ghost" id="demo-del" ${hasDemo ? '' : 'disabled'}>নমুনা ডেটা মুছুন</button>
        </div>
      </div>
    </details>
    <p class="muted small center">HisabFlow — আপনার হিসাব, আপনার ফোনেই</p>`;

  renderAppLockSection(c.querySelector('#applock-section'), () => renderSettings(c));
  renderBackupSection(c.querySelector('#backup-section'), () => renderSettings(c));

  c.querySelector('#theme-seg').addEventListener('click', async (e) => {
    const b = e.target.closest('button');
    if (!b) return;
    const k = b.dataset.theme;
    c.querySelectorAll('#theme-seg button').forEach((x) => x.classList.toggle('active', x === b));
    applyTheme(k);
    await update((st) => { st.settings.theme = k; });
  });

  c.querySelector('#dev').addEventListener('toggle', (e) => { devOpen = e.target.open; });
  c.querySelector('#demo-add').addEventListener('click', async () => {
    await update(addDemo);
    renderSettings(c);
  });
  c.querySelector('#demo-del').addEventListener('click', async () => {
    await update(removeDemo);
    renderSettings(c);
  });
}
