import { getState, update } from '../store.js';
import { uid, todayISO } from '../models.js';

// ডেমো ডেটা: টেস্ট করার জন্য। demo:true চিহ্ন থাকায় আলাদা করে মুছে ফেলা যায়।
function addDemo(s) {
  const d = new Date();
  const ym = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
  const pm = new Date(d.getFullYear(), d.getMonth() - 1, 1);
  const prev = `${pm.getFullYear()}-${String(pm.getMonth() + 1).padStart(2, '0')}`;
  const T = (type, amount, category, walletId, date, note = '') =>
    s.transactions.push({ id: uid('t'), type, amount, category, walletId, date, note, demo: true });

  T('income', 30000, 'বেতন', 'w_bank', `${prev}-05`, 'গত মাসের বেতন');
  T('expense', 8000, 'বাসা ভাড়া', 'w_bank', `${prev}-07`);
  T('income', 35000, 'বেতন', 'w_bank', `${ym}-05`, 'এ মাসের বেতন');
  T('expense', 8000, 'বাসা ভাড়া', 'w_bank', `${ym}-07`);
  T('expense', 450, 'খাবার', 'w_cash', `${ym}-09`, 'দুপুরের খাবার');
  T('expense', 1200, 'বিল', 'w_bkash', `${ym}-10`, 'ইন্টারনেট বিল');
  T('income', 2500, 'ব্যবসা', 'w_nagad', `${ym}-12`);

  const due1 = uid('d');
  const due2 = uid('d');
  s.dues.push(
    { id: due1, kind: 'receivable', person: 'রহিম', amount: 5000, walletId: 'w_cash', date: `${ym}-03`, dueDate: `${prev}-28`, note: 'ধার', demo: true },
    { id: due2, kind: 'payable', person: 'করিম', amount: 3000, walletId: 'w_bkash', date: `${ym}-04`, dueDate: `${ym}-28`, note: '', demo: true }
  );
  s.settlements.push({ id: uid('s'), dueId: due1, amount: 2000, walletId: 'w_cash', date: `${ym}-11`, demo: true });

  // আগের ২-৫ মাসের নমুনা (চার্ট দেখার জন্য)
  const cats = ['খাবার', 'যাতায়াত', 'বিল', 'কেনাকাটা', 'চিকিৎসা'];
  for (let k = 2; k <= 5; k++) {
    const md = new Date(d.getFullYear(), d.getMonth() - k, 1);
    const key = `${md.getFullYear()}-${String(md.getMonth() + 1).padStart(2, '0')}`;
    T('income', 28000 + k * 1500, 'বেতন', 'w_bank', `${key}-05`);
    T('expense', 8000, 'বাসা ভাড়া', 'w_bank', `${key}-07`);
    cats.forEach((cat, i) => T('expense', 600 + ((k * 7 + i * 5) % 9) * 350, cat, i % 2 ? 'w_bkash' : 'w_cash', `${key}-${String(8 + i * 4).padStart(2, '0')}`));
  }
  // চলতি মাসে আরও কিছু ব্যয় (ডোনাট/দৈনিক চার্টের জন্য)
  T('expense', 900, 'যাতায়াত', 'w_cash', `${ym}-02`);
  T('expense', 2200, 'কেনাকাটা', 'w_bkash', `${ym}-08`);
  T('expense', 700, 'চিকিৎসা', 'w_cash', `${ym}-11`);
}

function removeDemo(s) {
  s.transactions = s.transactions.filter((x) => !x.demo);
  s.dues = s.dues.filter((x) => !x.demo);
  s.settlements = s.settlements.filter((x) => !x.demo);
}

export function renderSettings(c) {
  const s = getState();
  const hasDemo = [...s.transactions, ...s.dues, ...s.settlements].some((x) => x.demo);

  c.innerHTML = `
    <div class="card">
      <h2>অ্যাপ তথ্য</h2>
      <ul class="list">
        <li><span>অ্যাপ</span><span>HisabFlow v0.5.0</span></li>
        <li><span>ডেটা ভার্সন</span><span>${s.version}</span></li>
        <li><span>ডেটা তৈরির তারিখ</span><span>${s.settings.createdAt}</span></li>
        <li><span>স্টোরেজ</span><span class="ok">লোকাল ডিভাইস ✓</span></li>
      </ul>
    </div>
    <div class="card">
      <h2>ডেটা সারাংশ</h2>
      <ul class="list">
        <li><span>ওয়ালেট</span><span>${s.wallets.length}</span></li>
        <li><span>লেনদেন</span><span>${s.transactions.length}</span></li>
        <li><span>দেনা-পাওনা</span><span>${s.dues.length}</span></li>
      </ul>
    </div>
    <div class="card">
      <h2>ডেমো ডেটা (টেস্টের জন্য)</h2>
      <p class="muted small">ড্যাশবোর্ড কেমন দেখায় তা যাচাই করতে নমুনা ডেটা যোগ করুন। আপনার আসল এন্ট্রি মুছবে না, শুধু ডেমো ডেটা মুছবে।</p>
      <div class="btn-row">
        <button class="btn" id="demo-add" ${hasDemo ? 'disabled' : ''}>ডেমো ডেটা যোগ করুন</button>
        <button class="btn btn-ghost" id="demo-del" ${hasDemo ? '' : 'disabled'}>ডেমো ডেটা মুছুন</button>
      </div>
    </div>
    <p class="muted small center">ব্যাকআপ/রিস্টোর ধাপ ৭-এ যোগ হবে</p>`;

  c.querySelector('#demo-add').addEventListener('click', async () => {
    await update(addDemo);
    renderSettings(c);
  });
  c.querySelector('#demo-del').addEventListener('click', async () => {
    await update(removeDemo);
    renderSettings(c);
  });
}
