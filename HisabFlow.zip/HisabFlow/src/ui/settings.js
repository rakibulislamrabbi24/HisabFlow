import { getState } from '../store.js';

// ধাপ ১: স্টোরেজ ঠিকমতো চালু হয়েছে কিনা এখানে দেখা যাবে
export function renderSettings(c) {
  const s = getState();
  c.innerHTML = `
    <div class="card">
      <h2>অ্যাপ তথ্য</h2>
      <ul class="list">
        <li><span>অ্যাপ</span><span>HisabFlow v0.1.0</span></li>
        <li><span>ডেটা ভার্সন</span><span>${s.version}</span></li>
        <li><span>ডেটা তৈরির তারিখ</span><span>${s.settings.createdAt}</span></li>
        <li><span>স্টোরেজ</span><span class="ok">লোকাল ডিভাইস ✓</span></li>
      </ul>
    </div>
    <div class="card">
      <h2>ডেটা সারাংশ</h2>
      <ul class="list">
        <li><span>ওয়ালেট</span><span>${s.wallets.length}</span></li>
        <li><span>লেনদেন</span><span>${s.transactions.length}</span></li>
        <li><span>দেনা-পাওনা</span><span>${s.dues.length}</span></li>
      </ul>
    </div>
    <p class="muted small center">ব্যাকআপ/রিস্টোর ধাপ ৭-এ যোগ হবে</p>`;
}
