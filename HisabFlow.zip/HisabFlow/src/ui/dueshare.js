// দেনা-পাওনার হিসাব শেয়ার: তৈরি মেসেজ (কপি/শেয়ার/WhatsApp) ও ফটো কার্ড (ছবি সেভ/শেয়ার)
import { getState } from '../store.js';
import { todayISO } from '../models.js';
import { dueInfo, settlementsOf } from '../services/dues.js';
import { buildDueMessage } from '../services/messages.js';
import { toWaNumber, showDigits } from '../services/contacts.js';
import { makeDueCard } from '../utils/card.js';
import { copyText, shareText, shareImage, openExternal } from '../utils/files.js';
import { withoutRelock } from '../lockState.js';
import { openSheet, toast } from './modal.js';
import { icon } from './icons.js';
import { fmtNum, fmtDateFull } from '../utils/format.js';

export function cardDataFor(due, info, history, profile) {
  const isReceivable = due.kind === 'receivable';
  const t = (n) => `৳${fmtNum(n)}`;
  const status = info.status === 'settled'
    ? 'সম্পূর্ণ পরিশোধিত'
    : info.status === 'partial'
      ? (isReceivable ? 'আংশিক আদায় হয়েছে' : 'আংশিক পরিশোধ হয়েছে')
      : 'এখনও বাকি';
  const sender = [profile.name, profile.phone ? showDigits(profile.phone) : ''].filter(Boolean).join(' · ');
  return {
    isReceivable,
    kindLabel: isReceivable ? 'পাওনার হিসাব' : 'দেনার হিসাব',
    person: due.person,
    subline: `${fmtDateFull(due.date)}${due.note ? ' · ' + due.note : ''}`,
    remainingText: t(info.remaining),
    statusText: status,
    pct: info.pct,
    totalText: t(due.amount),
    paidText: t(info.paid),
    paidLabel: isReceivable ? 'আদায়' : 'পরিশোধ',
    dueText: due.dueDate ? `মেয়াদ: ${fmtDateFull(due.dueDate)}${info.overdue ? ' (পার হয়ে গেছে)' : ''}` : '',
    overdue: info.overdue,
    historyTitle: isReceivable ? 'আদায়ের তালিকা' : 'পরিশোধের তালিকা',
    history: history.slice(0, 4).map((s) => ({ left: fmtDateFull(s.date), right: t(s.amount) })),
    sender,
    brand: 'HisabFlow'
  };
}

export function openDueShare(dueId) {
  const st = getState();
  const due = st.dues.find((d) => d.id === dueId);
  if (!due) return;
  const info = dueInfo(st, due, todayISO());
  const history = settlementsOf(st, due.id);
  const profile = st.settings.profile || { name: '', phone: '' };
  const message = buildDueMessage({ due, info, history, profile });
  const wa = toWaNumber(due.phone);

  const sheet = openSheet(`
    <div class="sheet-head">
      <h2>${icon('share', { size: 20 })} হিসাব শেয়ার</h2>
      <button class="icon-btn" data-close aria-label="বন্ধ">${icon('x', { size: 18 })}</button>
    </div>
    <div class="seg" id="sh-tabs">
      <button data-tab="msg" class="active" type="button">মেসেজ</button>
      <button data-tab="card" type="button">ফটো কার্ড</button>
    </div>

    <div id="sh-msg">
      <textarea id="sh-text" class="input" rows="11"></textarea>
      <p class="muted small">লেখাটি নিজের মতো বদলে নিতে পারেন।</p>
      <div class="btn-row">
        <button class="btn btn-ghost" id="sh-copy" type="button">${icon('copy', { size: 18 })} কপি</button>
        <button class="btn" id="sh-send" type="button">${icon('share', { size: 18 })} শেয়ার</button>
      </div>
      ${wa ? `<button class="btn btn-wa" id="sh-wa" type="button">${icon('message', { size: 18 })} WhatsApp-এ পাঠান</button>` : ''}
    </div>

    <div id="sh-card" class="hidden">
      <div class="muted small center" id="sh-loading">কার্ড তৈরি হচ্ছে…</div>
      <img id="sh-img" class="card-preview hidden" alt="হিসাব কার্ড" />
      <div class="btn-row">
        <button class="btn" id="sh-img-share" type="button" disabled>${icon('image', { size: 18 })} ছবি সেভ/শেয়ার</button>
      </div>
      <p class="muted small">শেয়ার মেনু থেকে গ্যালারি/ড্রাইভে সেভ করা যায়, বা WhatsApp-এ পাঠানো যায়।</p>
    </div>
  `);
  const q = (s) => sheet.el.querySelector(s);
  const textEl = q('#sh-text');
  textEl.value = message;

  let card = null;
  let cardStarted = false;
  async function ensureCard() {
    if (cardStarted) return;
    cardStarted = true;
    try {
      card = await makeDueCard(cardDataFor(due, info, history, profile));
      q('#sh-img').src = card.dataUrl;
      q('#sh-img').classList.remove('hidden');
      q('#sh-loading').classList.add('hidden');
      q('#sh-img-share').disabled = false;
    } catch (err) {
      console.error(err);
      q('#sh-loading').textContent = 'কার্ড তৈরি করা যায়নি';
    }
  }

  q('#sh-tabs').addEventListener('click', (e) => {
    const b = e.target.closest('button');
    if (!b) return;
    const tab = b.dataset.tab;
    q('#sh-tabs').querySelectorAll('button').forEach((x) => x.classList.toggle('active', x === b));
    q('#sh-msg').classList.toggle('hidden', tab !== 'msg');
    q('#sh-card').classList.toggle('hidden', tab !== 'card');
    if (tab === 'card') ensureCard();
  });

  q('#sh-copy').addEventListener('click', async () => {
    toast((await copyText(textEl.value)) ? 'কপি করা হয়েছে' : 'কপি করা যায়নি');
  });

  q('#sh-send').addEventListener('click', async () => {
    try {
      const r = await withoutRelock(() => shareText(textEl.value, 'হিসাব'));
      if (r === 'copied') toast('কপি করা হয়েছে');
    } catch (err) {
      console.error(err);
      toast('শেয়ার করা যায়নি');
    }
  });

  const waBtn = q('#sh-wa');
  if (waBtn) {
    waBtn.addEventListener('click', async () => {
      await withoutRelock(async () => openExternal(`https://wa.me/${wa}?text=${encodeURIComponent(textEl.value)}`));
    });
  }

  q('#sh-img-share').addEventListener('click', async () => {
    if (!card) return;
    try {
      const r = await withoutRelock(() => shareImage(card.base64, `HisabFlow-hisab-${Date.now()}.png`));
      if (r === 'downloaded') toast('ছবি ডাউনলোড হয়েছে');
    } catch (err) {
      console.error(err);
      toast('ছবি শেয়ার করা যায়নি');
    }
  });
}
