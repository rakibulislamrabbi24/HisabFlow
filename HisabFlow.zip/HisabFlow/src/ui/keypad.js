// পিন কিপ্যাড (লক স্ক্রিন ও পিন সেট/যাচাইয়ের শিটে একই কম্পোনেন্ট)
import { fmtNum } from '../utils/format.js';

export function createKeypad({ length, onSubmit, onBiometric = null }) {
  const el = document.createElement('div');
  el.className = 'keypad';
  const key = (d) => `<button class="key" data-d="${d}" type="button">${fmtNum(d)}</button>`;
  el.innerHTML = `
    <div class="pin-dots" aria-label="পিন">${'<span></span>'.repeat(length)}</div>
    <div class="pin-msg" aria-live="polite"></div>
    <div class="pad">
      ${[1, 2, 3, 4, 5, 6, 7, 8, 9].map(key).join('')}
      ${onBiometric ? '<button class="key key-fn" data-act="bio" type="button" aria-label="ফিঙ্গারপ্রিন্ট">👆</button>' : '<span class="key key-empty"></span>'}
      ${key(0)}
      <button class="key key-fn" data-act="del" type="button" aria-label="মুছুন">⌫</button>
    </div>`;

  const dots = el.querySelectorAll('.pin-dots span');
  const msg = el.querySelector('.pin-msg');
  let pin = '';
  let disabled = false;
  let busy = false;

  const paint = () => dots.forEach((d, i) => d.classList.toggle('on', i < pin.length));

  async function press(d) {
    if (disabled || busy || pin.length >= length) return;
    pin += d;
    paint();
    if (pin.length === length) {
      busy = true;
      const entered = pin;
      try {
        await onSubmit(entered);
      } finally {
        pin = '';
        paint();
        busy = false;
      }
    }
  }

  el.querySelector('.pad').addEventListener('click', (e) => {
    const b = e.target.closest('.key');
    if (!b) return;
    if (b.dataset.d !== undefined) press(b.dataset.d);
    else if (b.dataset.act === 'del') { if (!disabled && !busy) { pin = pin.slice(0, -1); paint(); } }
    else if (b.dataset.act === 'bio' && onBiometric && !disabled) onBiometric();
  });

  return {
    el,
    reset() { pin = ''; paint(); },
    message(text, kind = '') {
      msg.textContent = text || '';
      msg.className = 'pin-msg' + (kind ? ' ' + kind : '');
    },
    shake() {
      const d = el.querySelector('.pin-dots');
      d.classList.remove('shake');
      void d.offsetWidth; // অ্যানিমেশন আবার চালু করতে
      d.classList.add('shake');
      if (navigator.vibrate) navigator.vibrate(120);
    },
    setDisabled(v) {
      disabled = !!v;
      el.classList.toggle('disabled', disabled);
    }
  };
}
