// লোকাল স্টোরেজ লেয়ার: পুরো ডেটা একটি JSON হিসেবে সেভ/লোড হয়
import { Preferences } from '@capacitor/preferences';
import { defaultData, normalize } from './models.js';

const KEY = 'hisabflow_data';
let state = null;
const listeners = new Set();

export async function loadData() {
  try {
    const { value } = await Preferences.get({ key: KEY });
    state = value ? normalize(JSON.parse(value)) : defaultData();
    if (!value) await saveData(); // প্রথমবার ডিফল্ট ডেটা লিখে রাখা
  } catch (err) {
    console.error('ডেটা লোড করতে সমস্যা:', err);
    state = defaultData();
  }
  return state;
}

export async function saveData() {
  await Preferences.set({ key: KEY, value: JSON.stringify(state) });
  listeners.forEach((fn) => fn(state));
}

export function getState() {
  return state;
}

// ডেটা বদলাতে এই ফাংশন ব্যবহার করুন: update(s => s.transactions.push(...))
export async function update(mutator) {
  mutator(state);
  await saveData();
}

// ব্যাকআপ রিস্টোরের সময় (ধাপ ৭) পুরো ডেটা বদলানো হবে
export async function replaceAll(newData) {
  state = normalize(newData);
  await saveData();
}

export function subscribe(fn) {
  listeners.add(fn);
  return () => listeners.delete(fn);
}
