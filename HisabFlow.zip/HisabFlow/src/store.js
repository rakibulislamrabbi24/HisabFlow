// লোকাল স্টোরেজ লেয়ার: পুরো ডেটা একটি JSON হিসেবে সেভ/লোড হয়
import { Preferences } from '@capacitor/preferences';
import { defaultData, normalize } from './models.js';

const KEY = 'hisabflow_data';
let state = null;
const listeners = new Set();

export async function loadData() {
  try {
    const { value } = await Preferences.get({ key: KEY });
    state = value ? normalize(JSON.parse(value)) : defaultData();
    if (!value) await saveData(); // প্রথমবার ডিফল্ট ডেটা লিখে রাখা
  } catch (err) {
    console.error('ডেটা লোড করতে সমস্যা:', err);
    state = defaultData();
  }
  return state;
}

export async function saveData() {
  await Preferences.set({ key: KEY, value: JSON.stringify(state) });
  listeners.forEach((fn) => fn(state));
}

export function getState() {
  return state;
}

// ডেটা বদলাতে এই ফাংশন ব্যবহার করুন: update(s => s.transactions.push(...))
export async function update(mutator) {
  mutator(state);
  await saveData();
}

// ব্যাকআপ রিস্টোরের সময় (ধাপ ৭) পুরো ডেটা বদলানো হবে
export async function replaceAll(newData) {
  state = normalize(newData);
  await saveData();
}

export function subscribe(fn) {
  listeners.add(fn);
  return () => listeners.delete(fn);
}

// ---- নিরাপত্তা স্ন্যাপশট: রিস্টোর/রিসেটের ঠিক আগের ডেটা এক ধাপ ফেরত আনার জন্য ----
const PREV_KEY = 'hisabflow_data_prev';

export async function savePrevSnapshot(data = state) {
  await Preferences.set({ key: PREV_KEY, value: JSON.stringify({ savedAt: new Date().toISOString(), data }) });
}

export async function getPrevSnapshot() {
  try {
    const { value } = await Preferences.get({ key: PREV_KEY });
    if (!value) return null;
    const snap = JSON.parse(value);
    return snap && snap.data ? snap : null;
  } catch {
    return null;
  }
}

// আগের অবস্থায় ফেরা। বর্তমান ডেটা নতুন স্ন্যাপশট হয়ে যায়, তাই আবার চাপলে উল্টো ফেরা যায়।
export async function restorePrevSnapshot() {
  const snap = await getPrevSnapshot();
  if (!snap) return false;
  const current = state;
  await replaceAll(snap.data);
  await savePrevSnapshot(current);
  return true;
}

export async function clearPrevSnapshot() {
  await Preferences.remove({ key: PREV_KEY });
}

// পিন ভুলে গেলে: সব ডেটা ও আগের কপিও মুছে ফেলা (কপি রেখে দিলে সেটা দিয়ে লক এড়ানো যেত)
export async function resetEverything() {
  await replaceAll(defaultData());
  await clearPrevSnapshot();
}
