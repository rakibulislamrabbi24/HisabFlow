# HisabFlow
Capacitor + Vite অ্যাপ। `android-res/` ফোল্ডারে অ্যাপ আইকনের ফাইল আছে,
GitHub Actions বিল্ডের সময় এগুলো `android/app/src/main/res/`-এ কপি হয়।
